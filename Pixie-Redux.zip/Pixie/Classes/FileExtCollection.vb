﻿
' Collection of filename extensions
Public Class FileExtCollection
    Implements ICollection(Of String)

    ' Internal collection object for storing extensions
    Private myExts As New Collection

    ' Load from Pixie settings
    Public Sub Load()
        AddMultiple(My.Settings.SearchExtensions, ";")
    End Sub

    ' Save to Pixie settings
    Public Sub Save()
        My.Settings.SearchExtensions = Merge(";")
    End Sub

    ' Number of extensions stored
    Public ReadOnly Property Count As Integer Implements ICollection(Of String).Count
        Get
            Return myExts.Count
        End Get
    End Property

    ' NOT read-only!
    Public ReadOnly Property IsReadOnly As Boolean Implements ICollection(Of String).IsReadOnly
        Get
            Return False
        End Get
    End Property

    ' Throw invalid extension exception
    Protected Sub ThrowInvalid(ext As String)
        Dim msg As String = My.Resources.PixieResources.InvalidFileExtChar
        msg += " " + ext
        Throw New Exception(msg)
    End Sub

    ' Prettifies and validates a filename extension
    ' Throws an exception if the extension contains invalid characters
    Public Function Prettify(item As String) As String
        item = item.Trim().ToUpper()
        If item.StartsWith(".") Then
            item = item.Substring(1)
        End If
        If item.Length < 1 Then
            Throw New Exception("Can't add empty file extension to collection.")
        End If
        Dim invalid As Char() = IO.Path.GetInvalidFileNameChars()
        If item.LastIndexOfAny(invalid) >= 0 Then
            ThrowInvalid(item)
        End If
        If item.LastIndexOf(32) >= 0 Then
            ThrowInvalid(item)
        End If
        Return item
    End Function

    ' Get item at specified index
    Public ReadOnly Property Item(index As Integer) As String
        Get
            If (index < 1) Then Return Nothing
            If (index > Count) Then Return Nothing
            Return myExts.Item(index)
        End Get
    End Property

    ' Add an extension
    Public Sub Add(item As String) Implements ICollection(Of String).Add
        item = Prettify(item)
        If Not Contains(item) Then
            myExts.Add(item)
        End If
    End Sub

    ' Clear the collection
    Public Sub Clear() Implements ICollection(Of String).Clear
        myExts.Clear()
    End Sub

    ' Copy to external array (not implemented)
    Public Sub CopyTo(array() As String, arrayIndex As Integer) Implements ICollection(Of String).CopyTo
        Throw New NotImplementedException()
    End Sub

    ' Determines if item exists in collection
    Public Function Contains(item As String) As Boolean Implements ICollection(Of String).Contains
        item = item.Trim().ToUpper()
        If item.StartsWith(".") Then
            item = item.Substring(1)
        End If
        Return myExts.Contains(item)
    End Function

    ' Gets an enumerator for the collection
    Public Function GetEnumerator() As IEnumerator(Of String) Implements IEnumerable(Of String).GetEnumerator
        Throw New NotImplementedException("Microsoft sucks!!!")
    End Function

    ' Removes an item from the collection
    Public Function Remove(item As String) As Boolean Implements ICollection(Of String).Remove
        item = item.Trim().ToUpper()
        If myExts.Contains(item) Then
            myExts.Remove(item)
            Return True
        Else
            Return False
        End If
    End Function

    ' Gets an enumerator for the collection
    Private Function IEnumerable_GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Throw New NotImplementedException("Microsoft sucks!!!")
    End Function

    ' Split string containing multiple extensions
    Public Sub AddMultiple(items As String, separator As Char)
        items = items.Trim()
        While items.EndsWith(";")
            items = items.Substring(0, items.Length - 1)
        End While
        While items.StartsWith(";")
            items = items.Substring(1)
        End While
        Dim exts As String() = items.Split(separator)
        Dim index As Integer = 0
        Dim last As Integer = exts.Count - 1
        While index <= last
            Add(exts(index))
            index += 1
        End While
    End Sub

    ' Merge into single string
    Public Function Merge(separator As Char) As String
        Dim result As String = ""
        Dim last As Integer = Count
        If last < 0 Then
            Return result
        End If
        Dim index As Integer = 1
        result = myExts.Item(index)
        index += 1
        While index <= last
            result += separator + myExts.Item(index)
            index += 1
        End While
        Return result
    End Function

    ' Writes collection to a temporary TXT file and returns
    ' the pathname of that file. Returns an empty string if
    ' an exception occurs or the collection is empty.
    Public Function Report() As String
        Try
            If Count < 1 Then
                Return ""
            End If
            Dim path As String = IO.Path.GetTempFileName()
            path = IO.Path.ChangeExtension(path, "txt")
            Dim stream As New IO.StreamWriter(path)
            Dim index As Integer
            Dim last As Integer = Count - 1
            For index = 0 To last
                stream.WriteLine(myExts.Item(index))
            Next
            stream.Close()
            Return path
        Catch ex As Exception
            ShowWarnBox(ex.Message)
        End Try
        Return ""
    End Function

End Class

