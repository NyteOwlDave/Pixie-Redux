﻿
' Base class for all info classes
Imports Pixie

' Job exception class
Public Class JobException
    Inherits Exception
    Public XmlTag As String
    Public Details As String = ""
    Public Sub New(tag As String, reason As String)
        MyBase.New(reason)
        XmlTag = tag
    End Sub
    Public Sub New(tag As String, reason As String, details As String)
        MyBase.New(reason)
        XmlTag = tag
        If details IsNot Nothing Then
            Me.Details = details
        End If
    End Sub
    Public Shared Sub ThrowBecause(tag As String, reason As String)
        Throw New JobException(tag, reason)
    End Sub
End Class

' Base class for all tags
Friend MustInherit Class TagInfo
    ' XML tag name
    Public MustOverride ReadOnly Property Tag As String
    ' Throws exception: named node is missing it's XML document
    Public Sub ThrowMissingXmlDocument(name As String)
        Dim msg As String = "Missing XML document."
        JobException.ThrowBecause(name, msg)
    End Sub
    ' Throws exception: named node is missing it's XML parent node
    Public Sub ThrowMissingXmlParentNode(name As String)
        Dim msg As String = "Missing XML parent node."
        JobException.ThrowBecause(name, msg)
    End Sub
    ' Throws exception: node is missing (nothing)
    Public Sub ThrowMissingXmlNode(name As String)
        Dim msg As String = "Missing XML node."
        JobException.ThrowBecause(name, msg)
    End Sub
    ' Throws exception: node has the wrong tag name
    Public Sub ThrowInvalidXmlTagName(name As String)
        Dim msg As String = "Invalid XML tag name."
        JobException.ThrowBecause(name, msg)
    End Sub
    ' Throws exception: node's parent has the wrong tag name
    Public Sub ThrowInvalidXmlParentTagName(name As String)
        Dim msg As String = "Invalid XML parent tag name."
        JobException.ThrowBecause(name, msg)
    End Sub
    ' Throws exception: Missing a required element
    Public Sub ThrowMissingElement(name As String)
        JobException.ThrowBecause(name, My.Resources.JobResources.JobFileMissingElement)
    End Sub
    ' Checks to see if node is missing (nothing), throws if so
    Public Sub CheckXmlNode(node As Xml.XmlNode, name As String)
        If node Is Nothing Then
            ThrowMissingXmlNode(name)
        End If
        If node.Name <> name Then
            ThrowInvalidXmlTagName(name)
        End If
    End Sub
    ' Checks to see if node's document is missing (nothing), throws if so
    Public Sub CheckXmlDocument(node As Xml.XmlNode, name As String)
        CheckXmlNode(node, name)
        If node.OwnerDocument Is Nothing Then
            ThrowMissingXmlDocument(name)
        End If
    End Sub
    ' Checks to see if node's parent is missing (nothing), throws if so
    Public Sub CheckXmlParentNode(parent As Xml.XmlNode, nodeName As String)
        If parent Is Nothing Then
            ThrowMissingXmlParentNode(nodeName)
        End If
    End Sub
    ' Checks to see if node's tag name is wrong, throws if so
    Public Sub CheckXmlTagName(node As Xml.XmlNode, name As String)
        CheckXmlNode(node, name)
        If node.Name <> name Then
            ThrowInvalidXmlTagName(name)
        End If
    End Sub
    ' Checks to see if node's parent tag name is wrong, throws if so
    Public Sub CheckXmlParentTagName(parent As Xml.XmlNode, parentName As String, nodeName As String)
        CheckXmlParentNode(parent, nodeName)
        If parent.Name <> parentName Then
            ThrowInvalidXmlParentTagName(nodeName)
        End If
    End Sub
End Class

' User information class
Friend Class UserInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "user"
        End Get
    End Property
    ' XML name attribute value
    Public Property Name As String
    ' XML domain attribute value
    Public Property Domain As String
    ' Initialize name only (domain = loaded)
    Public Sub InitName(name As String)
        Me.Name = name
        Me.Domain = GetUserDomain()
    End Sub
    ' Initialize domain only (name = loaded)
    Public Sub InitDomain(domain As String)
        Me.Name = NCS.UserName
        Me.Domain = domain
    End Sub
    ' Initilialize name and domain
    Public Sub Init(name As String, domain As String)
        Me.Name = name
        Me.Domain = domain
    End Sub
    ' Load name and domain to job settings
    Public Sub Load()
        Name = NCS.UserName
        Domain = NCS.UserDomain
    End Sub
    ' Save name and domain to job settings
    Public Sub Save()
        NCS.UserName = Name
        NCS.UserDomain = Domain
    End Sub
    ' Create and append XML element for this item
    Public Function CreateXml(parent As Xml.XmlNode) As Xml.XmlElement
        CheckXmlParentTagName(parent, "settings", Me.Tag)
        CheckXmlDocument(parent, "settings")
        Dim doc As Xml.XmlDocument = parent.OwnerDocument
        Dim elem As Xml.XmlElement = doc.CreateElement(Me.Tag)
        parent.AppendChild(elem)
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        elem.Attributes.Append(attr)
        attr = doc.CreateAttribute("domain")
        attr.Value = Me.Domain
        elem.Attributes.Append(attr)
        Return elem
    End Function
    ' Read XML node into this object's members
    Public Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("name")
        Me.Name = attr.Value
        attr = node.Attributes.GetNamedItem("domain")
        Me.Domain = attr.Value
    End Sub
    ' Write XML node from this object's members
    Public Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("domain")
        attr.Value = Me.Domain
        node.Attributes.SetNamedItem(attr)
    End Sub
End Class

' Job information class
Friend Class JobInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "job"
        End Get
    End Property
    ' XML type attribute value
    Public Property JobType As NCS.JobTypeEnum
    ' XML status attribute value
    Public Property JobStatus As NCS.JobStatusEnum
    ' Initialize type (status = pending)
    Public Sub Init(t As NCS.JobTypeEnum)
        JobType = t
        JobStatus = NCS.JobStatusEnum.Pending
    End Sub
    ' Load type and status from job settings
    Public Sub Load()
        JobType = NCS.JobType
        JobStatus = NCS.JobStatus
    End Sub
    ' Save type and status to job settings
    Public Sub Save()
        NCS.JobType = JobType
        NCS.JobStatus = JobStatus
    End Sub
    ' Create and append XML element for this item
    Public Function CreateXml(parent As Xml.XmlNode) As Xml.XmlElement
        CheckXmlParentTagName(parent, "settings", Me.Tag)
        CheckXmlDocument(parent, "settings")
        Dim doc As Xml.XmlDocument = parent.OwnerDocument
        Dim elem As Xml.XmlElement = doc.CreateElement(Me.Tag)
        parent.AppendChild(elem)
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("type")
        attr.Value = Me.JobType
        elem.Attributes.Append(attr)
        attr = doc.CreateAttribute("status")
        attr.Value = Me.JobStatus
        elem.Attributes.Append(attr)
        Return elem
    End Function
    ' Read XML node into this object's members
    Public Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("type")
        Me.JobType = CType(attr.Value, NCS.JobTypeEnum)
        attr = node.Attributes.GetNamedItem("status")
        Me.JobStatus = CType(attr.Value, NCS.JobStatusEnum)
    End Sub
    ' Write XML node from this object's members
    Public Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("type")
        attr.Value = Me.JobType.ToString()
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("status")
        attr.Value = Me.JobStatus.ToString()
        node.Attributes.SetNamedItem(attr)
    End Sub
End Class

' Date information class
Friend Class DateInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "date"
        End Get
    End Property
    ' Name ID enumeration
    Public Enum NameEnum
        Created
        Completed
    End Enum
    ' Internal name ID
    Private myID As NameEnum
    ' Read-only access to internal name ID
    Public ReadOnly Property ID As NameEnum
        Get
            Return myID
        End Get
    End Property
    ' Throw exception for internal name ID invalid
    Private Sub ThrowInvalidMyID()
        ThrowInvalidID(myID)
    End Sub
    ' Throw exception for name ID invalid
    Private Sub ThrowInvalidID(id As NameEnum)
        Dim s As String
        s = "Invalid date id: " + id.ToString
        Throw New Exception(s)
    End Sub
    ' Throw exception for name invalid
    Private Sub ThrowInvalidName(name As String)
        Dim s As String
        s = "Invalid date name: " + name
        Throw New Exception(s)
    End Sub
    ' XML name attribute value
    Public Property Name As String
        Get
            Select Case myID
                Case NameEnum.Completed
                    Return "completed"
                Case NameEnum.Created
                    Return "created"
                Case Else
                    ThrowInvalidMyID()
                    Return Nothing
            End Select
        End Get
        Set(value As String)
            Dim s As String = value.Trim().ToLower()
            If s = "completed" Then
                myID = NameEnum.Completed
            ElseIf s = "created" Then
                myID = NameEnum.Created
            Else
                ThrowInvalidName(value)
            End If
        End Set
    End Property
    ' XML value attribute value
    Public Property Value As Date
    ' Check name ID, throw is invalid
    Public Sub CheckID(id As NameEnum)
        Select Case id
            Case NameEnum.Completed
                Exit Select
            Case NameEnum.Created
                Exit Select
            Case Else
                ThrowInvalidID(id)
        End Select
    End Sub
    ' Initialize name by ID, value = Now
    Public Sub InitNow(id As NameEnum)
        CheckID(id)
        myID = id
        Value = Date.Now()
    End Sub
    ' Initialize name by ID, value = Caller Defined
    Public Sub Init(id As NameEnum, value As Date)
        CheckID(id)
        myID = id
        Me.Value = value
    End Sub
    ' Initialize name as text, value = Now
    Public Sub InitNow(name As String)
        Me.Name = name
        Value = Date.Now()
    End Sub
    ' Initialize name as text, value = Caller Defined
    Public Sub Init(name As String, value As Date)
        Me.Name = name
        Me.Value = value
    End Sub
    ' Load value from job settings, using current name
    Public Sub Load()
        Select Case myID
            Case NameEnum.Completed
                Value = NCS.CompletionDate
            Case NameEnum.Created
                Value = NCS.CreationDate
            Case Else
                ThrowInvalidMyID()
        End Select
    End Sub
    ' Init name by ID, load value from job settings
    Public Sub Load(id As NameEnum)
        CheckID(id)
        myID = id
        Load()
    End Sub
    ' Init name as text, load value from job settings
    Public Sub Load(name As String)
        If name Is Nothing Then name = ""
        If name.Length > 0 Then
            Me.Name = name
        End If
        Load()
    End Sub
    ' Save value to job settings, using current name
    Public Sub Save()
        Select Case myID
            Case NameEnum.Completed
                Value = NCS.CompletionDate
            Case NameEnum.Created
                NCS.CreationDate = Value
            Case Else
                ThrowInvalidMyID()
        End Select
    End Sub
    ' Init name by ID, save value to job settings
    Public Sub Save(id As NameEnum)
        CheckID(id)
        myID = id
        Save()
    End Sub
    ' Init name as text, save value to job settings
    Public Sub Save(name As String)
        If name Is Nothing Then name = ""
        If name.Length > 0 Then
            Me.Name = name
        End If
        Save()
    End Sub
    ' Create and append XML element for this item
    Public Function CreateXml(parent As Xml.XmlNode) As Xml.XmlElement
        CheckXmlParentTagName(parent, "dates", Me.Tag)
        CheckXmlDocument(parent, "settings")
        Dim doc As Xml.XmlDocument = parent.OwnerDocument
        Dim elem As Xml.XmlElement = doc.CreateElement(Me.Tag)
        parent.AppendChild(elem)
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        elem.Attributes.Append(attr)
        attr = doc.CreateAttribute("value")
        attr.Value = Me.Value.ToString()
        elem.Attributes.Append(attr)
        Return elem
    End Function
    ' Read XML node into this object's members
    Public Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("name")
        Me.Name = attr.Value
        attr = node.Attributes.GetNamedItem("value")
        Me.Value = CDate(attr.Value)
    End Sub
    ' Write XML node from this object's members
    Public Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("value")
        attr.Value = Me.Value.ToString()
        node.Attributes.SetNamedItem(attr)
    End Sub
End Class

' Path information class
Friend Class PathInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "path"
        End Get
    End Property
    ' Name ID enumeration
    Public Enum NameEnum
        Source
        Target
    End Enum
    ' Internal name ID
    Private myID As NameEnum
    ' Read-only access to internal name ID
    Public ReadOnly Property ID As NameEnum
        Get
            Return myID
        End Get
    End Property
    ' Throw invalid internal name ID
    Private Sub ThrowInvalidMyID()
        ThrowInvalidID(myID)
    End Sub
    ' Throw invalid name ID
    Private Sub ThrowInvalidID(id As NameEnum)
        Dim msg As String
        msg = "Invalid path id: " + id.ToString
        Throw New JobException(Me.Tag, msg)
    End Sub
    ' Throw invalid name
    Private Sub ThrowInvalidName(name As String)
        Dim msg As String
        msg = "Invalid path name: " + name
        Throw New JobException(Me.Tag, msg)
    End Sub
    ' XML name attribute value
    Public Property Name As String
        Get
            Select Case myID
                Case NameEnum.Source
                    Return "source"
                Case NameEnum.Target
                    Return "target"
                Case Else
                    ThrowInvalidMyID()
                    Return Nothing
            End Select
        End Get
        Set(value As String)
            Dim s As String = value.Trim().ToLower()
            If (s = "source") Then
                myID = NameEnum.Source
            ElseIf (s = "target") Then
                myID = NameEnum.Target
            Else
                ThrowInvalidName(s)
            End If
        End Set
    End Property
    ' XML value attribute value
    Public Property Value As String
    ' Check name ID, throw if invalid
    Public Sub CheckID(id As NameEnum)
        Select Case id
            Case NameEnum.Source, NameEnum.Target
                Return
            Case Else
                ThrowInvalidID(id)
        End Select
    End Sub
    ' Initialize name by ID (value = loaded)
    Public Sub InitID(id As NameEnum)
        CheckID(id)
        myID = id
        Load()
    End Sub
    ' Initialize name by ID (value = custom)
    Public Sub InitID(id As NameEnum, value As String)
        CheckID(id)
        myID = id
        Me.Value = value
    End Sub
    ' Load value using current name ID
    Public Sub Load()
        Select Case myID
            Case NameEnum.Source
                Value = NCS.SourcePath
            Case NameEnum.Target
                Value = NCS.TargetPath
            Case Else
                ThrowInvalidMyID()
        End Select
    End Sub
    ' Load value using other name ID
    Public Sub Load(id As NameEnum)
        CheckID(id)
        myID = id
        Load()
    End Sub
    ' Load value using other name as text
    Public Sub Load(name As String)
        If name Is Nothing Then name = ""
        If name.Length > 0 Then
            Me.Name = name
        End If
        Load()
    End Sub
    ' Save value using current name ID
    Public Sub Save()
        Select Case ID
            Case NameEnum.Source
                NCS.SourcePath = Value
            Case NameEnum.Target
                NCS.TargetPath = Value
            Case Else
                ThrowInvalidID(ID)
        End Select
    End Sub
    ' Save value using other name ID
    Public Sub Save(id As NameEnum)
        CheckID(id)
        myID = id
        Save()
    End Sub
    ' Save value using other name as text
    Public Sub Save(name As String)
        If name Is Nothing Then name = ""
        If name.Length > 0 Then
            Me.Name = name
        End If
        Save()
    End Sub
    ' Read XML node into this object's members
    Public Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("name")
        Me.Name = attr.Value
        attr = node.Attributes.GetNamedItem("value")
        Me.Value = attr.Value
    End Sub
    ' Write XML node from this object's members
    Public Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("value")
        attr.Value = Me.Value
        node.Attributes.SetNamedItem(attr)
    End Sub
End Class

' Path parser class
Public Class PathParser
    Private myOpenerDetected As Boolean = False
    Private myCloserDetected As Boolean = False
    Private myFolder As String = ""
    Private myName As String = ""
    Private myCount As Integer = -1
    Private myExt As String = ""
    ' Access to count member
    Public Property Count As Integer
        Get
            Return myCount
        End Get
        Set(value As Integer)
            If value >= 0 Then
                myOpenerDetected = True
                myCloserDetected = True
                myCount = Count
            Else
                myOpenerDetected = False
                myCloserDetected = False
                myCount = -1
            End If
        End Set
    End Property
    ' Access to the full pathname
    Public Property Path As String
        Get
            ' Merge the component parts into a whole and return the result
            Return Merge()
        End Get
        Set(value As String)
            ' Split the whole into component parts
            Split(value)
        End Set
    End Property
    ' Merge component parts into a full pathname
    Private Function Merge() As String
        Dim temp As String = myFolder + myName
        If myOpenerDetected Then temp += "("
        If myCount > -1 Then temp += myCount.ToString()
        If myCloserDetected Then temp += ")"
        Return temp + myExt
    End Function
    ' Split a full pathname into component parts.
    ' This is where the real magic happens. The folder portion is split
    ' off, as well as the filename and extension, into three separate
    ' components. Then the filename portion is analyzed to see if it
    ' possesses a numeric suffix enclosed in parenths "(nnn)".
    ' If so, the suffix is removed and the value of the numeric digits
    ' is recorded, as well as which parenth(s) were detected and removed.
    ' If parenths are empty, or not a matching pair, or missing entirely,
    ' the myCount value will be set to -1. Otherwise, myCount contains the
    ' detected and decoded positive integer. Any trailing ")" is removed
    ' regardless of whether it has a matching "(". The Merge function will
    ' replace it later. It's possible for the filename portion to contain
    ' embedded parenths which don't match the required pattern. For example:
    '   name(3)x, n)ame, na(me), nam(e) etc. all have embedded parenths. 
    ' The results of splitting each of these is:
    '   name(3)x, n)ame, na(me, nam(e
    ' Notice that in the latter two cases, the trailing ")" was removed.
    Private Sub Split(pathName As String)
        ' Get folder portion
        myFolder = IO.Path.GetDirectoryName(pathName)
        ' Get filename w/o extension
        myName = IO.Path.GetFileNameWithoutExtension(pathName)
        ' Get extension
        myExt = IO.Path.GetExtension(pathName)
        ' Clear opener detected flag
        myOpenerDetected = False
        myCloserDetected = False
        ' Clear count
        myCount = -1
        ' Get the length of the name portion
        Dim length As Integer = myName.Length
        ' If the name portion is an empty string, we're done
        If length < 1 Then Return
        ' If there is no closer detected, we're done
        If Not myName.EndsWith(")") Then Return
        ' Signal that we located a closer
        myCloserDetected = True
        ' If the closer is the only character, simply remove it
        If length < 2 Then
            myName = ""
            Return
        End If
        ' If the filename has exactly two characters
        If length = 2 Then
            ' If the only other character is an opener
            If myName.ElementAt(0) = "(" Then
                ' Signal opener was found
                myOpenerDetected = True
                ' Remove opener and closer
                myName = ""
            Else
                ' Just remove the closer
                myName = myName.Substring(0, 1)
            End If
            ' We're done!
            Return
        End If
        ' Mark down the index of the closer ")"
        Dim index1 As Integer = length - 1
        ' Move back one position to what should be a numeric character
        Dim index2 As Integer = index1 - 1
        ' Take the string one character at a time
        Dim ch As String
        ' Search for matching opener "("
        Do
            ' Get next character
            ch = myName.ElementAt(index2)
            ' If the character isn't numeric...
            If Not IsNumeric(ch) Then
                ' If the character isn't the desired "("
                ' We can stop looking and let the closer
                ' be removed outside the loop
                If ch <> "(" Then Exit Do
                ' Signal that we located an opener
                myOpenerDetected = True
                ' Determine the number of numeric digits detected
                Dim lengthDigits As Integer = index1 - index2 - 1
                ' If no numeric digits were detected
                If (lengthDigits < 1) Then
                    ' Remove the silly empty parenths "()" from the end
                    ' of the filename, as they serve no real purpose.
                    myName = myName.Substring(0, length - 2)
                    ' And we're done
                    Return
                End If
                ' Capture the numeric digits between opener and closer
                Dim temp As String = myName.Substring(index2 + 1, lengthDigits)
                ' Convert them to an integer value
                myCount = Val(temp)
                ' Bump the length of the digit count to include opener and closer
                lengthDigits += 2
                ' Remove the opener, all digits, and the closer from the name string
                myName = myName.Substring(0, length - lengthDigits)
                ' Done!
                Return
            End If
            ' Back up one position and continue scanning past numeric digits
            index2 -= 1
        Loop While (index2 >= 0)
        ' We never located a matching opener, so...
        ' just remove the closer from the name, since it will be appended
        ' later in the Merge function.
        myName = myName.Substring(0, myName.Length - 1)
    End Sub
    ' Determine if a file exists at the specified path
    Public ReadOnly Property FileExists As Boolean
        Get
            Return IO.File.Exists(Me.Path)
        End Get
    End Property
    ' Determine if a folder exists at the specified path
    Public ReadOnly Property FolderExists As Boolean
        Get
            Return IO.Directory.Exists(Me.Path)
        End Get
    End Property
End Class

' File information class
Friend Class FileInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "file"
        End Get
    End Property
    ' Flag to pause copying or scanning
    Public ReadOnly Property Pause As Boolean
        Get
            If NCS.JobStatus = NCS.JobStatusEnum.Paused Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property
    ' Internal XML name attribute value
    Private Property myName As String
    ' Throw name empty exception
    Private Sub ThrowEmptyName()
        Dim msg As String = "File or folder name can't be empty."
        Throw New JobException(Me.Tag, msg)
    End Sub
    ' XML name attribute value
    Public Property Name As String
        Get
            Return myName
        End Get
        Set(value As String)
            Dim s As String = value.Trim()
            If s.Length < 1 Then
                ThrowEmptyName()
            End If
            myName = s
        End Set
    End Property
    ' XML status attribute value
    Private myStatus As NCS.JobStatusEnum
    ' Sync lock object for myStatus
    Private myStatusLock As New Object
    ' XML status attribute value
    Public Property Status As NCS.JobStatusEnum
        Get
            SyncLock myStatusLock
                Return myStatus
            End SyncLock
        End Get
        Set(value As NCS.JobStatusEnum)
            SyncLock myStatusLock
                myStatus = value
            End SyncLock
        End Set
    End Property
    ' XML size attribute value
    Public Property Size As ULong
    ' Get full path
    Public Function GetFullPath(folder As String) As String
        If folder.EndsWith("\") Or folder.EndsWith("/") Then
            Return folder + Name
        End If
        Return folder + "\" + Name
    End Function
    ' Check for file's existence in specified folder
    Public Function FileExistsIn(folder As String) As Boolean
        Dim path As String = GetFullPath(folder)
        Return System.IO.File.Exists(path)
    End Function
    ' Get information about file with this name in specified folder
    Public Function GetFileInfo(folder As String) As System.IO.FileInfo
        Dim path As String = GetFullPath(folder)
        Return New System.IO.FileInfo(path)
    End Function
    ' Throw job cancelled exception
    Public Sub ThrowJobCancelled()
        JobException.ThrowBecause(Me.Tag, My.Resources.JobResources.JobCancelledMsg)
    End Sub
    ' Helper to deal with pausing logic
    Protected Sub HandlePause()
        If Me.Pause Then
            Me.Status = NCS.JobStatusEnum.Paused
            While Me.Pause
                System.Threading.Thread.Sleep(300)
            End While
        End If
    End Sub
    ' Helper to handle cancel logic
    Protected Sub HandleCancel()
        ' See if user cancelled the job
        If NCS.JobStatus = NCS.JobStatusEnum.Cancelled Then
            ThrowJobCancelled()
        End If
    End Sub
    ' Rename target file
    Public Function RenameTargetFile(pathName As String) As String
        Dim psr As New PathParser
        psr.Path = pathName
        While psr.FileExists
            psr.Count += 1
        End While
        Return psr.Path
    End Function
    ' Copies the file form one folder to another
    Public Function CopyFile(targetFolder As String, sourceFolder As String) As Boolean
        Try
            ' Deal with pause logic
            HandlePause()
            ' Handle cancel logic
            HandleCancel()
            ' For log entries
            Dim entry As String = ""
            ' Set status to copying
            Me.Status = NCS.JobStatusEnum.Copying
            ' Get full pathname for source file
            Dim sourcePath As String = GetFullPath(sourceFolder)
            ' Get full pathname for target file
            Dim targetPath As String = GetFullPath(targetFolder)
            ' Make sure target filename is unique
            targetPath = RenameTargetFile(targetPath)
            ' Get info about source file
            Dim info As IO.FileInfo = New IO.FileInfo(sourcePath)
            ' Make log entry about our purpose
            entry = "Copying file from: " + sourcePath
            AddJobLogEntry(entry)
            entry = "Copying file to: " + targetPath
            AddJobLogEntry(entry)
            ' Try to copy the file (throws if file already exists)
            info.CopyTo(targetPath)
            ' Set status to copied
            Me.Status = NCS.JobStatusEnum.Copied
            ' Bump count of files copied
            NCS.FilesCopied = NCS.FilesCopied + 1
            ' Update bytes copied
            NCS.BytesCopied += Me.Size
            ' Report on result
            AddJobLogEntry("File was successfully copied.")
            ' Return success flag
            Return True
        Catch ex As JobException
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' If exception was due to user cancellation
            If ex.Message = My.Resources.JobResources.JobCancelledMsg Then
                ' Update status accordingly
                Me.Status = NCS.JobStatusEnum.Cancelled
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return failure flag
            Return False
        Catch ex As Exception
            ' Log the exception
            AddJobLogEntry(ex)
            ' Set status to failed
            Me.Status = NCS.JobStatusEnum.Failed
            ' Rethrow the exception, in case it's fatal
            Throw
        End Try
    End Function
    ' Scans the file size in the specified folder
    Public Function ScanFile(folder As String) As Boolean
        Try
            ' Deal with pause logic
            HandlePause()
            ' Handle cancel logic
            HandleCancel()
            ' For log entries
            Dim entry As String = ""
            ' Set status to scanning
            Me.Status = NCS.JobStatusEnum.Scanning
            ' Get full pathname to source file
            Dim path As String = GetFullPath(folder)
            ' Report what we're doing
            entry = "Scanning file: " + path
            AddJobLogEntry(entry)
            ' Make sure source file exists
            If Not FileExistsIn(folder) Then
                JobException.ThrowBecause(Me.Tag, "Source file doesn't exist: " + path)
                Me.Status = NCS.JobStatusEnum.Failed
                Return False
            End If
            ' Get file information
            Dim info As IO.FileInfo = GetFileInfo(path)
            ' Record size
            Me.Size = info.Length
            ' Report on result
            AddJobLogEntry("File was successfully scanned. Size = " &
                           Me.Size.ToString & " bytes.")
            ' Set status to scanned
            Me.Status = NCS.JobStatusEnum.Scanned
            ' Bump scanned files count
            NCS.FilesScanned = NCS.FilesScanned + 1
            ' Update bytes scanned
            NCS.BytesScanned += Me.Size
            ' Return success flag
            Return True
        Catch ex As JobException
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' If exception was due to user cancellation
            If ex.Message = My.Resources.JobResources.JobCancelledMsg Then
                ' Update status accordingly
                Me.Status = NCS.JobStatusEnum.Cancelled
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return failure flag
            Return False
        Catch ex As Exception
            ' Log the exception
            AddJobLogEntry(ex)
            ' Set status to failed
            Me.Status = NCS.JobStatusEnum.Failed
            ' Rethrow the exception, in case it's fatal
            Throw
        End Try
    End Function
    ' Read XML node into this object's members
    Public Overridable Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("name")
        Me.Name = attr.Value
        attr = node.Attributes.GetNamedItem("size")
        Me.Size = CInt(attr.Value)
        attr = node.Attributes.GetNamedItem("status")
        Me.Status = CInt(attr.Value)
    End Sub
    ' Write XML node from this object's members
    Public Overridable Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("size")
        attr.Value = Me.Size
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("status")
        attr.Value = Me.Status
        node.Attributes.SetNamedItem(attr)
    End Sub
End Class

' Folder information class
Friend Class FolderInfo
    Inherits FileInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "folder"
        End Get
    End Property
    ' Internal collection of subfolders
    Private myFolders As New FolderCollection
    ' Read-only access to internal collection of subfolders
    Public ReadOnly Property Folders As FolderCollection
        Get
            Return myFolders
        End Get
    End Property
    ' Internal collection of files
    Private myFiles As New FileCollection
    ' Read-only access to internal collection of files
    Public ReadOnly Property Files As FileCollection
        Get
            Return myFiles
        End Get
    End Property
    ' Initialize
    Public Sub Init()
        myFolders.Clear()
        myFiles.Clear()
    End Sub
    ' Check for folder's existence in specified folder
    Public Function FolderExistsIn(folder As String) As Boolean
        Dim path As String = GetFullPath(folder)
        Return System.IO.Directory.Exists(path)
    End Function
    ' Get information about file with this name in specified folder
    Public Function GetFolderInfo(folder As String) As System.IO.DirectoryInfo
        Dim path As String = GetFullPath(folder)
        Return New System.IO.DirectoryInfo(path)
    End Function
    ' Copies the file form one folder to another
    Public Function CopyFolder(targetParentFolder As String, sourceParentFolder As String) As Boolean
        Try
            ' Deal with pause logic
            HandlePause()
            ' Handle cancel logic
            HandleCancel()
            ' For log entries
            Dim entry As String = ""
            ' Set status to copying
            Me.Status = NCS.JobStatusEnum.Copying
            ' Determine full path to source folder
            Dim sourcePath As String = GetFullPath(sourceParentFolder)
            ' Determine full path to target folder
            Dim targetPath As String = GetFullPath(targetParentFolder)
            ' Get information about source folder
            Dim sourceInfo As IO.DirectoryInfo = New IO.DirectoryInfo(sourcePath)
            ' Get information about target folder
            Dim targetInfo As IO.DirectoryInfo = New IO.DirectoryInfo(targetPath)
            ' Make log entries explaining what's about to happen
            entry = "Copying from: " + sourcePath
            AddJobLogEntry(entry)
            entry = "Copying to: " + targetPath
            AddJobLogEntry(entry)
            ' Make sure source parent folder exists
            If Not IO.Directory.Exists(sourceParentFolder) Then
                JobException.ThrowBecause(Me.Tag, "Source parent folder doesn't exist: " &
                                          sourceParentFolder)
                Return False ' redundant
            End If
            ' Make sure source folder exists
            If Not sourceInfo.Exists Then
                JobException.ThrowBecause(Me.Tag, "Source folder doesn't exist: " + sourcePath)
                Return False ' redundant
            End If
            ' Create target parent folder, if required
            If Not IO.Directory.Exists(targetParentFolder) Then
                entry = "Creating target parent folder: " + targetParentFolder
                Logging.AddJobLogEntry(entry)
                IO.Directory.CreateDirectory(targetParentFolder)
            End If
            ' Create target folder, if required
            If Not targetInfo.Exists Then
                entry = "Creating target folder: " + targetPath
                Logging.AddJobLogEntry(entry)
                targetInfo.Create()
            End If
            ' Begin copying files
            Dim ok As Boolean = True
            Dim file As FileInfo
            entry = "Copying " + myFiles.Count.ToString() + " files."
            Logging.AddJobLogEntry(entry)
            ' Copy all files
            For Each file In myFiles
                ok &= file.CopyFile(targetPath, sourcePath)
            Next
            ' Report on success/fail
            If Not ok Then
                entry = "One or more files failed to copy."
            Else
                entry = "All files were successfully copied."
            End If
            Logging.AddJobLogEntry(entry)
            ' Begin copying folders
            Dim ok2 As Boolean = True
            Dim fldr As FolderInfo
            entry = "Copying " + myFolders.Count.ToString() + " folders."
            Logging.AddJobLogEntry(entry)
            ' Copy folders
            For Each fldr In myFolders
                ok2 &= fldr.CopyFolder(targetPath, sourcePath)
            Next
            ' Report on success/fail
            If Not ok2 Then
                entry = "One or more folders failed to copy."
            Else
                entry = "All folders were successfully copied."
            End If
            Logging.AddJobLogEntry(entry)
            ' Combine success/fail flags
            ok &= ok2
            ' Determine status for this folder, based on results
            If ok Then
                ' Set status to copied
                Me.Status = NCS.JobStatusEnum.Copied
                ' Bump folder copy count
                NCS.FoldersCopied = NCS.FoldersCopied + 1
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return overall success/fail
            Return ok
        Catch ex As JobException
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' If exception was due to user cancellation
            If ex.Message = My.Resources.JobResources.JobCancelledMsg Then
                ' Update status accordingly
                Me.Status = NCS.JobStatusEnum.Cancelled
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return failure flag
            Return False
        Catch ex As Exception
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' Set status to failed
            Me.Status = NCS.JobStatusEnum.Failed
            ' Rethrow exception, in case it's fatal
            Throw
        End Try
    End Function
    ' Scans the files and folders size in the specified folder
    Public Function ScanFolder(parentFolder As String) As Boolean
        Try
            ' Deal with pause logic
            HandlePause()
            ' Handle cancel logic
            HandleCancel()
            ' For log entries
            Dim entry As String = ""
            ' Set status to copying
            Me.Status = NCS.JobStatusEnum.Copying
            ' Clear existing file collection
            myFiles.Clear()
            ' Clear existing folder collection
            myFolders.Clear()
            ' Make sure parent folder still exists
            If Not IO.Directory.Exists(parentFolder) Then
                JobException.ThrowBecause(Me.Tag, "Source parent folder doesn't exist: " + parentFolder)
                Return False ' redundant
            End If
            ' Make sure folder still exists
            If Not FolderExistsIn(parentFolder) Then
                JobException.ThrowBecause(Me.Tag, "Source folder doesn't exist: " + parentFolder)
                Return False ' redundant
            End If
            ' Get full pathname to source folder
            Dim folder As String = GetFullPath(parentFolder)
            ' Get begin scanning files
            Dim files As String()
            files = IO.Directory.GetFiles(folder)
            Dim fi As FileInfo
            Dim name As String
            Dim ok As Boolean = True
            ' Scan files
            For Each name In files
                fi = New FileInfo
                fi.Name = name
                ok &= fi.ScanFile(folder)
                myFiles.Add(fi)
            Next
            ' Report on success/fail
            If Not ok Then
                entry = "One or more files couldn't be scanned."
            Else
                entry = "All files were scanned successfully."
            End If
            AddJobLogEntry(entry)
            ' Begin scanning subfolders
            Dim di As FolderInfo
            Dim folders As String()
            folders = IO.Directory.GetDirectories(folder)
            Dim ok2 As Boolean = True
            ' Scan subfolders
            For Each name In folders
                di = New FolderInfo
                di.Name = name
                ok2 &= di.ScanFolder(folder)
                myFolders.Add(di)
            Next
            ' Report on success/fail
            If Not ok2 Then
                entry = "One or more folders couldn't be scanned."
            Else
                entry = "All folders were scanned successfully."
            End If
            AddJobLogEntry(entry)
            ' Combine overall success/fail flags
            ok &= ok2
            ' If all went well
            If ok Then
                ' Set status to scanned
                Me.Status = NCS.JobStatusEnum.Scanned
                ' Bump scanned folder count
                NCS.FoldersScanned = NCS.FoldersScanned + 1
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return overall success/fail
            Return ok
        Catch ex As JobException
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' If due to user cancellation
            If ex.Message = My.Resources.JobResources.JobCancelledMsg Then
                ' Set status to cancelled
                Me.Status = NCS.JobStatusEnum.Cancelled
            Else
                ' Set status to failed
                Me.Status = NCS.JobStatusEnum.Failed
            End If
            ' Return failure indication
            Return False
        Catch ex As Exception
            ' Log the exception
            Logging.AddJobLogEntry(ex)
            ' Set status to failed
            Me.Status = NCS.JobStatusEnum.Failed
            ' Rethrow exception, in case it's fatal
            Throw
        End Try
    End Function
    ' Read XML node into this object's members
    Public Overrides Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim attr As Xml.XmlAttribute
        attr = node.Attributes.GetNamedItem("name")
        Me.Name = attr.Value
        attr = node.Attributes.GetNamedItem("size")
        Me.Size = CInt(attr.Value)
        attr = node.Attributes.GetNamedItem("status")
        Me.Status = CInt(attr.Value)
        myFiles.Clear()
        myFolders.Clear()
        Dim fi As New FileInfo
        Dim nodeChild As Xml.XmlNode
        Dim nodes As Xml.XmlNodeList
        nodes = node.SelectNodes(fi.Tag)
        For Each nodeChild In nodes
            fi = New FileInfo
            fi.ReadXml(nodeChild)
            myFiles.Add(fi)
        Next
        Dim di As New FolderInfo
        nodes = node.SelectNodes(di.Tag)
        For Each nodeChild In nodes
            di = New FolderInfo
            di.ReadXml(nodeChild)
            myFolders.Add(di)
        Next
    End Sub
    ' Write XML node from this object's members
    Public Overrides Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim attr As Xml.XmlAttribute = doc.CreateAttribute("name")
        attr.Value = Me.Name
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("size")
        attr.Value = Me.Size
        node.Attributes.SetNamedItem(attr)
        attr = doc.CreateAttribute("status")
        attr.Value = Me.Status
        node.Attributes.SetNamedItem(attr)
        Dim fi As FileInfo
        Dim nodeChild As Xml.XmlElement
        For Each fi In myFiles
            nodeChild = doc.CreateElement(fi.Tag)
            node.AppendChild(nodeChild)
            fi.WriteXml(nodeChild)
        Next
        Dim di As FolderInfo
        For Each di In myFolders
            nodeChild = doc.CreateElement(di.Tag)
            node.AppendChild(nodeChild)
            di.WriteXml(nodeChild)
        Next
    End Sub
End Class


'===============================================================================


' Settings information class
Friend Class SettingsInfo
    Inherits TagInfo
    ' XML tag name
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "settings"
        End Get
    End Property
    ' Internal instance of user info
    Private myUser As New UserInfo
    ' Read-only access to user info object
    Public ReadOnly Property User As UserInfo
        Get
            Return myUser
        End Get
    End Property
    ' Internal instance of job info
    Private myJob As New JobInfo
    ' Read-only access to job info
    Public ReadOnly Property Job As JobInfo
        Get
            Return myJob
        End Get
    End Property
    ' Internal instance of dates collection
    Private myDates As New DateCollection
    ' Read-only access to dates collection
    Public ReadOnly Property Dates As DateCollection
        Get
            Return myDates
        End Get
    End Property
    ' Internal instance of paths collection
    Private myPaths As New PathCollection
    ' Read-only access to paths collection
    Public ReadOnly Property Paths As PathCollection
        Get
            Return myPaths
        End Get
    End Property
    ' Initialize settings to prepare for a new job
    Public Sub Init()
        myUser.Name = Environ("USERNAME")
        myUser.Domain = Environ("USERDOMAIN")
        Dim createDate As New DateInfo
        myDates.Clear()
        createDate.InitNow(DateInfo.NameEnum.Created)
        myDates.Add(createDate)
        LoadPaths()
    End Sub
    ' Load everything from job settings file
    Public Sub Load()
        User.Load()
        Job.Load()
        LoadDates()
        LoadPaths()
    End Sub
    ' Load dates from job settings file
    Public Sub LoadDates()
        Dim createDate As New DateInfo
        createDate.Load(DateInfo.NameEnum.Created)
        myDates.Add(createDate)
        Dim compDate As New DateInfo
        compDate.Load(DateInfo.NameEnum.Completed)
        myDates.Add(compDate)
    End Sub
    ' Load paths from job settings file
    Public Sub LoadPaths()
        Dim pathSrc As New PathInfo
        pathSrc.Load(PathInfo.NameEnum.Source)
        myPaths.Add(pathSrc)
        Dim pathDst As New PathInfo
        pathDst.Load(PathInfo.NameEnum.Target)
        myPaths.Add(pathDst)
    End Sub
    ' Save everything to job settings file
    Public Sub Save()
        User.Save()
        Job.Save()
        SaveDates()
        SavePaths()
    End Sub
    ' Save dates to job settings file
    Public Sub SaveDates()
        Dim item As DateInfo
        For Each item In myDates
            item.Save()
        Next
    End Sub
    ' Save paths tp job settings file
    Public Sub SavePaths()
        Dim item As PathInfo
        For Each item In myPaths
            item.Save()
        Next
    End Sub
    ' Read XML node into this object's members
    Public Sub ReadXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        Dim nodeUser As Xml.XmlNode = node.SelectSingleNode(myUser.Tag)
        If nodeUser IsNot Nothing Then
            myUser.ReadXml(nodeUser)
        Else
            ThrowMissingElement(myUser.Tag)
        End If
        Dim nodeJob As Xml.XmlNode = node.SelectSingleNode(myJob.Tag)
        If nodeJob IsNot Nothing Then
            myJob.ReadXml(nodeJob)
        Else
            ThrowMissingElement(myJob.Tag)
        End If
        myDates.Clear()
        Dim nodeCreateDate As Xml.XmlNode
        Dim queryArg As String = QuoteText("created")
        Dim query As String = "date@name=" + queryArg
        nodeCreateDate = node.SelectSingleNode(query)
        If nodeCreateDate IsNot Nothing Then
            Dim dt As New DateInfo
            dt.ReadXml(nodeCreateDate)
            myDates.Add(dt)
        Else
            ThrowMissingElement(query)
        End If
        Dim nodeCompDate As Xml.XmlNode
        queryArg = QuoteText("completed")
        query = "date@name=" + queryArg
        nodeCompDate = node.SelectSingleNode(query)
        If nodeCompDate IsNot Nothing Then
            Dim dt As New DateInfo
            dt.ReadXml(nodeCompDate)
            myDates.Add(dt)
        Else
            ThrowMissingElement(query)
        End If
        myPaths.Clear()
        Dim nodeSrcPath As Xml.XmlNode
        queryArg = QuoteText("source")
        query = "path@name=" + query
        nodeSrcPath = node.SelectSingleNode(query)
        If nodeSrcPath IsNot Nothing Then
            Dim pa As New PathInfo
            pa.ReadXml(nodeSrcPath)
            myPaths.Add(pa)
        End If
        Dim nodeDstPath As Xml.XmlNode
        queryArg = QuoteText("target")
        query = "path@name=" + query
        nodeDstPath = node.SelectSingleNode(query)
        If nodeDstPath IsNot Nothing Then
            Dim pa As New PathInfo
            pa.ReadXml(nodeDstPath)
            myPaths.Add(pa)
        End If
    End Sub
    ' Write XML node from this object's members
    Public Sub WriteXml(node As Xml.XmlNode)
        CheckXmlTagName(node, Me.Tag)
        CheckXmlDocument(node, node.Name)
        Dim doc As Xml.XmlDocument = node.OwnerDocument
        Dim nodeUser As Xml.XmlElement = doc.CreateElement(myUser.Tag)
        myUser.WriteXml(nodeUser)
        node.AppendChild(nodeUser)
        Dim nodeJob As Xml.XmlElement = doc.CreateElement(myJob.Tag)
        myJob.WriteXml(nodeJob)
        node.AppendChild(nodeJob)
        ' TODO...
    End Sub
End Class

' Pixie document information information class
Friend Class PixieJob
    Inherits TagInfo
    ' Tag property
    Public Overrides ReadOnly Property Tag As String
        Get
            Return "pixie"
        End Get
    End Property
    ' XML version
    Public ReadOnly Property XmlVersion As Integer
        Get
            Return 1
        End Get
    End Property
    ' The internal instance of the XML document which stores the hierarchy
    Private myDocument As New Xml.XmlDocument
    ' Readonly access to internal XML document object
    Public ReadOnly Property XmlDoc As Xml.XmlDocument
        Get
            Return myDocument
        End Get
    End Property
    ' Readonly access to XML root element
    Public ReadOnly Property RootElem As Xml.XmlElement
        Get
            Return XmlDoc.FirstChild
        End Get
    End Property
    ' Internal settings object
    Private mySettings As New SettingsInfo
    ' Readonly access to internal settings object
    Public ReadOnly Property Settings As SettingsInfo
        Get
            Return mySettings
        End Get
    End Property
    ' Internal folder object
    Private myFolder As New FolderInfo
    ' Readonly access to internal folder object
    Public ReadOnly Property Folder As FolderInfo
        Get
            Return myFolder
        End Get
    End Property
    ' Initialize
    Public Sub Init(jobType As NCS.JobTypeEnum)
        NCS.JobType = jobType
        NCS.UserName = Environ("USERNAME")
        NCS.UserDomain = Environ("USERDOMAIN")

        Select Case jobType
            Case NCS.JobTypeEnum.ComputerToRemovable

            Case NCS.JobTypeEnum.RemovableToComputer

            Case NCS.JobTypeEnum.Backup

            Case NCS.JobTypeEnum.Restore

            Case Else
        End Select
        mySettings.Init()
        myFolder.Init()
    End Sub
    ' Create and append XML declation node <?xml version="..." ?>
    Private Function AppendDeclaration(version As String) As Xml.XmlDeclaration
        Dim declNode As Xml.XmlDeclaration
        declNode = myDocument.CreateXmlDeclaration("1.0", Nothing, Nothing)
        myDocument.AppendChild(declNode)
        Return declNode
    End Function
    ' Create and append the root element <pixie />
    Private Function AppendRootElement() As Xml.XmlElement
        Dim rootElem As Xml.XmlElement
        rootElem = myDocument.CreateElement(Me.Tag)
        myDocument.AppendChild(rootElem)
        Return rootElem
    End Function
    ' Initialize the job
    Public Function InitializeXml() As Boolean
        myDocument.RemoveAll()
        AppendDeclaration("1.0")
        AppendRootElement()
        Return True
    End Function

End Class

