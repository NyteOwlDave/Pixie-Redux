﻿
' Represents a collection of UserAccounts
Public Class UserAccountCollection

    ' Internal storage for user accounts
    Private myAccounts As New Collection

    ' Removes all accounts from the collection
    Public Sub Clear()
        myAccounts.Clear()
    End Sub

    ' Add an account
    Public Sub Add(acct As UserAccount)
        If acct Is Nothing Then
            Throw New Exception("User account object cannot be nothing.")
        End If
        If Not Contains(acct) Then
            myAccounts.Add(acct, acct.ID.ToString())
        End If
    End Sub

#Region "Determine if index/key/id/object is contained in collection"

    ' Determine if index is valid
    Public Function Contains(index As Integer) As Boolean
        If index < 1 Then Return False
        If index > myAccounts.Count Then Return False
        Return True
    End Function

    ' Determine if account with specified key exists in collection
    Public Function Contains(key As String) As Boolean
        Return myAccounts.Contains(key)
    End Function

    ' Determine if account with specified ID exists in collection
    Public Function Contains(id As Guid) As Boolean
        Dim key As String = id.ToString()
        Return Contains(key)
    End Function

    ' Determine if an account with the same ID exists in collection
    Public Function Contains(acct As UserAccount) As Boolean
        If acct Is Nothing Then Return False
        Dim key As String = acct.ID.ToString()
        Return Contains(key)
    End Function

#End Region

#Region "Item Counts"

    ' Number of accounts in collection
    Public ReadOnly Property Count As Integer
        Get
            Return myAccounts.Count
        End Get
    End Property

    ' Number of accounts matching the specified title
    Public ReadOnly Property CountByTitle(title As String) As Integer
        Get
            Dim found As Integer = 0
            Dim index As Integer = 1
            Dim last As Integer = Count
            For index = index To last
                Dim acct As UserAccount = myAccounts.Item(index)
                If acct.Title = title Then
                    found += 1
                End If
            Next
            Return found
        End Get
    End Property

    ' Number of accounts matching the specified username
    Public ReadOnly Property CountByUserName(userName As String) As Integer
        Get
            Dim found As Integer = 0
            Dim index As Integer = 1
            Dim last As Integer = Count
            For index = index To last
                Dim acct As UserAccount = myAccounts.Item(index)
                If acct.UserName = userName Then
                    found += 1
                End If
            Next
            Return found
        End Get
    End Property

    ' Number of accounts matching the specified password
    Public ReadOnly Property CountByPassword(password As String) As Integer
        Get
            Dim found As Integer = 0
            Dim index As Integer = 1
            Dim last As Integer = Count
            For index = index To last
                Dim acct As UserAccount = myAccounts.Item(index)
                If acct.Password = password Then
                    found += 1
                End If
            Next
            Return found
        End Get
    End Property

    ' Number of accounts matching the specified pin
    Public ReadOnly Property CountByPIN(pin As String) As Integer
        Get
            Dim found As Integer = 0
            Dim index As Integer = 1
            Dim last As Integer = Count
            For index = index To last
                Dim acct As UserAccount = myAccounts.Item(index)
                If acct.PIN = pin Then
                    found += 1
                End If
            Next
            Return found
        End Get
    End Property

    ' Number of accounts matching the specified site
    Public ReadOnly Property CountBySite(site As String) As Integer
        Get
            Dim found As Integer = 0
            Dim index As Integer = 1
            Dim last As Integer = Count
            For index = index To last
                Dim acct As UserAccount = myAccounts.Item(index)
                If acct.Site = site Then
                    found += 1
                End If
            Next
            Return found
        End Get
    End Property

#End Region

#Region "Lookup Items"

    ' Lookup account by index
    Public ReadOnly Property Item(index As Integer) As UserAccount
        Get
            If index < 1 Then Return Nothing
            If index > myAccounts.Count Then Return Nothing
            Return myAccounts.Item(index)
        End Get
    End Property

    ' Lookup account by key
    Public ReadOnly Property Item(key As String) As UserAccount
        Get
            Return myAccounts.Item(key)
        End Get
    End Property

    ' Lookup account by ID
    Public ReadOnly Property Item(id As Guid) As UserAccount
        Get
            If Not Contains(id) Then Return Nothing
            Dim key As String = id.ToString()
            Return myAccounts.Item(key)
        End Get
    End Property

    ' Lookup account with same ID as specified account
    Public ReadOnly Property Item(acct As UserAccount) As UserAccount
        Get
            If Not Contains(acct) Then Return Nothing
            Dim key As String = acct.ID.ToString()
            Return myAccounts.Item(key)
        End Get
    End Property

    ' Lookup accounts by title
    Public Function GetAccountsByTitle(title As String) As UserAccountCollection
        Dim index As Integer = 1
        Dim last As Integer = Count
        Dim accts As New UserAccountCollection
        For index = index To last
            Dim acct As UserAccount = myAccounts.Item(index)
            If acct.Title = title Then
                accts.Add(acct)
            End If
        Next
        Return accts
    End Function

    ' Lookup accounts by user name
    Public Function GetAccountsByUserName(userName As String) As UserAccountCollection
        Dim index As Integer = 1
        Dim last As Integer = Count
        Dim accts As New UserAccountCollection
        For index = index To last
            Dim acct As UserAccount = myAccounts.Item(index)
            If acct.UserName = userName Then
                accts.Add(acct)
            End If
        Next
        Return accts
    End Function

    ' Lookup accounts by password
    Public Function GetAccountsByPassword(password As String) As UserAccountCollection
        Dim index As Integer = 1
        Dim last As Integer = Count
        Dim accts As New UserAccountCollection
        For index = index To last
            Dim acct As UserAccount = myAccounts.Item(index)
            If acct.Password = password Then
                accts.Add(acct)
            End If
        Next
        Return accts
    End Function

    ' Lookup accounts by pin
    Public Function GetAccountsByPIN(pin As String) As UserAccountCollection
        Dim index As Integer = 1
        Dim last As Integer = Count
        Dim accts As New UserAccountCollection
        For index = index To last
            Dim acct As UserAccount = myAccounts.Item(index)
            If acct.PIN = pin Then
                accts.Add(acct)
            End If
        Next
        Return accts
    End Function

    ' Lookup accounts by site
    Public Function GetAccountsBySite(site As String) As UserAccountCollection
        Dim index As Integer = 1
        Dim last As Integer = Count
        Dim accts As New UserAccountCollection
        For index = index To last
            Dim acct As UserAccount = myAccounts.Item(index)
            If acct.Site = site Then
                accts.Add(acct)
            End If
        Next
        Return accts
    End Function

#End Region

#Region "Diagnostic Reporting"

    ' Diagnostic dump to collection
    Public Function Dump() As Collection
        Dim all As New Collection
        all.Add("Total accounts: " & myAccounts.Count)
        Dim cdump As Collection
        Dim line As String
        Dim acct As UserAccount
        For Each acct In myAccounts
            cdump = acct.Dump()
            For Each line In cdump
                all.Add(line)
            Next
        Next
        Return all
    End Function

    ' Diagnostic dump to text document (string)
    Public Overrides Function ToString() As String
        Dim s As String = ""
        Dim c As Collection = Me.Dump()
        Dim line As String
        For Each line In c
            s += line + ControlChars.NewLine
        Next
        Return s
    End Function

    ' Diagnostic dump via popup dialog
    Public Sub Report()
        Dim msg As String = Me.ToString()
        ShowInfoBox(msg)
    End Sub

    ' Diagnostic dump to log file, open with Explorer
    Public Sub Explore()
        Dim name As String = Logging.GetJobLogTempPathName()
        Dim log As New JobLog(name)
        Dim c As Collection = Me.Dump()
        Dim line As String
        For Each line In c
            log.Add(line)
        Next
        If log.SaveLogFile() Then
            ShellModule.Explore(name)
        End If
    End Sub

#End Region

End Class

