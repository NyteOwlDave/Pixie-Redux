﻿
' Parses a comma separated value (CSV) record into a collection
Public Class CSVParser

    ' Simple array of items
    Private myColumns As New Collections.ArrayList

    ' Get count
    Public ReadOnly Property Count As Integer
        Get
            Return myColumns.Count
        End Get
    End Property

    ' Clear the array
    Public Sub Clear()
        myColumns.Clear()
    End Sub

    ' Add an element to the array
    Public Sub Add(item As Object)
        myColumns.Add(item)
    End Sub

    ' Determine if an item is already in the array
    Public Function Contains(item As Object) As Boolean
        Return myColumns.Contains(item)
    End Function

    ' Obtains the item at the specified index
    Public ReadOnly Property Item(index As Integer) As Object
        Get
            If (index < 1) Then
                Return Nothing
            End If
            If index > Count Then
                Return Nothing
            End If
            Return myColumns.Item(index)
        End Get
    End Property

    ' Shared helper to quote a string
    Public Shared Function Quote(item As String) As String
        Return ChrW(34) + item + ChrW(34)
    End Function

    ' Shared helper to unquote a string
    Public Shared Function UnQuote(item As String) As String
        Dim length As Integer = item.Length
        If length < 2 Then
            Return item
        End If
        Return item.Substring(1, length - 2)
    End Function

    ' Helper function to determine if a string is quoted
    Public Function IsQuoted(item As String) As Boolean
        If item Is Nothing Then Return False
        If item.Length < 2 Then Return False
        If item.ElementAt(0) <> ChrW(34) Then Return False
        If item.ElementAt(item.Length - 1) <> ChrW(34) Then Return False
        Return True
    End Function

    ' Throw data type not supported exception
    Public Sub ThrowNotSupported(vt As VariantType)
        Dim msg As String
        msg = "Fields of type " & vt.ToString() & " can't be saved as a CSV field."
        Throw New NotSupportedException(msg)
    End Sub

    ' Split a CSV line into individual fields and store then in the array
    Public Sub Split(line As String)
        Clear()
        If line Is Nothing Then Return
        line = line.Trim()
        If line.Length < 1 Then Return
        Dim length As Integer = length
        Dim i1 As Integer = 0
        Dim i2 As Integer = 0
        Dim ch As Char = ChrW(0)
        Dim field As String
        While i1 < length
            field = ""
            ch = line.ElementAt(i1)
            If ch = ChrW(34) Then
                i2 = length - 1
                Dim extra As Integer = i2 - i1
                If extra < 1 Then
                    Return
                End If
                Dim ch2 As Char = ChrW(0)
                i1 += 1
                While i1 <= i2
                    ch2 = line.ElementAt(i1)
                    If ch2 = ChrW(34) Then
                        Exit While
                    End If
                    field = field & ch2
                    i1 += 1
                End While
                Add(field)
                i1 += 1
                Continue While
            End If
            If ch = "," Then
                Add(ConvertItem(field))
                i1 += 1
                Continue While
            End If
            field = field & ch
            i1 += 1
        End While
    End Sub

    ' Helper function to determine if a character is a decimal digit
    Private Function IsDigit(ch As Char) As Boolean
        If ch < "0" Or ch > "9" Then Return False
        Return True
    End Function

    ' Helper function to determine of a string contains only decimal
    ' digits
    Private Function IsNumber(item As String) As Boolean
        If item Is Nothing Then Return False
        Dim len As Integer = item.Length
        If len < 1 Then Return False
        Dim pos As Integer = 0
        Dim ch As Char = item.ElementAt(pos)
        If ch = "-" Then
            If len < 2 Then
                Return False
            End If
            pos += 1
            ch = item.ElementAt(pos)
        End If
        Dim foundDecPt As Boolean = False
        Dim foundExp As Boolean = False
        Dim foundExpSgn As Boolean = False
        If Not IsDigit(ch) Then Return False
        For pos = pos + 1 To len - 1
            ch = item.ElementAt(pos)
            If Not IsDigit(ch) Then
                If ch = "." Then
                    If foundDecPt Then
                        Return False
                    Else
                        foundDecPt = True
                        Continue For
                    End If
                End If
                If foundDecPt Then
                    If ch = "d" Or ch = "e" Then
                    End If
                Else
                    ' TODO...
                End If
            End If
        Next
        Return True
    End Function

    ' Convert string to typed object
    Private Function ConvertItem(item As String) As Object
        If IsNumber(item) Then
            Return CDbl(item)
        End If
        Return item
    End Function

    ' Merge fields stored in the array into a CSV line
    Public Function Merge() As String
        Dim item As Object
        Dim vt As VariantType
        Dim field As String = ""
        Dim line As String = ""
        Dim first As Boolean = True
        For Each item In myColumns
            vt = VarType(item)
            Select Case vt
                Case VariantType.Boolean, VariantType.Byte, VariantType.Char
                    field = CStr(item)
                Case VariantType.Currency, VariantType.Date, VariantType.Decimal
                    field = CStr(item)
                Case VariantType.Double, VariantType.Integer, VariantType.Long
                    field = CStr(item)
                Case VariantType.Short, VariantType.Single
                    field = CStr(item)
                Case VariantType.String
                    field = Quote(item)
                Case Else
                    ' Case VariantType.Array
                    ' Case VariantType.DataObject
                    ' Case VariantType.Empty
                    ' Case VariantType.Error
                    ' Case VariantType.Null
                    ' Case VariantType.Object
                    ' Case VariantType.UserDefinedType
                    ' Case VariantType.Variant
                    field = ""
                    ThrowNotSupported(vt)
                    Return line
            End Select
            If first Then
                line = field
                first = False
            Else
                line = line & "," & field
            End If
        Next
        Return line
    End Function

End Class

