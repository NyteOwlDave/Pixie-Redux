﻿
' User account class
Public NotInheritable Class UserAccount

#Region "Properties"

    ' Default title
    Private Const DefaultTitle As String = "New Account"

    ' Internal storage for title
    Private myTitle As String = DefaultTitle

    ' Helper to prettify title
    Protected Function PrettifyTitle(title As String) As String
        If title Is Nothing Then
            Return DefaultTitle
        Else
            title = title.Trim()
        End If
        If title.Length < 1 Then
            Return DefaultTitle
        End If
        Return title
    End Function

    ' Account title (required)
    Public Property Title As String
        Get
            Return myTitle
        End Get
        Set(value As String)
            myTitle = PrettifyTitle(value)
        End Set
    End Property

    ' Shared helper function to determine username for this computer
    Public Shared Function GetUserName() As String
        Dim name As String = Environ("USERNAME")
        If name Is Nothing Then
            name = ""
        Else
            name = name.Trim()
        End If
        If name.Length < 1 Then
            name = "?"
        End If
        Return name
    End Function

    ' Helper to prettify user name
    Protected Function PrettifyUserName(name As String) As String
        If name Is Nothing Then
            name = ""
        Else
            name = name.Trim()
        End If
        If name.Length < 1 Then
            Return GetUserName()
        End If
        Return name
    End Function

    ' Internal storage for username
    Private myName As String = ""

    ' User name (required)
    Public Property UserName As String
        Get
            If myName.Length < 1 Then
                myName = GetUserName()
            End If
            Return myName
        End Get
        Set(value As String)
            myName = PrettifyUserName(value)
        End Set
    End Property

    ' Internal storage for site
    Private mySite As String = ""

    ' Site (required)
    Public Property Site As String
        Get
            If mySite.Length < 1 Then
                mySite = My.Settings.DaveWellstedDotNet
            End If
            Return mySite
        End Get
        Set(value As String)
            If value Is Nothing Then value = ""
            If value.Length < 1 Then
                mySite = My.Settings.DaveWellstedDotNet
            Else
                mySite = value
            End If
        End Set
    End Property

    ' Internal storage for ID
    Private myID As Guid

    ' Unique identifier for the account (required)
    Public Property ID As Guid
        Get
            If myID.Equals(Guid.Empty) Then
                myID = Guid.NewGuid()
            End If
            Return myID
        End Get
        Set(value As Guid)
            If value.Equals(Guid.Empty) Then
                myID = Guid.NewGuid()
            Else
                myID = value
            End If
        End Set
    End Property

    ' Prettify optional text tring
    Public Function PrettifyText(text As String) As String
        If text Is Nothing Then
            Return ""
        Else
            Return text.Trim()
        End If
    End Function

    ' Internal storage for password
    Private myPassword As String = ""

    ' Password (optional)
    Public Property Password As String
        Get
            Return myPassword
        End Get
        Set(value As String)
            myPassword = PrettifyText(value)
        End Set
    End Property

    ' Internal storage for PIN
    Private myPIN As String = ""

    ' PIN (optional)
    Public Property PIN As String
        Get
            Return myPIN
        End Get
        Set(value As String)
            myPIN = PrettifyText(value)
        End Set
    End Property

    ' Whether the account is considered active (optional)
    Public Property Active As Boolean = False

    ' Get default creator (optional)
    Private Function GetDefaultCreator() As String
        Dim dom As String
        Dim usr As String
        Try
            dom = Environ("USERDOMAIN")
            If dom Is Nothing Then dom = ""
        Catch ex As Exception
            dom = ""
        End Try
        Try
            usr = Environ("USERNAME")
            If usr Is Nothing Then usr = ""
        Catch ex As Exception
            usr = ""
        End Try
        If dom.Length < 1 Then
            If usr.Length < 1 Then
                Return ""
            Else
                Return usr
            End If
        Else
            If usr.Length > 1 Then
                Return dom & "/" & usr
            Else
                Return usr
            End If
        End If
    End Function

    ' Internal storage for creator
    Private myCreator As String = ""

    ' Name of the person who created the account (optional)
    Public Property Creator As String
        Get
            Return myCreator
        End Get
        Set(value As String)
            value = PrettifyText(value)
            If value.Length < 1 Then
                myCreator = GetDefaultCreator()
            Else
                myCreator = value
            End If
        End Set
    End Property

    ' Internal storage for date created
    Private myDateCreated As Date = Date.Now

    ' Date the account was created (optional)
    Public Property DateCreated As Date
        Get
            Return myDateCreated
        End Get
        Set(value As Date)
            If value.ToBinary() = 0 Then
                value = Date.Now()
            End If
            myDateCreated = value
        End Set
    End Property

    ' Internal storage for comments
    Private myComments As String = ""

    ' Comments
    Public Property Comments As String
        Get
            Return myComments
        End Get
        Set(value As String)
            value = PrettifyText(value)
        End Set
    End Property

#Region "Additional properties that have no associated XML attribute"

    ' Pathname to image file on local file system
    Public Property ImagePath As String = ""

    ' Image object stored in memory
    Public Property ImageObject As Image = Nothing

    ' Any extra stuff the program might need to attach to the object
    Public Property Tag As Object = Nothing

#End Region

#End Region

#Region "Instantiation"

    ' New user account (auto-generated)
    Public Sub New()
        AddJobLogEntry("Auto-generated new user account.")
    End Sub

    ' New user account (read from XmlNode)
    Public Sub New(node As Xml.XmlNode)
        ReadXml(node)
    End Sub

    ' New user account (from discrete values)
    Public Sub New(id As Guid, title As String, userName As String, site As String)
        Me.ID = id
        Me.Title = title
        Me.UserName = userName
        Me.Site = site
        AddJobLogEntry("Created new user account for: " & Me.Title)
    End Sub

#End Region

#Region "Reporting"

    ' Diagnostic dump to a collection of strings
    Public Function Dump() As Collection
        Dim log As New Collection
        log.Add("ID = " & Me.ID.ToString())
        log.Add("Title = " & Me.Title)
        log.Add("Site = " & Me.Site)
        log.Add("UserName = " & Me.UserName)
        log.Add("Password = " & Me.Password)
        log.Add("PIN = " & Me.PIN)
        log.Add("Active = " & CStr(Me.Active))
        log.Add("Creator = " & Me.Creator)
        log.Add("DateCreated = " & Me.DateCreated)
        Return log
    End Function

    ' Diagnostic dump to single string (text document)
    Public Overrides Function ToString() As String
        Dim s As String = ""
        Dim c As Collection
        c = Dump()
        Dim n As Integer
        For n = 1 To c.Count
            s += c.Item(n) + ControlChars.NewLine
        Next
        Return s
    End Function

    ' Diagnostic dump via dialog
    Public Sub Report()
        Dim s As String = Me.ToString()
        ShowInfoBox(s)
    End Sub

    ' Diagnostic dump to temp log file, then open via Explorer
    Public Sub Explore()
        Dim name As String = GetJobLogTempPathName()
        Dim log As New JobLog(name)
        Dim c As Collection = Me.Dump()
        Dim line As String
        For Each line In c
            log.Add(line)
        Next
        If Not log.SaveLogFile() Then
            Return
        End If
        ShellModule.Explore(name)
    End Sub

#End Region

#Region "Read/Write XML node"

    ' Throw exception: node has the wrong XML tag name
    Private Sub ThrowWrongTag()
        Dim msg As String = "Source XML node's name must be <account>."
        Throw New Exception(msg)
    End Sub

    ' Throw exception: node is nothing
    Private Sub ThrowMissingNode()
        Dim msg As String = "Source XML node cannot be nothing."
        Throw New Exception(msg)
    End Sub

    ' Throw exception: parent node is nothing
    Private Sub ThrowMissingParentNode()
        Dim msg As String = "Source XML parent node cannot be nothing."
        Throw New Exception(msg)
    End Sub

    ' Throw exception: node is nothing
    Private Sub ThrowMissingDocument()
        Dim msg As String = "Source XML parent node is not attached to a document."
        Throw New Exception(msg)
    End Sub

    ' Validate node
    Private Sub ValidateNode(node As Xml.XmlNode)
        If node Is Nothing Then
            ThrowMissingNode()
            Return ' Redundant
        End If
        If node.Name.ToLower() <> "account" Then
            ThrowWrongTag()
            Return ' Redundant
        End If
    End Sub

    ' Validate parent node
    Private Sub ValidateParent(nodeParent As Xml.XmlNode)
        If nodeParent Is Nothing Then
            ThrowMissingParentNode()
            Return ' Redundant
        End If
        If nodeParent.OwnerDocument Is Nothing Then
            ThrowMissingDocument()
            Return ' Redundant
        End If
    End Sub

    ' Read information from an XML node
    Public Sub ReadXml(node As Xml.XmlNode)
        Try
            AddJobLogEntry("Reading XML account node")
            ValidateNode(node)
            AddJobLogEntry("tag = " & node.Name)
            Dim attr As Xml.XmlAttribute = Nothing
            ' Title (required)
            Try
                attr = node.Attributes.GetNamedItem("title")
                Me.Title = attr.Value
            Catch ex As Exception
                Throw New Exception("Missing title attribute", ex)
            End Try
            ' Name (required)
            Try
                attr = node.Attributes.GetNamedItem("user")
                Me.UserName = attr.Value
            Catch ex As Exception
                Throw New Exception("Missing user attribute", ex)
            End Try
            ' Site (required)
            Try
                attr = node.Attributes.GetNamedItem("site")
                Me.Site = attr.Value
            Catch ex As Exception
                Throw New Exception("Missing site attribute", ex)
            End Try
            ' Password (optional)
            Try
                attr = node.Attributes.GetNamedItem("pass")
                If Not attr Is Nothing Then
                    Me.Password = attr.Value
                Else
                    Me.Password = ""
                End If
            Catch ex As Exception
                Throw New Exception("Error reading password", ex)
            End Try
            ' PIN (optional)
            Try
                attr = node.Attributes.GetNamedItem("pin")
                If Not attr Is Nothing Then
                    Me.PIN = attr.Value
                Else
                    Me.PIN = ""
                End If
            Catch ex As Exception
                Throw New Exception("Error reading pin", ex)
            End Try
            ' Active (optional)
            Try
                attr = node.Attributes.GetNamedItem("active")
                If Not attr Is Nothing Then
                    Me.Active = attr.Value
                Else
                    Me.Active = True
                End If
            Catch ex As Exception
                Throw New Exception("Error reading active flag", ex)
            End Try
            ' Creator (optional)
            Try
                attr = node.Attributes.GetNamedItem("creator")
                If Not attr Is Nothing Then
                    Me.Creator = attr.Value
                Else
                    Me.Creator = ""
                End If
            Catch ex As Exception
                Throw New Exception("Error reading creator", ex)
            End Try
            ' DateCreated (optional)
            Try
                attr = node.Attributes.GetNamedItem("datecreated")
                If Not attr Is Nothing Then
                    Me.DateCreated = attr.Value
                Else
                    Me.DateCreated = Date.Now()
                End If
            Catch ex As Exception
                Throw New Exception("Error reading date created", ex)
            End Try
            ' ID (optional)
            Try
                attr = node.Attributes.GetNamedItem("id")
                If Not attr Is Nothing Then
                    Me.ID = New Guid(attr.Value)
                Else
                    Me.ID = Guid.NewGuid()
                End If
            Catch ex As Exception
                Throw New Exception("Error reading id", ex)
            End Try
        Catch ex As Exception
            AddJobLogEntry(ex)
            Throw ex
        End Try
    End Sub

    ' Write information to an XML node
    Public Sub WriteXml(nodeParent As Xml.XmlNode)
        Try
            AddJobLogEntry("Writing XML account node")
            ValidateParent(nodeParent)
            Dim doc As New Xml.XmlDocument
            doc = nodeParent.OwnerDocument
            AddJobLogEntry("owner doc = " & doc.Name)
            AddJobLogEntry("parent tag = " & nodeParent.Name)
            Dim elem As Xml.XmlElement = doc.CreateElement("account")
            Dim attr As Xml.XmlAttribute = Nothing
            ' Title
            attr = doc.CreateAttribute("title")
            attr.Value = Me.Title
            elem.Attributes.SetNamedItem(attr)
            ' User name
            attr = doc.CreateAttribute("user")
            attr.Value = Me.UserName
            elem.Attributes.SetNamedItem(attr)
            ' Password
            attr = doc.CreateAttribute("pass")
            attr.Value = Me.Password
            elem.Attributes.SetNamedItem(attr)
            ' PIN
            attr = doc.CreateAttribute("pin")
            attr.Value = Me.PIN
            elem.Attributes.SetNamedItem(attr)
            ' Location
            attr = doc.CreateAttribute("site")
            attr.Value = Me.Site
            elem.Attributes.SetNamedItem(attr)
            ' Active
            attr = doc.CreateAttribute("active")
            attr.Value = Me.Active
            elem.Attributes.SetNamedItem(attr)
            ' Creator
            attr = doc.CreateAttribute("creator")
            attr.Value = Me.Creator
            elem.Attributes.SetNamedItem(attr)
            ' DateCreated
            attr = doc.CreateAttribute("datecreated")
            attr.Value = Me.DateCreated
            elem.Attributes.SetNamedItem(attr)
            ' ID
            attr = doc.CreateAttribute("id")
            attr.Value = Me.ID.ToString()
            elem.Attributes.SetNamedItem(attr)
            ' Comments
            Dim cdata As Xml.XmlCDataSection
            cdata = doc.CreateCDataSection(Me.Comments)
            elem.AppendChild(cdata)
            ' Append node to parent node
            nodeParent.AppendChild(elem)
        Catch ex As Exception
            AddJobLogEntry(ex)
            Throw ex
        End Try
    End Sub

#End Region

#Region "Import/Export CSV record "

    ' Import imformation from CSV format
    Public Sub ImportCSV(line As String)
        Throw New NotImplementedException("ImportCSV method needs coded!")
        ' TODO...
    End Sub

    ' Export information in CSV format
    Public Function ExportCSV() As String
        Throw New NotImplementedException("ExportCSV method needs coded!")
        Dim line As String = ""
        ' TODO...
        Return line
    End Function

#End Region

End Class

