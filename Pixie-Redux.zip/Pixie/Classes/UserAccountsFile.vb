﻿

' Represents an XML file for user accounts
Public Class UserAccountXmlFile

    ' Internal instance of XML document
    Private myDoc As New Xml.XmlDocument

    ' Readonly access to XML document
    Public ReadOnly Property Document As Xml.XmlDocument
        Get
            Return myDoc
        End Get
    End Property

    ' Enclose a string using the specified opener/closer characters
    Public Function EncloseText(text As String, opener As Char, closer As Char) As String
        Return opener + text + closer
    End Function

    ' Enclose a string in single quotes
    Public Function SingleQuoteText(text As String) As String
        Return EncloseText(text, "'", "'")
    End Function

    ' Enclose a string in square brackets
    Public Function BracketText(text As String) As String
        Return EncloseText(text, "[", "]")
    End Function

    ' Enclose a string in square brackets
    Public Function BuildAttrQuery(app As String, group As String) As String
        Dim attr As String = "@app=" + SingleQuoteText(app)
        attr += " And @group=" + SingleQuoteText(group)
        Return BracketText(attr)
    End Function

    ' Read XML file
    ' app is typically "Pixie" or "prototypes"
    ' but the XML file can store any number of <accounts> nodes, each
    ' having an app="xxx" attribute to distinguish the owner application
    ' for that particular group of user accounts.
    Public Function ReadFile(url As String, app As String, group As String) As UserAccountCollection
        Dim accts As New UserAccountCollection
        Try
            AddJobLogEntry("Reading user account XML file from site:")
            AddJobLogEntry(url)
            myDoc.RemoveAll()
            myDoc.Load(url)
            AddJobLogEntry("Success!")
        Catch ex As Exception
            AddJobLogEntry(ex)
            Throw ex
        End Try
        Try
            AddJobLogEntry("Now reading elements.")
            Dim root As Xml.XmlElement = myDoc.DocumentElement
            If root Is Nothing Then
                Return accts
            End If
            If root.Name <> "xml" Then
                Throw New Exception("Top level node must be <xml>.")
            End If
            Dim query As String = "accounts" + BuildAttrQuery(app, group)
            Dim node As Xml.XmlNode = root.SelectSingleNode(query)
            If node Is Nothing Then
                Return accts
            End If
            Dim list As Xml.XmlNodeList
            list = node.SelectNodes("account")
            If list Is Nothing Then
                Return accts
            End If
            If list.Count < 1 Then
                Return accts
            End If
            Dim subNode As Xml.XmlNode
            For Each subNode In list
                Dim acct As New UserAccount
                acct.ReadXml(subNode)
            Next
            AddJobLogEntry("Success!")
        Catch ex As Exception
            AddJobLogEntry(ex)
            Throw ex
        End Try
        Return accts
    End Function

    ' Write XML file
    ' app is typically "Pixie" or "prototypes"
    ' but the XML file can store any number of <accounts> nodes, each
    ' having an app="xxx" attribute to distinguish the owner application
    ' for that particular group of user accounts.
    Public Sub WriteXml(url As String, app As String, group As String, accts As UserAccountCollection)
        Try
            AddJobLogEntry("Writing user account XML file to site:")
            AddJobLogEntry(url)
            Dim root As Xml.XmlElement = myDoc.DocumentElement
            If root Is Nothing Then
                root = myDoc.CreateElement("xml")
                myDoc.AppendChild(root)
            End If
            Dim query As String = "accounts" + BuildAttrQuery(app, group)
            Dim acctsNode = root.SelectSingleNode(query)
            If acctsNode Is Nothing Then
                acctsNode = myDoc.CreateElement("accounts")
                Dim attr As Xml.XmlAttribute
                attr = myDoc.CreateAttribute("app")
                attr.Value = app
                acctsNode.Attributes.SetNamedItem(attr)
                attr = myDoc.CreateAttribute("group")
                attr.Value = group
                acctsNode.Attributes.SetNamedItem(attr)
                root.AppendChild(acctsNode)
            Else
                acctsNode.RemoveAll()
            End If
            Dim acct As UserAccount
            Dim first As Integer = 1
            Dim final As Integer = accts.Count
            Dim index As Integer
            For index = first To final
                acct = accts.Item(index)
                acct.WriteXml(acctsNode)
            Next
            myDoc.Save(url)
            AddJobLogEntry("Success!")
        Catch ex As Exception
            AddJobLogEntry(ex)
            Throw ex
        End Try
    End Sub

End Class

