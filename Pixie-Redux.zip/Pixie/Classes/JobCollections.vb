﻿
' Collection of date info objects
Friend Class DateCollection
    Implements ICollection(Of DateInfo)

    ' Internal collection for storing dates
    Private myDates As New Collection

    ' How many dates are stored within
    Public ReadOnly Property Count As Integer Implements ICollection(Of DateInfo).Count
        Get
            Return myDates.Count
        End Get
    End Property

    ' We don't want to be readonly!
    Public ReadOnly Property IsReadOnly As Boolean Implements ICollection(Of DateInfo).IsReadOnly
        Get
            Return False
        End Get
    End Property

    ' Add date to collection
    Public Sub Add(item As DateInfo) Implements ICollection(Of DateInfo).Add
        If Contains(item) Then
            Remove(item)
        End If
        myDates.Add(item, item.Name)
    End Sub

    ' Clear the collection
    Public Sub Clear() Implements ICollection(Of DateInfo).Clear
        myDates.Clear()
    End Sub

    ' Copy to date array
    Public Sub CopyTo(array() As DateInfo, arrayIndex As Integer) Implements ICollection(Of DateInfo).CopyTo
        If array.Count < 1 Then
            Return
        End If
        If array.Rank > 1 Then
            Throw New System.NotSupportedException()
        End If
        Try
            Dim first As Integer = array.GetLowerBound(0)
            Dim last As Integer = array.GetUpperBound(0)
            Dim item As DateInfo
            For Each item In myDates
                If first > last Then
                    Exit For
                End If
                array.SetValue(item, first)
                first += 1
            Next
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Determine if date is within the collection
    Public Function Contains(item As DateInfo) As Boolean Implements ICollection(Of DateInfo).Contains
        Return myDates.Contains(item.Name)
    End Function

    ' Get enumerator
    Public Function GetEnumerator() As IEnumerator(Of DateInfo) Implements IEnumerable(Of DateInfo).GetEnumerator
        Return IEnumerable_GetEnumerator()
    End Function

    ' Remove item
    Public Function Remove(item As DateInfo) As Boolean Implements ICollection(Of DateInfo).Remove
        If Contains(item) Then
            myDates.Remove(item.Name)
            Return True
        End If
        Return False
    End Function

    ' Get item by index
    Public ReadOnly Property Item(index As Integer) As DateInfo
        Get
            If Count < 1 Then Return Nothing
            If Count <= index Then Return Nothing
            Return myDates.Item(index)
        End Get
    End Property

    ' Get index of specified item
    Public Function GetIndexOf(key As String) As Integer
        If Count < 1 Then Return -1
        Dim n As Integer
        Dim di As DateInfo
        For n = 0 To Count - 1
            di = myDates.Item(n)
            If di.Name = key Then
                Return n
            End If
        Next
        Return -1
    End Function

    ' Get specified item
    Public Function GetItem(key As String) As DateInfo
        Dim index As Integer = GetIndexOf(key)
        If (index < 0) Then Return Nothing
        Return myDates.Item(index)
    End Function

    ' Get enumerator (internal)
    Private Function IEnumerable_GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return myDates.GetEnumerator
    End Function

End Class

' Collection of path info objects
Friend Class PathCollection
    Implements ICollection(Of PathInfo)

    ' Internal collection for storing paths
    Private myPaths As New Collection

    ' Number of paths in collection
    Public ReadOnly Property Count As Integer Implements ICollection(Of PathInfo).Count
        Get
            Return myPaths.Count
        End Get
    End Property

    ' We do NOT want a read-only collection!
    Public ReadOnly Property IsReadOnly As Boolean Implements ICollection(Of PathInfo).IsReadOnly
        Get
            Return False
        End Get
    End Property

    ' Add path to collection
    Public Sub Add(item As PathInfo) Implements ICollection(Of PathInfo).Add
        If myPaths.Contains(item.Name) Then
            myPaths.Remove(item.Name)
        End If
        myPaths.Add(item.Name)
    End Sub

    ' Clear the collection
    Public Sub Clear() Implements ICollection(Of PathInfo).Clear
        myPaths.Clear()
    End Sub

    ' Copy to an array
    Public Sub CopyTo(array() As PathInfo, arrayIndex As Integer) Implements ICollection(Of PathInfo).CopyTo
        If array.Count < 1 Then
            Return
        End If
        If array.Rank > 1 Then
            Throw New System.NotSupportedException()
        End If
        Try
            Dim first As Integer = array.GetLowerBound(0)
            Dim last As Integer = array.GetUpperBound(0)
            Dim item As PathInfo
            For Each item In myPaths
                If first > last Then
                    Exit For
                End If
                array.SetValue(item, first)
                first += 1
            Next
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Whether path is contained in collection
    Public Function Contains(item As PathInfo) As Boolean Implements ICollection(Of PathInfo).Contains
        Return myPaths.Contains(item.Name)
    End Function

    ' Get enumerator
    Public Function GetEnumerator() As IEnumerator(Of PathInfo) Implements IEnumerable(Of PathInfo).GetEnumerator
        Return IEnumerable_GetEnumerator()
    End Function

    ' Remove item from list
    Public Function Remove(item As PathInfo) As Boolean Implements ICollection(Of PathInfo).Remove
        If Contains(item) Then
            myPaths.Remove(item.Name)
            Return True
        End If
        Return False
    End Function

    ' Get enumerator (internal version)
    Private Function IEnumerable_GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return myPaths.GetEnumerator()
    End Function

    ' Get item by index
    Public ReadOnly Property Item(index As Integer) As PathInfo
        Get
            If Count < 1 Then Return Nothing
            If Count <= index Then Return Nothing
            Return myPaths.Item(index)
        End Get
    End Property

    ' Get index of specified item
    Public Function GetIndexOf(key As String) As Integer
        If Count < 1 Then Return -1
        Dim n As Integer
        Dim di As DateInfo
        For n = 0 To Count - 1
            di = myPaths.Item(n)
            If di.Name = key Then
                Return n
            End If
        Next
        Return -1
    End Function

    ' Get specified item
    Public Function GetItem(key As String) As PathInfo
        Dim index As Integer = GetIndexOf(key)
        If (index < 0) Then Return Nothing
        Return myPaths.Item(index)
    End Function

End Class

' Collection of file info objects
Friend Class FileCollection
    Implements ICollection(Of FileInfo)

    ' Internal collection for storing file info objects
    Private myFiles As New Collection

    ' Return item count
    Public ReadOnly Property Count As Integer Implements ICollection(Of FileInfo).Count
        Get
            Return myFiles.Count
        End Get
    End Property

    ' We do NOT want a read-only collection!
    Public ReadOnly Property IsReadOnly As Boolean Implements ICollection(Of FileInfo).IsReadOnly
        Get
            Return False
        End Get
    End Property

    ' Add file to collection
    Public Sub Add(item As FileInfo) Implements ICollection(Of FileInfo).Add
        If Contains(item) Then
            Remove(item)
        End If
        myFiles.Add(item, item.Name)
    End Sub

    ' Clear the collection
    Public Sub Clear() Implements ICollection(Of FileInfo).Clear
        myFiles.Clear()
    End Sub

    ' Copy to an array
    Public Sub CopyTo(array() As FileInfo, arrayIndex As Integer) Implements ICollection(Of FileInfo).CopyTo
        If array.Count < 1 Then
            Return
        End If
        If array.Rank > 1 Then
            Throw New System.NotSupportedException()
        End If
        Try
            Dim first As Integer = array.GetLowerBound(0)
            Dim last As Integer = array.GetUpperBound(0)
            Dim item As FileInfo
            For Each item In myFiles
                If first > last Then
                    Exit For
                End If
                array.SetValue(item, first)
                first += 1
            Next
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Determine if file exists in collection
    Public Function Contains(item As FileInfo) As Boolean Implements ICollection(Of FileInfo).Contains
        Return myFiles.Contains(item.Name)
    End Function

    ' Get enumerator
    Public Function GetEnumerator() As IEnumerator(Of FileInfo) Implements IEnumerable(Of FileInfo).GetEnumerator
        Return myFiles.GetEnumerator()
    End Function

    ' Remove item from collection
    Public Function Remove(item As FileInfo) As Boolean Implements ICollection(Of FileInfo).Remove
        If Contains(item) Then
            myFiles.Remove(item.Name)
            Return True
        End If
        Return False
    End Function

    ' Get enumerator (internal version)
    Private Function IEnumerable_GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return myFiles.GetEnumerator()
    End Function

    ' Get item by index
    Public ReadOnly Property Item(index As Integer) As FileInfo
        Get
            If Count < 1 Then Return Nothing
            If Count <= index Then Return Nothing
            Return myFiles.Item(index)
        End Get
    End Property

    ' Get index of specified item
    Public Function GetIndexOf(key As String) As Integer
        If Count < 1 Then Return -1
        Dim n As Integer
        Dim di As DateInfo
        For n = 0 To Count - 1
            di = myFiles.Item(n)
            If di.Name = key Then
                Return n
            End If
        Next
        Return -1
    End Function

    ' Get specified item
    Public Function GetItem(key As String) As FileInfo
        Dim index As Integer = GetIndexOf(key)
        If (index < 0) Then Return Nothing
        Return myFiles.Item(index)
    End Function

End Class

' Collection of folder info objects
Friend Class FolderCollection
    Implements ICollection(Of FolderInfo)

    ' Internal collection object
    Private myFolders As New Collection

    ' Number of folders in collection
    Public ReadOnly Property Count As Integer Implements ICollection(Of FolderInfo).Count
        Get
            Return myFolders.Count
        End Get
    End Property

    ' We don NOT want a read-only collection!
    Public ReadOnly Property IsReadOnly As Boolean Implements ICollection(Of FolderInfo).IsReadOnly
        Get
            Return False
        End Get
    End Property

    ' Add new folder
    Public Sub Add(item As FolderInfo) Implements ICollection(Of FolderInfo).Add
        If Contains(item) Then
            Remove(item)
        End If
        myFolders.Add(item, item.Name)
    End Sub

    ' Clear the collection
    Public Sub Clear() Implements ICollection(Of FolderInfo).Clear
        myFolders.Clear()
    End Sub

    ' Copy to array
    Public Sub CopyTo(array() As FolderInfo, arrayIndex As Integer) Implements ICollection(Of FolderInfo).CopyTo
        If array.Count < 1 Then
            Return
        End If
        If array.Rank > 1 Then
            Throw New System.NotSupportedException()
        End If
        Try
            Dim first As Integer = array.GetLowerBound(0)
            Dim last As Integer = array.GetUpperBound(0)
            Dim item As FolderInfo
            For Each item In myFolders
                If first > last Then
                    Exit For
                End If
                array.SetValue(item, first)
                first += 1
            Next
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Determine if item is in collection
    Public Function Contains(item As FolderInfo) As Boolean Implements ICollection(Of FolderInfo).Contains
        Return myFolders.Contains(item.Name)
    End Function

    ' Get enumerator
    Public Function GetEnumerator() As IEnumerator(Of FolderInfo) Implements IEnumerable(Of FolderInfo).GetEnumerator
        Return myFolders.GetEnumerator()
    End Function

    ' Remove item from collection
    Public Function Remove(item As FolderInfo) As Boolean Implements ICollection(Of FolderInfo).Remove
        If Contains(item) Then
            myFolders.Remove(item.Name)
            Return True
        End If
        Return False
    End Function

    ' Get enumerator
    Private Function IEnumerable_GetEnumerator() As IEnumerator Implements IEnumerable.GetEnumerator
        Return myFolders.GetEnumerator()
    End Function

    ' Get item by index
    Public ReadOnly Property Item(index As Integer) As FolderInfo
        Get
            If Count < 1 Then Return Nothing
            If Count <= index Then Return Nothing
            Return myFolders.Item(index)
        End Get
    End Property

    ' Get index of specified item
    Public Function GetIndexOf(key As String) As Integer
        If Count < 1 Then Return -1
        Dim n As Integer
        Dim di As DateInfo
        For n = 0 To Count - 1
            di = myFolders.Item(n)
            If di.Name = key Then
                Return n
            End If
        Next
        Return -1
    End Function

    ' Get specified item
    Public Function GetItem(key As String) As FolderInfo
        Dim index As Integer = GetIndexOf(key)
        If (index < 0) Then Return Nothing
        Return myFolders.Item(index)
    End Function

End Class

