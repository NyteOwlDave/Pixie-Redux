﻿
' Serializable interface
Public Interface ISerializable
    Sub WriteFile(path As String)
    Sub ReadFile(path As String)
End Interface

' Job log class
Public Class JobLog
    Implements ISerializable
    ' Pathname to output file
    Private myPath As String = ""
    ' Read-only access to pathname for log file
    Public ReadOnly Property Path As String
        Get
            Return myPath
        End Get
    End Property
    ' Collection of error lines
    Private myLines As New Collection
    ' Clear the log
    Public Sub Clear()
        myLines.Clear()
    End Sub
    ' Read-only access to count of lines
    Public ReadOnly Property Count As Integer
        Get
            Return myLines.Count
        End Get
    End Property
    ' Constructor
    Public Sub New(pathName As String)
        SetNewPath(pathName)
    End Sub
    ' Load log file
    Public Function LoadLogFile() As Boolean
        Try
            ReadFile(Me.Path)
            Return True
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            Return False
        End Try
    End Function
    ' Save log file
    Public Function SaveLogFile() As Boolean
        Try
            WriteFile(Me.Path)
            Return True
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            Return False
        End Try
    End Function
    ' Set new pathname
    Public Sub SetNewPath(pathName As String)
        If (pathName Is Nothing) Then
            Throw New Exception(My.Resources.JobResources.InvalidJobFilePath)
        End If
        Dim root As String = IO.Path.GetPathRoot(pathName)
        If (root Is Nothing) Then root = ""
        If (root.Length < 3) Then
            Throw New Exception(My.Resources.JobResources.JobFilePathMissingRoot)
        End If
        If (pathName.Length < 4) Then
            Throw New Exception(My.Resources.JobResources.InvalidJobFilePath)
        End If
        myPath = pathName
    End Sub
    ' Add an entry to the log
    Public Sub Add(msg As String)
        myLines.Add(Format(msg))
    End Sub
    ' Add an entry to the log
    Public Sub Add(ex As Exception)
        myLines.Add(Format(ex))
    End Sub
    ' Add an entry to the log
    Public Sub Add(ex As JobException)
        myLines.Add(Format(ex))
    End Sub
    ' Read log from text file
    Public Sub ReadFile(path As String) Implements ISerializable.ReadFile
        myLines.Clear()
        Try
            Dim line As String
            Dim stream As New IO.StreamReader(path)
            While Not stream.EndOfStream
                line = stream.ReadLine()
                myLines.Add(line)
            End While
            stream.Close()
        Catch ex As Exception
            Dim msg As String = ComposeErrMsg(ex.Message)
            ShowErrorBox(msg)
        End Try
    End Sub
    ' Write log to text file
    Public Sub WriteFile(path As String) Implements ISerializable.WriteFile
        Try
            Dim line As String
            Dim stream As New IO.StreamWriter(path)
            For Each line In myLines
                stream.WriteLine(line)
            Next
            stream.Close()
        Catch ex As Exception
            Dim msg As String = ComposeErrMsg(ex.Message)
            ShowErrorBox(msg)
        End Try
    End Sub
    ' Compose document
    Public Function ComposeDocument() As String
        Dim s As String
        Dim all As String = ""
        For Each s In myLines
            all += s + "\n"
        Next
        Return all
    End Function
    ' Compose error message
    Private Function ComposeErrMsg(reason As String) As String
        Return "An error occured while reading a job log: " + reason
    End Function
    ' Format an entry from a simple string
    Public Shared Function Format(ex As Exception) As String
        Dim msg As String
        msg = ex.Message
        Return Format(msg)
    End Function
    ' Format an entry from an exception
    Public Shared Function Format(ex As JobException) As String
        Dim msg As String
        msg = "<" + ex.XmlTag + "> " + ex.Message
        Return Format(msg)
    End Function
    ' Format an entry from a job exception
    Public Shared Function Format(msg As String) As String
        Return Format(Date.Now) + " --- " + msg
    End Function
    ' Format date as text
    Public Shared Function Format(dt As Date) As String
        Dim text As String
        text = dt.Year.ToString("0000")
        text += "/"
        text += dt.Month.ToString("00")
        text += "/"
        text += dt.Day.ToString("00")
        text += " "
        text += dt.Hour.ToString("00")
        text += ":"
        text += dt.Minute.ToString("00")
        text += ":"
        Return text + dt.Second.ToString("00")
    End Function
End Class

' Implements a single instance of a job log object for app-wide usage
Friend Module Logging

    ' Single instance of job logger
    Private myLogger As JobLog = Nothing

    ' REad only access to the global job log object
    Public ReadOnly Property JobLogObject As JobLog
        Get
            Return myLogger
        End Get
    End Property

    ' Format date string my way
    Function FormatDate(dt As Date) As String
        Return JobLog.Format(dt)
    End Function

    ' Enclosed a string in double quotes
    Function QuoteText(arg As String) As String
        Return Chr(34) + arg + Chr(34)
    End Function

    ' Enclose a string in block characters
    Function QuoteTextEx(arg As String, opener As Char, closer As Char) As String
        Return opener + arg + closer
    End Function

    ' Create job logger object
    Sub CreateJobLog(pathName As String)
        If myLogger Is Nothing Then
            myLogger = New JobLog(pathName)
            Return
        End If
        myLogger.SetNewPath(pathName)
    End Sub

    ' Save log file
    Sub SaveJobLog()
        If myLogger Is Nothing Then Return
        myLogger.SaveLogFile()
    End Sub

    ' Clear log file
    Sub ClearJobLog()
        If myLogger Is Nothing Then Return
        myLogger.Clear()
    End Sub

    ' Add an entry to the job log
    Sub AddJobLogEntry(msg As String)
        If myLogger IsNot Nothing Then
            myLogger.Add(msg)
        End If
    End Sub

    ' Add an entry to the job log
    Sub AddJobLogEntry(ex As Exception)
        If myLogger IsNot Nothing Then
            myLogger.Add(ex)
        End If
    End Sub

    ' Add an entry to the job log
    Sub AddJobLogEntry(ex As JobException)
        If myLogger IsNot Nothing Then
            myLogger.Add(ex)
        End If
    End Sub

    ' Number of entries in logger
    ReadOnly Property JobLogCount As Integer
        Get
            If myLogger Is Nothing Then
                Return 0
            End If
            Return myLogger.Count
        End Get
    End Property

    ' Log file pathname
    ReadOnly Property JobLogPath As String
        Get
            If myLogger Is Nothing Then
                Return ""
            End If
            Return myLogger.Path
        End Get
    End Property

    ' Log file content
    ReadOnly Property JobLogContent As String
        Get
            If myLogger Is Nothing Then
                Return ""
            End If
            Return myLogger.ComposeDocument()
        End Get
    End Property

    ' Generate a pathname for a temporary log file
    Public Function GetJobLogTempPathName() As String
        Dim fldr As String = System.AppDomain.CurrentDomain.BaseDirectory
        Dim name As String = IO.Path.GetTempFileName()
        name = IO.Path.ChangeExtension(name, "txt")
        If fldr.EndsWith("\") Or fldr.EndsWith("/") Then
            Return fldr + name
        Else
            Return fldr + "\" + name
        End If
    End Function

    ' Browse logger file
    Sub BrowseLogFile(saveCurrent As Boolean)
        If (saveCurrent) Then
            SaveJobLog()
        End If
        If Not IO.File.Exists(JobLogPath) Then
            ShowInfoBox("The job log file doesn't exist.")
            Return
        End If
        Browse(JobLogPath)
    End Sub

    ' Test log file
    Sub TestJobLog()
        Dim path As String = GetPixieFolder()
        If path.EndsWith("\") Or path.EndsWith("/") Then
            path += "joblog.txt"
        Else
            path += "\joblog.txt"
        End If
        Try
            CreateJobLog(path)
            AddJobLogEntry("This is a test...")
            AddJobLogEntry("This is a test too...")
            AddJobLogEntry("This is a test also ...")
            AddJobLogEntry("This is the end of testing!")
            BrowseLogFile(True)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            ClearJobLog()
        End Try
    End Sub

End Module

