﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class PickDeviceDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PickDeviceDlg))
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.DriveListView = New System.Windows.Forms.ListView()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(7, 9)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 15
        Me.PixieBox.TabStop = False
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(424, 79)
        Me.HelpBox.TabIndex = 14
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Click on the device you want to use."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'DriveListView
        '
        Me.DriveListView.FullRowSelect = True
        Me.DriveListView.LabelWrap = False
        Me.DriveListView.LargeImageList = Me.ImageList1
        Me.DriveListView.Location = New System.Drawing.Point(7, 98)
        Me.DriveListView.Name = "DriveListView"
        Me.DriveListView.Size = New System.Drawing.Size(518, 301)
        Me.DriveListView.SmallImageList = Me.ImageList1
        Me.DriveListView.TabIndex = 16
        Me.DriveListView.UseCompatibleStateImageBehavior = False
        Me.DriveListView.View = System.Windows.Forms.View.List
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.HelpBox)
        Me.Panel1.Location = New System.Drawing.Point(97, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(428, 83)
        Me.Panel1.TabIndex = 17
        '
        'Timer1
        '
        Me.Timer1.Interval = 1000
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "FlashDrive32.png")
        Me.ImageList1.Images.SetKeyName(1, "SDCard32.png")
        '
        'PickDeviceDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.ClientSize = New System.Drawing.Size(535, 411)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PixieBox)
        Me.Controls.Add(Me.DriveListView)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PickDeviceDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Choose Removable Device"
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents DriveListView As ListView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents ImageList1 As ImageList
End Class
