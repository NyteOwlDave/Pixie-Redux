﻿Imports System.ComponentModel
Imports System.Windows.Forms

Public Class SpecialFoldersDlg

    Private Sub ProfileBox_Click(sender As Object, e As EventArgs) Handles ProfileBox.Click
        Browse(GetUserProfileFolder())
    End Sub

    Private Sub PicturesBox_Click(sender As Object, e As EventArgs) Handles PicturesBox.Click
        Browse(GetPicturesFolder())
    End Sub

    Private Sub VideosBox_Click(sender As Object, e As EventArgs) Handles VideosBox.Click
        Browse(GetVideosFolder())
    End Sub

    Private Sub MusicBox_Click(sender As Object, e As EventArgs) Handles MusicBox.Click
        Browse(GetMusicFolder())
    End Sub

    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        Browse(GetPixieFolder())
    End Sub

    Private Sub FavoritesBox_Click(sender As Object, e As EventArgs) Handles FavoritesBox.Click
        Browse(GetFavoritesFolder())
    End Sub

    Private Sub DownloadsBox_Click(sender As Object, e As EventArgs) Handles DownloadsBox.Click
        Browse(GetDownloadsFolder())
    End Sub

    Private Sub ContactsBox_Click(sender As Object, e As EventArgs) Handles ContactsBox.Click
        Browse(GetContactsFolder())
    End Sub

    Private Sub DocumentsBox_Click(sender As Object, e As EventArgs) Handles DocumentsBox.Click
        Browse(GetDocumentsFolder())
    End Sub

    Private Sub PixieHelpBox_Click(sender As Object, e As EventArgs) Handles PixieHelpBox.Click
        BrowsePixieHelp()
    End Sub

    Public Shared Sub Reveal()

        Dim frm As Form
        For Each frm In My.Application.OpenForms
            If frm.GetType().Name = "SpecialFoldersDlg" Then
                frm.Show()
                frm.Activate()
                Return
            End If
        Next

        frm = New SpecialFoldersDlg
        frm.Show()

    End Sub

    Private Sub SpecialFoldersDlg_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        e.Cancel = True
        Me.Hide()
    End Sub

End Class

