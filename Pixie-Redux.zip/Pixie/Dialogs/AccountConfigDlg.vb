﻿Imports System.Windows.Forms

' Account configuration dialog
Public Class AccountConfigDlg

    ' Clicked on OK button
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Clicked on Cancel button
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    ' Load dialog
    Private Sub AccountConfigDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' TODO...
    End Sub

End Class
