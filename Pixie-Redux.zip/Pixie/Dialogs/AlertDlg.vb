﻿Imports System.Windows.Forms

Public Class AlertDlg

    ' Icon style
    Public Enum Mode
        Notice
        Warning
        Critical
    End Enum

    ' Dialog mode should also be set before calling ShowDialog()
    Public DialogMode As Mode

    ' Message
    ' Set this before calling ShowDialog
    Public Message As String = "?"

    ' Details file
    Public DetailsFile As String = ""

    ' Static helper function to invoke dialog
    Public Shared Sub Execute(parent As Form, msg As String, detFile As String, m As Mode)
        Dim dlg As New AlertDlg
        dlg.DialogMode = m
        dlg.Message = msg
        dlg.DetailsFile = detFile
        dlg.ShowDialog(parent)
    End Sub

    ' Adapt for multiline message
    Private Sub AdaptForMultiline(msg As String)
        If msg.Contains(ControlChars.NewLine) Then
            With Me.HelpBox
                .Multiline = True
                .TextAlign = HorizontalAlignment.Left
                .ScrollBars = ScrollBars.Both
            End With
            Me.WindowState = FormWindowState.Maximized
        End If
    End Sub

    ' Show help message
    Private Sub ShowHelp(msg As String)
        AdaptForMultiline(msg)
        Me.HelpBox.Text = msg
    End Sub

    ' Show query message
    Private Sub ShowMessage()
        ShowHelp(Message)
    End Sub

    ' Update icon
    Private Sub UpdateIcon()
        Select Case DialogMode
            Case Mode.Critical
                Me.PixieBox.Image = My.Resources.AlertResources.ErrorIcon
            Case Mode.Warning
                Me.PixieBox.Image = My.Resources.AlertResources.WarningIcon
            Case Else
                Me.PixieBox.Image = My.Resources.AlertResources.InfoIcon
        End Select
    End Sub

    ' Okay button clicked
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.Close()
    End Sub

    ' Details button clicked
    Private Sub DetailsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DetailsButton.Click
        Dim path As String = GetPixieContentFolder()
        path = path + "\" + DetailsFile
        BrowserForm.Execute(path)
    End Sub

    ' Dialog ALWAYS returns OK result
    Private Sub AlertDlg_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Me.DialogResult = DialogResult.OK
    End Sub

    ' Form load event handler
    Private Sub AlertDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ShowMessage()
        UpdateIcon()
        If (DetailsFile Is Nothing) Then
            DetailsFile = ""
        End If
        If (DetailsFile.Length < 1) Then
            DetailsButton.Enabled = False
        End If
    End Sub

End Class
