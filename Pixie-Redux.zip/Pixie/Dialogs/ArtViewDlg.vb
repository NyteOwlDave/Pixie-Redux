﻿Imports System.Windows.Forms

Public Class ArtViewDlg

    ' Type of action to take when the user clicks the preview box
    Enum ActionType
        Pixie
        Computer
        Drive
    End Enum

    ' Currently selected action type
    Protected CurrentActionType As ActionType = ActionType.Pixie

    ' Show help text
    Protected Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Show standard help message
    Protected Sub ShowStandardHelp()
        Dim s As String = My.Resources.DefaultHelpMsg
        ShowHelp(s)
    End Sub

    ' Show preview help
    Protected Sub ShowPreviewHelp()
        Select Case CurrentActionType
            Case ActionType.Computer
                ShowHelp("Click here to see all the drives on your computer.")
                Return
            Case ActionType.Drive
                ShowHelp("Click here to see just the removable drives plugged in to your computer.")
                Return
            Case ActionType.Pixie
                ShowHelp("Click here to explore my program files.")
                Return
            Case Else
                ShowHelp("Dave needs to fix a bug in the program!")
                Return
        End Select
    End Sub

    ' Set preview image
    Private Sub SetPreviewImage(it As ImageType, type As ActionType)
        Dim img As Image = GetImageResource(it)
        PreviewBox.BackgroundImage = img
        CurrentActionType = type
    End Sub

#Region "Mouse Click Events"

    ' Click on pixie box
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        SetPreviewImage(ImageType.PixieGirl, ActionType.Pixie)
    End Sub

    ' Click on laptop box
    Private Sub LaptopBox_Click(sender As Object, e As EventArgs) Handles LaptopBox.Click
        SetPreviewImage(ImageType.Laptop, ActionType.Computer)
    End Sub

    ' Click on desktop box
    Private Sub DesktopBox_Click(sender As Object, e As EventArgs) Handles DesktopBox.Click
        SetPreviewImage(ImageType.Desktop, ActionType.Computer)
    End Sub

    ' Click on flash drive box
    Private Sub FlashDriveBox_Click(sender As Object, e As EventArgs) Handles FlashDriveBox.Click
        SetPreviewImage(ImageType.FlashDrive, ActionType.Drive)
    End Sub

    ' Click on SD card box
    Private Sub SDCardBox_Click(sender As Object, e As EventArgs) Handles SDCardBox.Click
        SetPreviewImage(ImageType.SDCard, ActionType.Drive)
    End Sub

    ' Click on preview box
    Private Sub PreviewBox_Click(sender As Object, e As EventArgs) Handles PreviewBox.Click
        Dim dlg As DriveListDlg = Nothing
        Select Case CurrentActionType
            Case ActionType.Computer
                dlg = New DriveListDlg
                dlg.ShowAllDrives = True
                dlg.ShowDialog(Me)
                dlg.Dispose()
                Return
            Case ActionType.Drive
                dlg = New DriveListDlg
                dlg.ShowAllDrives = False
                dlg.ShowDialog(Me)
                dlg.Dispose()
                Return
            Case ActionType.Pixie
                ExplorePixieRootFolder()
                Return
            Case Else
                MsgBox("Dave needs to fix the program!",
                       MsgBoxStyle.Exclamation,
                       My.Resources.MsgBoxCaption)
        End Select
    End Sub

#End Region

#Region "Mouse Enter/Leave/Hover Events"

    ' Mouse entering help box
    Private Sub PixieBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieBox.MouseEnter
        ShowHelp("Click here to see my full size photo.")
    End Sub

    ' Mouse leaving help box
    Private Sub PixieBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering preview box
    Private Sub PreviewBox_MouseEnter(sender As Object, e As EventArgs) Handles PreviewBox.MouseEnter
        ShowPreviewHelp()
    End Sub

    ' Mouse leaving preview box
    Private Sub PreviewBox_MouseLeave(sender As Object, e As EventArgs) Handles PreviewBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering laptop box
    Private Sub LaptopBox_MouseEnter(sender As Object, e As EventArgs) Handles LaptopBox.MouseEnter
        ShowHelp("Click here to see the full size laptop photo.")
    End Sub

    ' Mouse leaving help box
    Private Sub LaptopBox_MouseLeave(sender As Object, e As EventArgs) Handles LaptopBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering desktop box
    Private Sub DesktopBox_MouseEnter(sender As Object, e As EventArgs) Handles DesktopBox.MouseEnter
        ShowHelp("Click here to see the full size desktop photo.")
    End Sub

    ' Mouse leaving desktop box
    Private Sub DesktopBox_MouseLeave(sender As Object, e As EventArgs) Handles DesktopBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering flash drive box
    Private Sub FlashDriveBox_MouseEnter(sender As Object, e As EventArgs) Handles FlashDriveBox.MouseEnter
        ShowHelp("Click here to see the full size flash drive photo.")
    End Sub

    ' Mouse leaving flash drive box
    Private Sub FlashDriveBox_MouseLeave(sender As Object, e As EventArgs) Handles FlashDriveBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering SD card box
    Private Sub SDCardBox_MouseEnter(sender As Object, e As EventArgs) Handles SDCardBox.MouseEnter
        ShowHelp("Click here to see the full size SD card photo.")
    End Sub

    ' Mouse leaving SD card box
    Private Sub SDCardBox_MouseLeave(sender As Object, e As EventArgs) Handles SDCardBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Form load event
    Private Sub ArtViewDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

#End Region

End Class

