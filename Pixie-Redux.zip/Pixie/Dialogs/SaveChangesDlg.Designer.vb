﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SaveChangesDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim HelpPanel As System.Windows.Forms.Panel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SaveChangesDlg))
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.ActionComboBox = New System.Windows.Forms.ComboBox()
        HelpPanel = New System.Windows.Forms.Panel()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        HelpPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Location = New System.Drawing.Point(12, 101)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(83, 30)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(12, 12)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 2
        Me.PixieBox.TabStop = False
        '
        'HelpPanel
        '
        HelpPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        HelpPanel.Controls.Add(Me.HelpBox)
        HelpPanel.Location = New System.Drawing.Point(100, 12)
        HelpPanel.Name = "HelpPanel"
        HelpPanel.Size = New System.Drawing.Size(470, 119)
        HelpPanel.TabIndex = 3
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(466, 115)
        Me.HelpBox.TabIndex = 1
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'ActionComboBox
        '
        Me.ActionComboBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ActionComboBox.CausesValidation = False
        Me.ActionComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ActionComboBox.Items.AddRange(New Object() {"Save Changes and Close Window", "Discard Changes and Close Window", "Save Changes and Stay Open", "Discard Changes and Stay Open"})
        Me.ActionComboBox.Location = New System.Drawing.Point(100, 137)
        Me.ActionComboBox.Name = "ActionComboBox"
        Me.ActionComboBox.Size = New System.Drawing.Size(468, 24)
        Me.ActionComboBox.TabIndex = 4
        '
        'SaveChangesDlg
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CausesValidation = False
        Me.ClientSize = New System.Drawing.Size(582, 173)
        Me.Controls.Add(Me.ActionComboBox)
        Me.Controls.Add(Me.OK_Button)
        Me.Controls.Add(HelpPanel)
        Me.Controls.Add(Me.PixieBox)
        Me.HelpButton = True
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimumSize = New System.Drawing.Size(600, 220)
        Me.Name = "SaveChangesDlg"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Closing Window"
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        HelpPanel.ResumeLayout(False)
        HelpPanel.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents ActionComboBox As ComboBox
End Class
