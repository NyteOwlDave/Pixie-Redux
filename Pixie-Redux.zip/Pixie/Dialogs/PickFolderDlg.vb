﻿Imports System.Windows.Forms

Public Class PickFolderDlg

    ' Action to be taken when dialog is closed
    Public Enum AutoModeEnum
        None
        Explore
        Browse
        Profile
        Admin
    End Enum

    ' Input:
    ' Message to appear in help box
    Public HelpMessage As String = ""

    ' Input:
    ' Name of a folder to initially select, if desired
    Public LookForFolder As String = ""

    ' Input:
    ' Root path for primary node
    Public RootPath As String = ""

    ' Input:
    ' Determines action to be taken after folder is selected.
    ' This is for customizing help messages.
    Public AutoMode As AutoModeEnum

    ' Output:
    ' Contains the full pathname for the selected folder, if OK was clicked.
    ' If dialog was cancelled, contains an empty string.
    Public SelectedPath As String

    ' Read selected path from selected node
    Private Function ReadSelectedPath() As String
        Dim node As TreeNode
        node = FolderTreeView.SelectedNode
        If node Is Nothing Then
            Return Nothing
        End If
        Return CType(node.Tag, String)
    End Function

    ' Show help
    Private Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Update help
    Private Sub UpdateHelp()
        Select Case AutoMode
            Case AutoModeEnum.Explore
                HelpMessage = "Select a folder to open with Windows Explorer."
            Case AutoModeEnum.Browse
                HelpMessage = "Select a folder to browse."
            Case Else
                If HelpMessage Is Nothing Then HelpMessage = ""
                If HelpMessage.Length < 1 Then
                    HelpMessage = "Please select a folder and click OK."
                End If
        End Select
        ShowHelp(HelpMessage)
    End Sub

    ' OK button clicked
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Dim s As String = ReadSelectedPath()
        If s Is Nothing Then
            ShowInfoBox("You must click on a folder to select it before clicking OK.")
            Return
        End If
        SelectedPath = s
        Select Case AutoMode
            Case AutoModeEnum.Explore
                ShellOpen("explorer.exe", SelectedPath)
                Return
        End Select
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Cancel button clicked
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.SelectedPath = ""
        Me.Close()
    End Sub

    ' Compose path
    Private Function ComposePath(parent As String, child As String) As String
        If parent.EndsWith("\") Or parent.EndsWith("/") Then
            Return parent + child
        Else
            Return parent + IO.Path.DirectorySeparatorChar + child
        End If
    End Function

    ' Internal list of drives
    Private myDrives As IO.DriveInfo() = Nothing

    ' Helper to determine if the drive is ready for a pathname
    Private Function IsDriveReady(path As String) As Boolean
        If myDrives Is Nothing Then
            myDrives = IO.DriveInfo.GetDrives()
        End If
        If Not IO.Path.IsPathRooted(path) Then Return False
        Dim root As String = IO.Path.GetPathRoot(path).ToUpper()
        Dim drive As String = path(0)
        Dim info As IO.DriveInfo
        For Each info In myDrives
            Dim name As String = info.Name.ToUpper()
            If name = root Then
                Return info.IsReady
            End If
        Next
        Return False
    End Function

    ' Helper to determine if directory should be listed or hidden
    Private Function IsPathAccessible(path As String) As Boolean
        If AutoMode <> AutoModeEnum.None Then Return True
        Dim mask As IO.FileAttributes
        mask = IO.FileAttributes.Hidden ' Or IO.FileAttributes.System
        Dim info As IO.DirectoryInfo
        Try
            info = New IO.DirectoryInfo(path)
            If info.Attributes And mask Then
                Return False
            End If
            Return IsDriveReady(path)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            Return False
        End Try
    End Function

    ' Populate node
    Private Function PopulateNode(node As TreeNode, parentFolder As String) As Boolean

        Try
            ' Not a good thing!
            If node Is Nothing Then
                ShowErrorBox(My.Resources.BrowserResources.NullNodeMsg)
                Return False
            End If

            Dim folder As String = ComposePath(parentFolder, node.Text)
            node.Tag = folder

            Dim subs As String() = Nothing

            Try
                subs = IO.Directory.GetDirectories(folder)
            Catch ex As Exception
                AddJobLogEntry("Failed to get subdirectories: " & folder)
                AddJobLogEntry(ex)
                Return False
            End Try

            Dim s As String
            Dim child As TreeNode

            ' Now we need to scan all subdirectories to see if they contain
            ' sub-sub directories. Each one that does needs to have a single dummy
            ' child node attached as a place-holder so the tree control knows the
            ' node can be expanded. We capture the expand event later and remove
            ' the dummy node, replacing it with the actual list of sub-sub directories.
            For Each s In subs
                ' Filter out inaccessible stuff
                If Not IsPathAccessible(s) Then
                    Continue For
                End If
                ' Create and initialize the child node
                child = New TreeNode
                child.Text = IO.Path.GetFileName(s)
                child.Tag = s
                child.ImageIndex = 4
                child.SelectedImageIndex = 4
                ' Add it to it's parent
                node.Nodes.Add(child)
                ' Try to get sub-sub directories list
                ' We won't scan the list, just see if it exists and
                ' has more than zero entries.
                Dim subSubs As String() = Nothing
                Try
                    subSubs = IO.Directory.GetDirectories(s)
                Catch ex As Exception
                    AddJobLogEntry("Failed to get subdirectories: " & s)
                    AddJobLogEntry(ex)
                End Try
                ' If we failed, assume the folder's content is inaccessible
                If subSubs Is Nothing Then Continue For
                ' If the list of sub-sub directories isn't empty...
                If subSubs.Count > 0 Then
                    ' Put in a dummy node (to be replaced later)
                    Dim dummy As New TreeNode
                    dummy.Text = "Dummy"
                    child.Nodes.Add(dummy)
                End If
            Next

        Catch ex As OutOfMemoryException
            Throw

        Catch ex As Exception
            Dim folder As String = ComposePath(parentFolder, node.Text)
            AddJobLogEntry("Failed to populate tree node: " & folder)
            AddJobLogEntry(ex)
            Return False

        End Try

        Return True

    End Function

    ' Get drive info from specified pathname
    Public Function GetDriveInfo(pathName As String) As IO.DriveInfo
        If pathName Is Nothing Then pathName = ""
        If pathName.Length < 1 Then
            Return Nothing
        End If
        Dim root As String = IO.Path.GetPathRoot(pathName)
        If Not IO.Directory.Exists(root) Then
            ShowErrorBox("Root path doesn't exist")
            Return Nothing
        End If
        ' Get first letter of root path and capitalize it
        Dim ch1 As String = root(0)
        ch1 = ch1.ToUpper()
        ' Get list of drives
        myDrives = IO.DriveInfo.GetDrives()
        ' Loop through the drives
        Dim info As IO.DriveInfo
        For Each info In myDrives
            ' Get first letter of drive and capitalize it
            Dim ch2 As String = info.Name(0)
            ch2 = ch2.ToUpper()
            If (ch1 = ch2) Then
                Return info
            End If
        Next
        Return Nothing
    End Function

    ' Populate root node
    Private Sub Populate()
        Try
            ' Make sure root path and lookforfolder are not NOTHING
            If RootPath Is Nothing Then RootPath = ""
            If LookForFolder Is Nothing Then LookForFolder = ""

            Dim rootNodeImageIndex As Integer
            Dim rootText As String = Me.RootPath

            ' If AutoMode isn't None...
            If (AutoMode <> AutoModeEnum.None) Then
                ' Get information about drive for current root path
                Dim info As IO.DriveInfo = GetDriveInfo(RootPath)
                ' Root path doesn't exist or is invalid
                If info Is Nothing Then
                    Return
                End If
                ' If the drive type is removabe
                If info.DriveType = IO.DriveType.Removable Then
                    ' If current drive type is flash drive
                    If (My.Settings.CurrentDriveType = DriveType.FlashDrive) Then
                        ' Set image index for flash drive
                        rootNodeImageIndex = 2
                    Else
                        ' Set image index for SD card
                        rootNodeImageIndex = 3
                    End If
                Else ' Not a removable drive
                    ' If current computer type is laptop
                    If (My.Settings.CurrentComputerType = ComputerType.Laptop) Then
                        ' Set image index for laptop
                        rootNodeImageIndex = 0
                    Else
                        ' Set image index for desktop
                        rootNodeImageIndex = 1
                    End If
                End If
            Else ' Not in explore or browse mode
                ' If current computer type is laptop
                If (My.Settings.CurrentComputerType = ComputerType.Laptop) Then
                    ' Set image index for laptop
                    rootNodeImageIndex = 0
                Else
                    ' Set image index for desktop
                    rootNodeImageIndex = 1
                End If
            End If
            ' Get root node for tree view
            Dim rootNode As TreeNode = FolderTreeView.TopNode
            ' If no root node, create one and attach it
            If rootNode Is Nothing Then
                rootNode = New TreeNode
                FolderTreeView.Nodes.Add(rootNode)
            End If
            ' Initialize the root node
            rootNode.Text = rootText
            rootNode.Tag = RootPath
            rootNode.ImageIndex = rootNodeImageIndex
            rootNode.SelectedImageIndex = rootNodeImageIndex
            ' Clear root node of children
            rootNode.Nodes.Clear()
            ' If look for path provide
            If LookForFolder.Length > 0 Then
                ' If it's the root node's path
                If LookForFolder = RootPath Then
                    ' Select the root node
                    FolderTreeView.SelectedNode = rootNode
                    ' Make sure other nodes don't get checked for possible selection
                    LookForFolder = ""
                End If
            End If
            ' If drive for root path isn't ready, bail out
            If Not IsDriveReady(RootPath) Then
                Dim root As String = IO.Path.GetPathRoot(RootPath)
                ShowInfoBox("The disk drive isn't ready for " & root)
                Return
            End If
            ' Get list of subdirectories
            Dim subs As String()
            Try
                subs = IO.Directory.GetDirectories(RootPath)
            Catch ex As Exception
                AddJobLogEntry("Failed to read subfolders: " & RootPath)
                AddJobLogEntry(ex)
                Return
            End Try
            ' Prepare to iterate list
            Dim s As String
            Dim node As TreeNode
            Dim ok As Boolean = True
            ' Iterate list of subdirectories
            For Each s In subs
                ' If the path isn't accessible..
                If Not IsPathAccessible(s) Then
                    ' Skip it
                    Continue For
                End If
                ' Create a new child node, initialize it, and attach it to the root node
                node = New TreeNode
                node.Text = IO.Path.GetFileName(s)
                node.ImageIndex = 4
                node.SelectedImageIndex = 4
                rootNode.Nodes.Add(node)
                ' Populate the child node
                ok = PopulateNode(node, RootPath) And ok
                ' If we're supposed to auto-select a folder by name
                If LookForFolder.Length > 0 Then
                    ' And this is the one
                    If node.Text = LookForFolder Then
                        ' Select the node for this folder
                        FolderTreeView.SelectedNode = node
                    End If
                End If
            Next
            ' Expand the root node
            rootNode.Expand()
        Catch ex As OutOfMemoryException
            Throw
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Form load event
    Private Sub PickFolderDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If AutoMode = AutoModeEnum.Browse Then
            Me.BrowseButton.Visible = False
        Else
            Me.BrowseButton.Visible = True
        End If
        If AutoMode = AutoModeEnum.Profile Then
            RootPath = ""
        End If
        If RootPath Is Nothing Then
            RootPath = ""
        End If
        If Not IO.Directory.Exists(RootPath) Then
            RootPath = Environ("USERPROFILE")
            If RootPath Is Nothing Then RootPath = ""
            If RootPath.Length < 1 Then RootPath = "C:\Users"
            If Not IO.Directory.Exists(RootPath) Then
                RootPath = "C:\Documents and Settings"
                If Not IO.Directory.Exists(RootPath) Then
                    ShowErrorBox("Unable to choose AddressOf root path.")
                    Me.Close()
                    Return
                End If
            End If
        End If
        UpdateHelp()
        Populate()
    End Sub

    ' Tree node expanding
    Private Sub FolderTreeView_BeforeExpand(sender As Object, e As TreeViewCancelEventArgs) Handles FolderTreeView.BeforeExpand
        Dim node As TreeNode = e.Node
        If (node.Tag Is Nothing) Then
            e.Cancel = True
            Return
        End If
        If node.Nodes.Count > 1 Then
            e.Cancel = False
            Return
        End If
        Dim child As TreeNode = node.Nodes.Item(0)
        If child.Tag IsNot Nothing Then
            e.Cancel = False
            Return
        End If
        Dim folder As String = CType(node.Tag, String)
        Dim parent As String = IO.Path.GetDirectoryName(folder)
        If Not IsDriveReady(parent) Then
            e.Cancel = True
            Return
        End If
        node.Nodes.Clear()
        PopulateNode(node, parent)
        e.Cancel = False
    End Sub

    ' Event handler for node collapsed.
    Private Sub FolderTreeView_AfterCollapse(sender As Object, e As TreeViewEventArgs) Handles FolderTreeView.AfterCollapse
        Dim node As TreeNode = e.Node
        If node Is FolderTreeView.Nodes(0) Then Return
        node.ImageIndex = 4
        node.SelectedImageIndex = 4
    End Sub

    ' Prevent root node from collapsing.
    Private Sub FolderTreeView_BeforeCollapse(sender As Object, e As TreeViewCancelEventArgs) Handles FolderTreeView.BeforeCollapse
        Dim node As TreeNode = e.Node
        If node Is FolderTreeView.Nodes(0) Then
            e.Cancel = True
            Return
        End If
        e.Cancel = False
    End Sub

    ' Event handler for node expanded.
    Private Sub FolderTreeView_AfterExpand(sender As Object, e As TreeViewEventArgs) Handles FolderTreeView.AfterExpand
        Dim node As TreeNode = e.Node
        If node Is FolderTreeView.Nodes(0) Then Return
        node.ImageIndex = 5
        node.SelectedImageIndex = 5
    End Sub

    ' Click on Pixie box
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        Try
            Dim web As New BrowserForm
            BrowserForm.HomePage = ReadSelectedPath()
            web.Show(Me)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Clicked on browse button
    Private Sub BrowseButton_Click(sender As Object, e As EventArgs) Handles BrowseButton.Click
        Dim path As String = Me.ReadSelectedPath()
        If path Is Nothing Then
            ShowInfoBox("Click on a folder to select it, then click browse.")
            Return
        End If
        Browse(path)
    End Sub

    ' Result of execute function
    Public Shared ExecuteResult As String = ""

    ' Shared helper to simplify dialog usage
    Public Shared Function Execute(
                         msg As String,
                         rootPath As String,
                         lookFor As String,
                         auto As AutoModeEnum) As DialogResult
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        Dim dlg As New PickFolderDlg
        dlg.HelpMessage = msg
        dlg.RootPath = rootPath
        dlg.LookForFolder = lookFor
        dlg.AutoMode = auto
        result = dlg.ShowDialog(parent)
        If result = DialogResult.OK Then
            ExecuteResult = dlg.SelectedPath
        Else
            ExecuteResult = ""
        End If
        dlg.Dispose()
        Return result
    End Function

End Class

