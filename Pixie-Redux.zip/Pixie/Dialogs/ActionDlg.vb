﻿Imports System.Windows.Forms

Public Class ActionDlg

    ' Button style
    Public Enum Mode
        YesNo
        OKCancel
    End Enum

    ' Dialog mode should also be set before calling ShowDialog()
    Public DialogMode As Mode

    ' QueryMessage
    ' Set this before calling ShowDialog
    Public QueryMessage As String

    ' Show help message
    Private Sub ShowHelp(msg As String)
        Me.HelpBox.Text = msg
    End Sub

    ' Show query message
    Private Sub ShowQueryMessage()
        ShowHelp(QueryMessage)
    End Sub

    ' OK Button Clicked
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Select Case DialogMode
            Case Mode.OKCancel
                Me.DialogResult = DialogResult.OK
            Case Mode.YesNo
                Me.DialogResult = DialogResult.Yes
            Case Else
                Me.DialogResult = DialogResult.Abort
        End Select
        Me.Close()
    End Sub

    ' Cancel button clicked
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Select Case DialogMode
            Case Mode.OKCancel
                Me.DialogResult = DialogResult.Cancel
            Case Mode.YesNo
                Me.DialogResult = DialogResult.No
            Case Else
                Me.DialogResult = DialogResult.Abort
        End Select
        Me.Close()
    End Sub

    ' Form load event
    Private Sub ActionDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Select Case DialogMode
            Case Mode.OKCancel
                OK_Button.Text = "OK"
                Cancel_Button.Text = "Cancel"
            Case Mode.YesNo
                OK_Button.Text = "Yes"
                Cancel_Button.Text = "No"
            Case Else
                ShowHelp("Dave needs to fix the program!")
                Return
        End Select
        ShowQueryMessage()
    End Sub

    ' Public static function to show the dialog
    Public Shared Function Execute(parent As Form, msg As String, m As Mode) As DialogResult
        Dim dlg As New ActionDlg
        dlg.DialogMode = m
        dlg.QueryMessage = msg
        Dim r As DialogResult
        Try
            r = dlg.ShowDialog(parent)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            r = DialogResult.Abort
        Finally
            dlg.Dispose()
        End Try
        Return r
    End Function

End Class
