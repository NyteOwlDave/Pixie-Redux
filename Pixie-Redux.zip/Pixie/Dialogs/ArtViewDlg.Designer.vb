﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ArtViewDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.LaptopBox = New System.Windows.Forms.PictureBox()
        Me.DesktopBox = New System.Windows.Forms.PictureBox()
        Me.FlashDriveBox = New System.Windows.Forms.PictureBox()
        Me.SDCardBox = New System.Windows.Forms.PictureBox()
        Me.HelpPanel = New System.Windows.Forms.Panel()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.PreviewBox = New System.Windows.Forms.PictureBox()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LaptopBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DesktopBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FlashDriveBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDCardBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.HelpPanel.SuspendLayout()
        CType(Me.PreviewBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(6, 9)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 1
        Me.PixieBox.TabStop = False
        '
        'LaptopBox
        '
        Me.LaptopBox.BackColor = System.Drawing.SystemColors.Control
        Me.LaptopBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.Laptop128
        Me.LaptopBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LaptopBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LaptopBox.Location = New System.Drawing.Point(6, 98)
        Me.LaptopBox.Name = "LaptopBox"
        Me.LaptopBox.Size = New System.Drawing.Size(82, 83)
        Me.LaptopBox.TabIndex = 2
        Me.LaptopBox.TabStop = False
        '
        'DesktopBox
        '
        Me.DesktopBox.BackColor = System.Drawing.SystemColors.Control
        Me.DesktopBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.Desktop128
        Me.DesktopBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DesktopBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DesktopBox.Location = New System.Drawing.Point(6, 187)
        Me.DesktopBox.Name = "DesktopBox"
        Me.DesktopBox.Size = New System.Drawing.Size(82, 83)
        Me.DesktopBox.TabIndex = 3
        Me.DesktopBox.TabStop = False
        '
        'FlashDriveBox
        '
        Me.FlashDriveBox.BackColor = System.Drawing.SystemColors.Control
        Me.FlashDriveBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.FlashDrive128
        Me.FlashDriveBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.FlashDriveBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlashDriveBox.Location = New System.Drawing.Point(6, 276)
        Me.FlashDriveBox.Name = "FlashDriveBox"
        Me.FlashDriveBox.Size = New System.Drawing.Size(82, 83)
        Me.FlashDriveBox.TabIndex = 4
        Me.FlashDriveBox.TabStop = False
        '
        'SDCardBox
        '
        Me.SDCardBox.BackColor = System.Drawing.SystemColors.Control
        Me.SDCardBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.SDCard128
        Me.SDCardBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SDCardBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SDCardBox.Location = New System.Drawing.Point(6, 365)
        Me.SDCardBox.Name = "SDCardBox"
        Me.SDCardBox.Size = New System.Drawing.Size(82, 83)
        Me.SDCardBox.TabIndex = 5
        Me.SDCardBox.TabStop = False
        '
        'HelpPanel
        '
        Me.HelpPanel.BackColor = System.Drawing.Color.Transparent
        Me.HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpPanel.Controls.Add(Me.HelpBox)
        Me.HelpPanel.Location = New System.Drawing.Point(94, 9)
        Me.HelpPanel.Name = "HelpPanel"
        Me.HelpPanel.Size = New System.Drawing.Size(352, 83)
        Me.HelpPanel.TabIndex = 7
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(348, 79)
        Me.HelpBox.TabIndex = 0
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'PreviewBox
        '
        Me.PreviewBox.BackColor = System.Drawing.Color.SlateBlue
        Me.PreviewBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl
        Me.PreviewBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PreviewBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PreviewBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PreviewBox.Location = New System.Drawing.Point(96, 98)
        Me.PreviewBox.Name = "PreviewBox"
        Me.PreviewBox.Size = New System.Drawing.Size(350, 350)
        Me.PreviewBox.TabIndex = 8
        Me.PreviewBox.TabStop = False
        '
        'ArtViewDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 456)
        Me.Controls.Add(Me.PreviewBox)
        Me.Controls.Add(Me.HelpPanel)
        Me.Controls.Add(Me.SDCardBox)
        Me.Controls.Add(Me.FlashDriveBox)
        Me.Controls.Add(Me.DesktopBox)
        Me.Controls.Add(Me.LaptopBox)
        Me.Controls.Add(Me.PixieBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "ArtViewDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "The Artful Pixie"
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LaptopBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DesktopBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FlashDriveBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDCardBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.HelpPanel.ResumeLayout(False)
        Me.HelpPanel.PerformLayout()
        CType(Me.PreviewBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents LaptopBox As PictureBox
    Friend WithEvents DesktopBox As PictureBox
    Friend WithEvents FlashDriveBox As PictureBox
    Friend WithEvents SDCardBox As PictureBox
    Public WithEvents HelpPanel As Panel
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents PreviewBox As PictureBox
End Class
