﻿Imports System.Windows.Forms

Public Class PickUserDlg

    ' Prettifies the user name
    Public Shared Function PrettifyName(name As String) As String
        If name Is Nothing Then
            name = My.Resources.DefaultUserName
        Else
            name = name.Trim().ToLower()
        End If
        If name.Length < 1 Then
            Return My.Resources.DefaultUserName
        End If
        If name = My.Resources.DefaultUserName Then Return name
        Dim c As Char = name.Chars(0)
        If name.Length > 1 Then
            Return UCase(c) + name.Substring(1)
        Else
            name = UCase(c)
            Return name
        End If
    End Function

    ' OK button click
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        My.Settings.UserName = PrettifyName(UserNameBox.Text)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Cancel button click
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        My.Settings.UserName = My.Resources.DefaultUserName
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    ' Form load event
    Private Sub PickUserDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UserNameBox.Text = PrettifyName(My.Settings.UserName)
    End Sub

    ' Shared helper to simplify dialog usage
    Public Shared Function Execute() As DialogResult
        Dim parent As Form = My.Application.OpenForms(0)
        Dim dlg As New PickUserDlg
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        dlg.Dispose()
        Return result
    End Function

End Class
