﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AlertDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim HelpPanel As System.Windows.Forms.Panel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AlertDlg))
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.DetailsButton = New System.Windows.Forms.Button()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        HelpPanel = New System.Windows.Forms.Panel()
        HelpPanel.SuspendLayout()
        Me.TableLayoutPanel1.SuspendLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'HelpPanel
        '
        HelpPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        HelpPanel.Controls.Add(Me.HelpBox)
        HelpPanel.Location = New System.Drawing.Point(100, 12)
        HelpPanel.Name = "HelpPanel"
        HelpPanel.Size = New System.Drawing.Size(379, 173)
        HelpPanel.TabIndex = 4
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(375, 169)
        Me.HelpBox.TabIndex = 2
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Some action needs your attention."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.DetailsButton, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(289, 195)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(195, 36)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(4, 4)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 28)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'DetailsButton
        '
        Me.DetailsButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.DetailsButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DetailsButton.Location = New System.Drawing.Point(101, 4)
        Me.DetailsButton.Margin = New System.Windows.Forms.Padding(4)
        Me.DetailsButton.Name = "DetailsButton"
        Me.DetailsButton.Size = New System.Drawing.Size(89, 28)
        Me.DetailsButton.TabIndex = 1
        Me.DetailsButton.Text = "Details..."
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(12, 12)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 3
        Me.PixieBox.TabStop = False
        '
        'AlertDlg
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(492, 241)
        Me.Controls.Add(HelpPanel)
        Me.Controls.Add(Me.PixieBox)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(316, 199)
        Me.Name = "AlertDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Note"
        HelpPanel.ResumeLayout(False)
        HelpPanel.PerformLayout()
        Me.TableLayoutPanel1.ResumeLayout(False)
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents DetailsButton As System.Windows.Forms.Button
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents HelpBox As TextBox
End Class
