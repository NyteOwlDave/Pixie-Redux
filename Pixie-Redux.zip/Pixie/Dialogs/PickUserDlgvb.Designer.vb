﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PickUserDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim HelpGroup As System.Windows.Forms.GroupBox
        Dim Label1 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Me.HelpPanel = New System.Windows.Forms.Panel()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.UserNameBox = New System.Windows.Forms.TextBox()
        HelpGroup = New System.Windows.Forms.GroupBox()
        Label1 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        HelpGroup.SuspendLayout()
        Me.HelpPanel.SuspendLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'HelpGroup
        '
        HelpGroup.Controls.Add(Me.HelpPanel)
        HelpGroup.Controls.Add(Label1)
        HelpGroup.Controls.Add(Me.PixieBox)
        HelpGroup.Location = New System.Drawing.Point(12, 12)
        HelpGroup.Name = "HelpGroup"
        HelpGroup.Size = New System.Drawing.Size(538, 242)
        HelpGroup.TabIndex = 4
        HelpGroup.TabStop = False
        '
        'HelpPanel
        '
        Me.HelpPanel.BackColor = System.Drawing.Color.Transparent
        Me.HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpPanel.Controls.Add(Me.HelpBox)
        Me.HelpPanel.Location = New System.Drawing.Point(7, 111)
        Me.HelpPanel.Name = "HelpPanel"
        Me.HelpPanel.Size = New System.Drawing.Size(525, 123)
        Me.HelpPanel.TabIndex = 2
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(521, 119)
        Me.HelpBox.TabIndex = 0
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hi! I'd like to make our interactions more friendly. Could you please tell me you" &
    "r first name?"
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(99, 82)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(164, 24)
        Label1.TabIndex = 1
        Label1.Text = "Your Pixie Says..."
        Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(6, 21)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 0
        Me.PixieBox.TabStop = False
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(17, 257)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(145, 24)
        Label2.TabIndex = 5
        Label2.Text = "Please call me:"
        Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(350, 342)
        Me.TableLayoutPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(195, 36)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(4, 4)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 28)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(101, 4)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 28)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'UserNameBox
        '
        Me.UserNameBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.UserNameBox.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.UserNameBox.Font = New System.Drawing.Font("Verdana", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserNameBox.Location = New System.Drawing.Point(18, 284)
        Me.UserNameBox.MaxLength = 16
        Me.UserNameBox.Name = "UserNameBox"
        Me.UserNameBox.Size = New System.Drawing.Size(526, 40)
        Me.UserNameBox.TabIndex = 6
        Me.UserNameBox.Text = "?"
        Me.UserNameBox.WordWrap = False
        '
        'PickUserDlg
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SeaShell
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(561, 393)
        Me.Controls.Add(Me.UserNameBox)
        Me.Controls.Add(Label2)
        Me.Controls.Add(HelpGroup)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PickUserDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Introduce Yourself"
        HelpGroup.ResumeLayout(False)
        HelpGroup.PerformLayout()
        Me.HelpPanel.ResumeLayout(False)
        Me.HelpPanel.PerformLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Public WithEvents HelpPanel As Panel
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents UserNameBox As TextBox
End Class
