﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DriveListDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Label1 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DriveListDlg))
        Me.HelpPanel = New System.Windows.Forms.Panel()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.DriveListView = New System.Windows.Forms.ListView()
        Me.DriveImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.DriveBox = New System.Windows.Forms.PictureBox()
        Me.ComputerBox = New System.Windows.Forms.PictureBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Label1 = New System.Windows.Forms.Label()
        Me.HelpPanel.SuspendLayout()
        CType(Me.DriveBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ComputerBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Tahoma", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(93, 5)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(137, 21)
        Label1.TabIndex = 9
        Label1.Text = "Your Pixie Says..."
        Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'HelpPanel
        '
        Me.HelpPanel.BackColor = System.Drawing.Color.Transparent
        Me.HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpPanel.Controls.Add(Me.HelpBox)
        Me.HelpPanel.Location = New System.Drawing.Point(95, 29)
        Me.HelpPanel.Name = "HelpPanel"
        Me.HelpPanel.Size = New System.Drawing.Size(352, 83)
        Me.HelpPanel.TabIndex = 10
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(348, 79)
        Me.HelpBox.TabIndex = 0
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'DriveListView
        '
        Me.DriveListView.FullRowSelect = True
        Me.DriveListView.LabelWrap = False
        Me.DriveListView.LargeImageList = Me.DriveImageList
        Me.DriveListView.Location = New System.Drawing.Point(97, 118)
        Me.DriveListView.Name = "DriveListView"
        Me.DriveListView.Size = New System.Drawing.Size(350, 172)
        Me.DriveListView.SmallImageList = Me.DriveImageList
        Me.DriveListView.TabIndex = 13
        Me.DriveListView.UseCompatibleStateImageBehavior = False
        Me.DriveListView.View = System.Windows.Forms.View.List
        '
        'DriveImageList
        '
        Me.DriveImageList.ImageStream = CType(resources.GetObject("DriveImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.DriveImageList.TransparentColor = System.Drawing.Color.Transparent
        Me.DriveImageList.Images.SetKeyName(0, "FlashDrive32.png")
        Me.DriveImageList.Images.SetKeyName(1, "SDCard32.png")
        Me.DriveImageList.Images.SetKeyName(2, "Desktop32.png")
        Me.DriveImageList.Images.SetKeyName(3, "FixedDisk32.png")
        Me.DriveImageList.Images.SetKeyName(4, "NetDrive32.png")
        Me.DriveImageList.Images.SetKeyName(5, "NoRoot32.png")
        Me.DriveImageList.Images.SetKeyName(6, "OpticalDrive32.png")
        Me.DriveImageList.Images.SetKeyName(7, "PixieGirl32.png")
        Me.DriveImageList.Images.SetKeyName(8, "RAMDrive32.png")
        Me.DriveImageList.Images.SetKeyName(9, "Removable32.png")
        Me.DriveImageList.Images.SetKeyName(10, "UnknownDrive32.png")
        '
        'DriveBox
        '
        Me.DriveBox.BackColor = System.Drawing.SystemColors.Control
        Me.DriveBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.FlashDrive128
        Me.DriveBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DriveBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DriveBox.Location = New System.Drawing.Point(7, 207)
        Me.DriveBox.Name = "DriveBox"
        Me.DriveBox.Size = New System.Drawing.Size(82, 83)
        Me.DriveBox.TabIndex = 12
        Me.DriveBox.TabStop = False
        '
        'ComputerBox
        '
        Me.ComputerBox.BackColor = System.Drawing.SystemColors.Control
        Me.ComputerBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.Laptop128
        Me.ComputerBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ComputerBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComputerBox.Location = New System.Drawing.Point(7, 118)
        Me.ComputerBox.Name = "ComputerBox"
        Me.ComputerBox.Size = New System.Drawing.Size(82, 83)
        Me.ComputerBox.TabIndex = 11
        Me.ComputerBox.TabStop = False
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(7, 29)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 8
        Me.PixieBox.TabStop = False
        '
        'Timer1
        '
        '
        'DriveListDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 300)
        Me.Controls.Add(Me.DriveListView)
        Me.Controls.Add(Me.DriveBox)
        Me.Controls.Add(Me.ComputerBox)
        Me.Controls.Add(Me.HelpPanel)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Me.PixieBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DriveListDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "All Drives"
        Me.HelpPanel.ResumeLayout(False)
        Me.HelpPanel.PerformLayout()
        CType(Me.DriveBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ComputerBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Public WithEvents HelpPanel As Panel
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents ComputerBox As PictureBox
    Friend WithEvents DriveBox As PictureBox
    Friend WithEvents DriveListView As ListView
    Friend WithEvents DriveImageList As ImageList
    Friend WithEvents Timer1 As Timer
End Class
