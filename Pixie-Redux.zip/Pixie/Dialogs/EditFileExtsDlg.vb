﻿Imports System.ComponentModel
Imports System.Windows.Forms

Public Class EditFileExtsDlg

    ' File extensions collection
    Private myExts As New FileExtCollection

    ' Input/output:
    ' Filename extensions as a single string
    ' Throws exception if string is malformed
    ' Separator = ";"
    Public Property Extensions As String
        Get
            Return myExts.Merge(";")
        End Get
        Set(value As String)
            myExts.AddMultiple(value, ";")
        End Set
    End Property

    ' Clicked on OK button
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        If CaptureExts() Then
            myWantClose = True
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub

    ' Clicked on Cancel button
    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        myWantClose = True
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    ' Find item by name
    Private Function FindItem(ext As String) As ListViewItem
        Dim item As ListViewItem
        For Each item In ExtsListView.Items
            If item.Text = ext Then
                Return item
            End If
        Next
        Return Nothing
    End Function

    ' Clicked on Add button
    Private Sub AddButton_Click(sender As Object, e As EventArgs) Handles AddButton.Click
        Dim ext As String = ExtBox.Text
        Try
            ext = myExts.Prettify(ext)
            If FindItem(ext) IsNot Nothing Then
                Return
            End If
            Dim item As New ListViewItem
            item.Text = ext
            item.ImageIndex = 0
            ExtsListView.Items.Add(item)
        Catch ex As Exception
            ShowWarnBox(ex.Message)
        End Try
    End Sub

    ' Clicked on Remove button 
    Private Sub RemoveButton_Click(sender As Object, e As EventArgs) Handles RemoveButton.Click
        With ExtsListView
            Dim item As ListViewItem
            For Each item In .SelectedItems
                .Items.Remove(item)
            Next
        End With
    End Sub

    ' User finished editing label of selected item
    Private Sub ExtsListView_AfterLabelEdit(sender As Object, e As EventArgs) Handles ExtsListView.AfterLabelEdit
        ' TODO...
    End Sub

    ' Selected item activated
    Private Sub ExtsListView_ItemActivate(sender As Object, e As EventArgs) Handles ExtsListView.ItemActivate
        ExtsListView.SelectedItems(0).BeginEdit()
    End Sub

    ' Capture the listview items into the Extensions collection
    Protected Function CaptureExts() As Boolean
        Dim ok As Boolean = True
        myExts.Clear()
        Dim item As ListViewItem
        For Each item In ExtsListView.Items
            Try
                myExts.Add(item.Text)
            Catch ex As Exception
                ShowWarnBox(ex.Message)
                ok = False
            End Try
        Next
        Return ok
    End Function

    ' Populate the listview
    Protected Sub Populate()
        With ExtsListView
            .Items.Clear()
            Dim item As ListViewItem
            Dim ext As String
            Dim count As Integer = myExts.Count
            Dim index As Integer
            For index = 1 To count
                ext = myExts.Item(index)
                item = New ListViewItem
                item.Text = ext
                item.ImageIndex = 0
                .Items.Add(item)
            Next
        End With
    End Sub

    ' Form load event
    Private Sub EditFileExtsDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Populate()
    End Sub

    ' Flag to keep the silly dialog from closing until WE TELL IT TO!!!
    Private myWantClose As Boolean = False

    ' Trap closing event and cancel it unless we explicitly told it to do so...
    Private Sub EditFileExtsDlg_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        e.Cancel = Not myWantClose
    End Sub

End Class

