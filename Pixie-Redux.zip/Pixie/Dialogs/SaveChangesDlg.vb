﻿Imports System.Windows.Forms

Public Class SaveChangesDlg

    ' Enumeration for result
    Public Enum ActionEnum
        SaveAndClose
        DiscardAndClose
        SaveAndStayOpen
        DiscardAndStayOpen
    End Enum

    ' Input/Output
    ' Action to be taken after dialog closes
    Public Action As ActionEnum = ActionEnum.SaveAndClose

    ' Current group
    Public Property Group As String
        Get

        End Get
        Set(value As String)

        End Set
    End Property

    ' Internal storage for standard help message
    Private myMessage = My.Resources.DefaultHelpMsg

    ' Property to change standard help message
    Public Property Message As String
        Get
            Return myMessage
        End Get
        Set(value As String)
            If value Is Nothing Then
                value = ""
            Else
                value = value.Trim()
            End If
            If value.Length < 1 Then
                myMessage = My.Resources.DefaultHelpMsg
            Else
                myMessage = value
            End If
        End Set
    End Property

    ' Show help message
    Private Sub ShowHelp(msg As String)
        Me.HelpBox.Text = msg
    End Sub

    ' Show standard help message
    Private Sub ShowStandardHelp()
        ShowHelp(myMessage)
    End Sub

    ' Clicked OK button
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Action = Me.ActionComboBox.SelectedIndex
        Me.Close()
    End Sub

    ' Form load event
    Private Sub SaveChangesDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.ActionComboBox.SelectedIndex = Me.Action
        Me.ShowStandardHelp()
    End Sub

    ' Clicked on pixie box
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        ShowInfoBox(My.Resources.ToDoMessage)
    End Sub

    ' Mouse entered action combo box
    Private Sub ActionComboBox_MouseEnter(sender As Object, e As EventArgs) Handles ActionComboBox.MouseEnter
        ShowHelp("Select the desired action from this drop down box.")
    End Sub

    ' Mouse left action combo box
    Private Sub ActionComboBox_MouseLeave(sender As Object, e As EventArgs) Handles ActionComboBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered OK button
    Private Sub OK_Button_MouseEnter(sender As Object, e As EventArgs) Handles OK_Button.MouseEnter
        ShowHelp("Click here to carry out the desired action.")
    End Sub

    ' Mouse left OK button
    Private Sub OK_Button_MouseLeave(sender As Object, e As EventArgs) Handles OK_Button.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered pixie box
    Private Sub PixieBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieBox.MouseEnter
        ShowHelp("Click here for more details.")
    End Sub

    ' Mouse left pixie box
    Private Sub PixieBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieBox.MouseLeave
        ShowStandardHelp()
    End Sub

End Class

