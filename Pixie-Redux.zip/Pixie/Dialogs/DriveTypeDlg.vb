﻿Imports System.Windows.Forms

Public Class DriveTypeDlg

    Public Result As DriveType = DriveType.Undefined

    Private Sub FlashBox_Click(sender As Object, e As EventArgs) Handles FlashBox.Click
        Me.Result = DriveType.FlashDrive
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub SDCardBox_Click(sender As Object, e As EventArgs) Handles SDCardBox.Click
        Me.Result = DriveType.SDCard
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

End Class

