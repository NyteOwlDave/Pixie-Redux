﻿Imports System.Windows.Forms

Public Class ComputerTypeDlg

    Public Result As ComputerType = ComputerType.Undefined

    Private Sub LaptopBox_Click(sender As Object, e As EventArgs) Handles LaptopBox.Click
        Me.Result = ComputerType.Laptop
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

    Private Sub DesktopBox_Click(sender As Object, e As EventArgs) Handles DesktopBox.Click
        Me.Result = ComputerType.Desktop
        Me.DialogResult = DialogResult.OK
        Me.Close()
    End Sub

End Class

