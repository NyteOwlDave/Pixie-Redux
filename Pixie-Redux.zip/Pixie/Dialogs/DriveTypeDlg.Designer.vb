﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DriveTypeDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim Label1 As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Me.FlashBox = New System.Windows.Forms.PictureBox()
        Me.SDCardBox = New System.Windows.Forms.PictureBox()
        Label1 = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        CType(Me.FlashBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SDCardBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Location = New System.Drawing.Point(155, 70)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(109, 17)
        Label1.TabIndex = 2
        Label1.Text = "<-- Click one -->"
        '
        'Label2
        '
        Label2.BackColor = System.Drawing.Color.PaleGoldenrod
        Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 13.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label2.Location = New System.Drawing.Point(12, 149)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(395, 133)
        Label2.TabIndex = 3
        Label2.Text = "You can choose the picture you'd like to use to represent removable drives."
        Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'FlashBox
        '
        Me.FlashBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.FlashDrive
        Me.FlashBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.FlashBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FlashBox.Location = New System.Drawing.Point(12, 11)
        Me.FlashBox.Name = "FlashBox"
        Me.FlashBox.Size = New System.Drawing.Size(137, 135)
        Me.FlashBox.TabIndex = 0
        Me.FlashBox.TabStop = False
        '
        'SDCardBox
        '
        Me.SDCardBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.SDCard
        Me.SDCardBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SDCardBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SDCardBox.Location = New System.Drawing.Point(270, 11)
        Me.SDCardBox.Name = "SDCardBox"
        Me.SDCardBox.Size = New System.Drawing.Size(137, 135)
        Me.SDCardBox.TabIndex = 1
        Me.SDCardBox.TabStop = False
        '
        'DriveTypeDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(420, 295)
        Me.Controls.Add(Label2)
        Me.Controls.Add(Label1)
        Me.Controls.Add(Me.SDCardBox)
        Me.Controls.Add(Me.FlashBox)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "DriveTypeDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Drive Type"
        CType(Me.FlashBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SDCardBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents FlashBox As PictureBox
    Friend WithEvents SDCardBox As PictureBox
End Class
