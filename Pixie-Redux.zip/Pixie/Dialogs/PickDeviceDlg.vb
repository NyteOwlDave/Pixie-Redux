﻿Imports System.Windows.Forms

Public Class PickDeviceDlg

    ' Result (drive letter 'A' - 'C')
    ' Will be zero if dialog cancelled.
    Public SelectedDrive As Char

    ' Last drive count
    Private LastCount As Integer

    ' End dialog
    Private Sub EndDialog(result As DialogResult)
        Me.DialogResult = result
        Me.Close()
    End Sub

    ' Show help message
    Private Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Format text for drive list item
    Private Function FormatItemText(drive As IO.DriveInfo) As String
        Dim label As String = "?"
        Try
            If (drive.IsReady) Then
                label = drive.VolumeLabel
            Else
                label = "No Media"
            End If
        Catch ex As Exception
            label = "Error!"
        End Try
        Return label + " (" + drive.Name(0) + ":)"
    End Function

    ' Populated drive list
    Private Sub PopulateDriveList()
        Timer1.Enabled = False
        Try
            Dim drives As IO.DriveInfo() = IO.DriveInfo.GetDrives()
            Dim count1 As Integer = LastCount
            Dim count2 As Integer = drives.Count
            If (count1 = count2) Then Return
            LastCount = count2
            DriveListView.Items.Clear()
            Dim item As ListViewItem = Nothing
            For n = 1 To count2
                Dim drive As IO.DriveInfo
                drive = drives.ElementAt(n - 1)
                If (drive.DriveType = IO.DriveType.Removable) Then
                    item = New ListViewItem
                    item.Text = FormatItemText(drive)
                    item.Tag = drive.Name(0)
                    item.ImageIndex = My.Settings.CurrentDriveType - 1
                    DriveListView.Items.Add(item)
                End If
            Next
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            Timer1.Enabled = True
        End Try
    End Sub

    ' Update help message based on current conditions
    Private Sub UpdateHelp()
        Timer1.Enabled = False
        Try
            Dim drv As String
            Dim tp As DriveType = My.Settings.CurrentDriveType
            Select Case tp
                Case DriveType.FlashDrive
                    drv = "flash drive"
                Case DriveType.SDCard
                    drv = "SD card"
                Case Else
                    drv = "removable drive"
            End Select
            Dim count As Integer = DriveListView.Items.Count
            If (count = 0) Then
                ShowHelp("Please insert your " + drv + " now.")
                Return
            End If
            If (count = 1) Then
                ShowHelp("Please click on the " + drv + " listed below." &
                         " You can plug in or unplug devices if you like.")
                Return
            End If
            ShowHelp("Please click on the " + drv &
                     " you wish to use." &
                     " You can plug in or unplug devices if you like.")
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            Timer1.Enabled = True
        End Try
    End Sub

    ' Form load event
    Private Sub PickDeviceDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LastCount = 0
        Timer1.Interval = 2500
        PopulateDriveList()
        UpdateHelp()
    End Sub

    ' Timer tick handler
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        PopulateDriveList()
        UpdateHelp()
    End Sub

    ' Click on selected item
    Private Sub DriveListView_SelectedIndexChanged(
        sender As Object, e As EventArgs) Handles DriveListView.Click, DriveListView.MouseClick
        Dim item As ListViewItem = DriveListView.SelectedItems(0)
        SelectedDrive = CType(item.Tag, Char)
        EndDialog(DialogResult.OK)
    End Sub

End Class
