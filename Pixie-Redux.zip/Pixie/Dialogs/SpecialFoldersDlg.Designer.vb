﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SpecialFoldersDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Panel1 As System.Windows.Forms.Panel
        Dim Label1 As System.Windows.Forms.Label
        Dim Panel2 As System.Windows.Forms.Panel
        Dim Label2 As System.Windows.Forms.Label
        Dim Panel3 As System.Windows.Forms.Panel
        Dim Label3 As System.Windows.Forms.Label
        Dim Panel4 As System.Windows.Forms.Panel
        Dim Label4 As System.Windows.Forms.Label
        Dim Panel5 As System.Windows.Forms.Panel
        Dim Label5 As System.Windows.Forms.Label
        Dim Panel6 As System.Windows.Forms.Panel
        Dim Label6 As System.Windows.Forms.Label
        Dim Panel7 As System.Windows.Forms.Panel
        Dim Label7 As System.Windows.Forms.Label
        Dim Panel8 As System.Windows.Forms.Panel
        Dim Label8 As System.Windows.Forms.Label
        Dim Panel9 As System.Windows.Forms.Panel
        Dim Label9 As System.Windows.Forms.Label
        Dim Panel10 As System.Windows.Forms.Panel
        Dim Label10 As System.Windows.Forms.Label
        Me.PixieHelpBox = New System.Windows.Forms.PictureBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.ContactsBox = New System.Windows.Forms.PictureBox()
        Me.DownloadsBox = New System.Windows.Forms.PictureBox()
        Me.FavoritesBox = New System.Windows.Forms.PictureBox()
        Me.DocumentsBox = New System.Windows.Forms.PictureBox()
        Me.MusicBox = New System.Windows.Forms.PictureBox()
        Me.VideosBox = New System.Windows.Forms.PictureBox()
        Me.PicturesBox = New System.Windows.Forms.PictureBox()
        Me.ProfileBox = New System.Windows.Forms.PictureBox()
        Panel1 = New System.Windows.Forms.Panel()
        Label1 = New System.Windows.Forms.Label()
        Panel2 = New System.Windows.Forms.Panel()
        Label2 = New System.Windows.Forms.Label()
        Panel3 = New System.Windows.Forms.Panel()
        Label3 = New System.Windows.Forms.Label()
        Panel4 = New System.Windows.Forms.Panel()
        Label4 = New System.Windows.Forms.Label()
        Panel5 = New System.Windows.Forms.Panel()
        Label5 = New System.Windows.Forms.Label()
        Panel6 = New System.Windows.Forms.Panel()
        Label6 = New System.Windows.Forms.Label()
        Panel7 = New System.Windows.Forms.Panel()
        Label7 = New System.Windows.Forms.Label()
        Panel8 = New System.Windows.Forms.Panel()
        Label8 = New System.Windows.Forms.Label()
        Panel9 = New System.Windows.Forms.Panel()
        Label9 = New System.Windows.Forms.Label()
        Panel10 = New System.Windows.Forms.Panel()
        Label10 = New System.Windows.Forms.Label()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        Panel3.SuspendLayout()
        Panel4.SuspendLayout()
        Panel5.SuspendLayout()
        Panel6.SuspendLayout()
        Panel7.SuspendLayout()
        Panel8.SuspendLayout()
        Panel9.SuspendLayout()
        Panel10.SuspendLayout()
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ContactsBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DownloadsBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FavoritesBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DocumentsBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MusicBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VideosBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicturesBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProfileBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Panel1.Controls.Add(Label1)
        Panel1.Controls.Add(Me.ProfileBox)
        Panel1.Location = New System.Drawing.Point(11, 14)
        Panel1.Name = "Panel1"
        Panel1.Size = New System.Drawing.Size(127, 114)
        Panel1.TabIndex = 1
        '
        'Label1
        '
        Label1.Dock = System.Windows.Forms.DockStyle.Bottom
        Label1.Location = New System.Drawing.Point(0, 91)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(127, 23)
        Label1.TabIndex = 2
        Label1.Text = "Profile"
        Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel2
        '
        Panel2.Controls.Add(Label2)
        Panel2.Controls.Add(Me.PicturesBox)
        Panel2.Location = New System.Drawing.Point(144, 14)
        Panel2.Name = "Panel2"
        Panel2.Size = New System.Drawing.Size(127, 114)
        Panel2.TabIndex = 2
        '
        'Label2
        '
        Label2.Dock = System.Windows.Forms.DockStyle.Bottom
        Label2.Location = New System.Drawing.Point(0, 91)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(127, 23)
        Label2.TabIndex = 2
        Label2.Text = "Pictures"
        Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel3
        '
        Panel3.Controls.Add(Label3)
        Panel3.Controls.Add(Me.VideosBox)
        Panel3.Location = New System.Drawing.Point(277, 14)
        Panel3.Name = "Panel3"
        Panel3.Size = New System.Drawing.Size(127, 114)
        Panel3.TabIndex = 3
        '
        'Label3
        '
        Label3.Dock = System.Windows.Forms.DockStyle.Bottom
        Label3.Location = New System.Drawing.Point(0, 91)
        Label3.Name = "Label3"
        Label3.Size = New System.Drawing.Size(127, 23)
        Label3.TabIndex = 2
        Label3.Text = "Videos"
        Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(Me.MusicBox)
        Panel4.Location = New System.Drawing.Point(410, 11)
        Panel4.Name = "Panel4"
        Panel4.Size = New System.Drawing.Size(127, 114)
        Panel4.TabIndex = 4
        '
        'Label4
        '
        Label4.Dock = System.Windows.Forms.DockStyle.Bottom
        Label4.Location = New System.Drawing.Point(0, 91)
        Label4.Name = "Label4"
        Label4.Size = New System.Drawing.Size(127, 23)
        Label4.TabIndex = 2
        Label4.Text = "Music"
        Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel5
        '
        Panel5.Controls.Add(Label5)
        Panel5.Controls.Add(Me.DocumentsBox)
        Panel5.Location = New System.Drawing.Point(410, 131)
        Panel5.Name = "Panel5"
        Panel5.Size = New System.Drawing.Size(127, 114)
        Panel5.TabIndex = 5
        '
        'Label5
        '
        Label5.Dock = System.Windows.Forms.DockStyle.Bottom
        Label5.Location = New System.Drawing.Point(0, 91)
        Label5.Name = "Label5"
        Label5.Size = New System.Drawing.Size(127, 23)
        Label5.TabIndex = 2
        Label5.Text = "Documents"
        Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel6
        '
        Panel6.Controls.Add(Label6)
        Panel6.Controls.Add(Me.FavoritesBox)
        Panel6.Location = New System.Drawing.Point(11, 134)
        Panel6.Name = "Panel6"
        Panel6.Size = New System.Drawing.Size(127, 114)
        Panel6.TabIndex = 6
        '
        'Label6
        '
        Label6.Dock = System.Windows.Forms.DockStyle.Bottom
        Label6.Location = New System.Drawing.Point(0, 91)
        Label6.Name = "Label6"
        Label6.Size = New System.Drawing.Size(127, 23)
        Label6.TabIndex = 2
        Label6.Text = "Favorites"
        Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel7
        '
        Panel7.Controls.Add(Label7)
        Panel7.Controls.Add(Me.DownloadsBox)
        Panel7.Location = New System.Drawing.Point(144, 134)
        Panel7.Name = "Panel7"
        Panel7.Size = New System.Drawing.Size(127, 114)
        Panel7.TabIndex = 7
        '
        'Label7
        '
        Label7.Dock = System.Windows.Forms.DockStyle.Bottom
        Label7.Location = New System.Drawing.Point(0, 91)
        Label7.Name = "Label7"
        Label7.Size = New System.Drawing.Size(127, 23)
        Label7.TabIndex = 2
        Label7.Text = "Downloads"
        Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel8
        '
        Panel8.Controls.Add(Label8)
        Panel8.Controls.Add(Me.ContactsBox)
        Panel8.Location = New System.Drawing.Point(277, 134)
        Panel8.Name = "Panel8"
        Panel8.Size = New System.Drawing.Size(127, 114)
        Panel8.TabIndex = 8
        '
        'Label8
        '
        Label8.Dock = System.Windows.Forms.DockStyle.Bottom
        Label8.Location = New System.Drawing.Point(0, 91)
        Label8.Name = "Label8"
        Label8.Size = New System.Drawing.Size(127, 23)
        Label8.TabIndex = 2
        Label8.Text = "Contacts"
        Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel9
        '
        Panel9.Controls.Add(Label9)
        Panel9.Controls.Add(Me.PixieBox)
        Panel9.Location = New System.Drawing.Point(543, 11)
        Panel9.Name = "Panel9"
        Panel9.Size = New System.Drawing.Size(127, 114)
        Panel9.TabIndex = 9
        '
        'Label9
        '
        Label9.Dock = System.Windows.Forms.DockStyle.Bottom
        Label9.Location = New System.Drawing.Point(0, 91)
        Label9.Name = "Label9"
        Label9.Size = New System.Drawing.Size(127, 23)
        Label9.TabIndex = 2
        Label9.Text = "Pixie"
        Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel10
        '
        Panel10.Controls.Add(Label10)
        Panel10.Controls.Add(Me.PixieHelpBox)
        Panel10.Location = New System.Drawing.Point(543, 131)
        Panel10.Name = "Panel10"
        Panel10.Size = New System.Drawing.Size(127, 114)
        Panel10.TabIndex = 10
        '
        'Label10
        '
        Label10.Dock = System.Windows.Forms.DockStyle.Bottom
        Label10.Location = New System.Drawing.Point(0, 91)
        Label10.Name = "Label10"
        Label10.Size = New System.Drawing.Size(127, 23)
        Label10.TabIndex = 2
        Label10.Text = "Help"
        Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PixieHelpBox
        '
        Me.PixieHelpBox.BackgroundImage = Global.Pixie.My.Resources.AlertResources.HelpIcon
        Me.PixieHelpBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieHelpBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieHelpBox.Location = New System.Drawing.Point(20, 3)
        Me.PixieHelpBox.Name = "PixieHelpBox"
        Me.PixieHelpBox.Size = New System.Drawing.Size(85, 86)
        Me.PixieHelpBox.TabIndex = 2
        Me.PixieHelpBox.TabStop = False
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(20, 3)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(85, 86)
        Me.PixieBox.TabIndex = 2
        Me.PixieBox.TabStop = False
        '
        'ContactsBox
        '
        Me.ContactsBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.ContactsFolder128
        Me.ContactsBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ContactsBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ContactsBox.Location = New System.Drawing.Point(20, 3)
        Me.ContactsBox.Name = "ContactsBox"
        Me.ContactsBox.Size = New System.Drawing.Size(85, 86)
        Me.ContactsBox.TabIndex = 2
        Me.ContactsBox.TabStop = False
        '
        'DownloadsBox
        '
        Me.DownloadsBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.DownloadsFolder128
        Me.DownloadsBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DownloadsBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DownloadsBox.Location = New System.Drawing.Point(20, 3)
        Me.DownloadsBox.Name = "DownloadsBox"
        Me.DownloadsBox.Size = New System.Drawing.Size(85, 86)
        Me.DownloadsBox.TabIndex = 2
        Me.DownloadsBox.TabStop = False
        '
        'FavoritesBox
        '
        Me.FavoritesBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.FavoritesFolder128
        Me.FavoritesBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.FavoritesBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.FavoritesBox.Location = New System.Drawing.Point(20, 3)
        Me.FavoritesBox.Name = "FavoritesBox"
        Me.FavoritesBox.Size = New System.Drawing.Size(85, 86)
        Me.FavoritesBox.TabIndex = 2
        Me.FavoritesBox.TabStop = False
        '
        'DocumentsBox
        '
        Me.DocumentsBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.DocumentsFolder128
        Me.DocumentsBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DocumentsBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DocumentsBox.Location = New System.Drawing.Point(20, 3)
        Me.DocumentsBox.Name = "DocumentsBox"
        Me.DocumentsBox.Size = New System.Drawing.Size(85, 86)
        Me.DocumentsBox.TabIndex = 2
        Me.DocumentsBox.TabStop = False
        '
        'MusicBox
        '
        Me.MusicBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.MusicFolder128
        Me.MusicBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MusicBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MusicBox.Location = New System.Drawing.Point(20, 3)
        Me.MusicBox.Name = "MusicBox"
        Me.MusicBox.Size = New System.Drawing.Size(85, 86)
        Me.MusicBox.TabIndex = 2
        Me.MusicBox.TabStop = False
        '
        'VideosBox
        '
        Me.VideosBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.VideosFolder128
        Me.VideosBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.VideosBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.VideosBox.Location = New System.Drawing.Point(20, 3)
        Me.VideosBox.Name = "VideosBox"
        Me.VideosBox.Size = New System.Drawing.Size(85, 86)
        Me.VideosBox.TabIndex = 2
        Me.VideosBox.TabStop = False
        '
        'PicturesBox
        '
        Me.PicturesBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PicturesFolder128
        Me.PicturesBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PicturesBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicturesBox.Location = New System.Drawing.Point(20, 3)
        Me.PicturesBox.Name = "PicturesBox"
        Me.PicturesBox.Size = New System.Drawing.Size(85, 86)
        Me.PicturesBox.TabIndex = 2
        Me.PicturesBox.TabStop = False
        '
        'ProfileBox
        '
        Me.ProfileBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.UserProfileFolder128
        Me.ProfileBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ProfileBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ProfileBox.Location = New System.Drawing.Point(20, 3)
        Me.ProfileBox.Name = "ProfileBox"
        Me.ProfileBox.Size = New System.Drawing.Size(85, 86)
        Me.ProfileBox.TabIndex = 2
        Me.ProfileBox.TabStop = False
        '
        'SpecialFoldersDlg
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 259)
        Me.Controls.Add(Panel10)
        Me.Controls.Add(Panel9)
        Me.Controls.Add(Panel8)
        Me.Controls.Add(Panel7)
        Me.Controls.Add(Panel6)
        Me.Controls.Add(Panel5)
        Me.Controls.Add(Panel4)
        Me.Controls.Add(Panel3)
        Me.Controls.Add(Panel2)
        Me.Controls.Add(Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SpecialFoldersDlg"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Special Folders"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel3.ResumeLayout(False)
        Panel4.ResumeLayout(False)
        Panel5.ResumeLayout(False)
        Panel6.ResumeLayout(False)
        Panel7.ResumeLayout(False)
        Panel8.ResumeLayout(False)
        Panel9.ResumeLayout(False)
        Panel10.ResumeLayout(False)
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ContactsBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DownloadsBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FavoritesBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DocumentsBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MusicBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VideosBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicturesBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProfileBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ProfileBox As PictureBox
    Friend WithEvents PicturesBox As PictureBox
    Friend WithEvents VideosBox As PictureBox
    Friend WithEvents MusicBox As PictureBox
    Friend WithEvents DocumentsBox As PictureBox
    Friend WithEvents FavoritesBox As PictureBox
    Friend WithEvents DownloadsBox As PictureBox
    Friend WithEvents ContactsBox As PictureBox
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents PixieHelpBox As PictureBox
End Class
