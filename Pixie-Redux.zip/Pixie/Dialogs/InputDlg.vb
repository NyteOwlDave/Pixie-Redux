﻿Imports System.Windows.Forms

Public Class InputDlg

    ' Input:
    ' Set to TRUE if dialog REQUIRES an answer
    Public RequireAnswer As Boolean = False

    ' Input:
    ' What to show in the help box
    ' Set this before calling ShowDialog
    Public QueryMessage As String = ""

    ' Input:
    ' The string to be edited
    ' Output:
    ' The result, if OK was pressed. Otherwise, unchanged.
    Public InputText As String = ""

    ' Show help message
    Private Sub ShowHelp(msg As String)
        If msg.Length < 1 Then
            ShowErrorBox("No query message was provided by the programmer.")
            QueryMessage = "Please contact Dave, since a programming error has occured."
            msg = QueryMessage
        End If
        Me.HelpBox.Text = msg
    End Sub

    ' Show query message
    Private Sub ShowQueryMessage()
        ShowHelp(QueryMessage)
    End Sub

    ' Show query message
    Private Sub InitInputText()
        InputText = InputText.Trim()
        If RequireAnswer Then
            If InputText.Length < 1 Then
                ShowErrorBox("Dialogs that require an answer should set the InputText member before" &
                             " invoking the InputDlg.ShowDialog() method.")
                InputText = "unknown value"
            End If
        End If
        InputBox.Text = InputText
    End Sub

    ' Update input text
    Private Sub UpdateInputText()
        InputText = InputBox.Text.Trim()
    End Sub

    ' OK button clicked
    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        UpdateInputText()
        If RequireAnswer Then
            If InputText.Length < 1 Then
                ShowInfoBox("This information is required. Please enter a value.")
                Return
            End If
        End If
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    ' Form load event
    Private Sub InputDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ShowQueryMessage()
        InitInputText()
    End Sub

    ' Public static function to show the dialog
    'Public Shared Function Execute(parent As Form, msg As String, value As String) As String
    '    Dim dlg As New InputDlg
    '    dlg.InputText = value
    '    dlg.QueryMessage = msg
    '    Dim r As DialogResult
    '    Try
    '        r = dlg.ShowDialog(parent)
    '        value = dlg.InputText
    '    Catch ex As Exception
    '        ShowErrorBox(ex.Message)
    '        r = DialogResult.Abort
    '    Finally
    '        dlg.Dispose()
    '    End Try
    '    Return value
    'End Function

    ' Form closing event
    Private Sub InputDlg_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If RequireAnswer Then
            If InputText.Length < 1 Then
                ShowInfoBox("This information is required. Please enter a value.")
                e.Cancel = True
            End If
        End If
    End Sub

    ' Shared helper function to simplify dialog usage
    Public Shared Function Execute(query As String, input As String, required As Boolean) As String
        Dim parent As Form = My.Application.OpenForms(0)
        Dim dlg As New InputDlg
        dlg.QueryMessage = query
        dlg.InputText = input
        dlg.RequireAnswer = required
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If result = DialogResult.OK Then
            input = dlg.InputText
        End If
        dlg.Dispose()
        Return input
    End Function

End Class
