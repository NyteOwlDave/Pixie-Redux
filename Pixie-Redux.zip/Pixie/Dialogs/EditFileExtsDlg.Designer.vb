﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EditFileExtsDlg
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("TXT", 0)
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EditFileExtsDlg))
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.RemoveButton = New System.Windows.Forms.Button()
        Me.ExtBox = New System.Windows.Forms.TextBox()
        Me.ExtsListView = New System.Windows.Forms.ListView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'OK_Button
        '
        Me.OK_Button.Location = New System.Drawing.Point(380, 4)
        Me.OK_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(89, 28)
        Me.OK_Button.TabIndex = 0
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(477, 4)
        Me.Cancel_Button.Margin = New System.Windows.Forms.Padding(4)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(89, 28)
        Me.Cancel_Button.TabIndex = 1
        Me.Cancel_Button.Text = "Cancel"
        '
        'AddButton
        '
        Me.AddButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.AddButton.Location = New System.Drawing.Point(198, 4)
        Me.AddButton.Margin = New System.Windows.Forms.Padding(4)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(74, 28)
        Me.AddButton.TabIndex = 2
        Me.AddButton.Text = "Add"
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.Cancel_Button)
        Me.Panel1.Controls.Add(Me.OK_Button)
        Me.Panel1.Controls.Add(Me.RemoveButton)
        Me.Panel1.Controls.Add(Me.ExtBox)
        Me.Panel1.Controls.Add(Me.AddButton)
        Me.Panel1.Location = New System.Drawing.Point(12, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(568, 37)
        Me.Panel1.TabIndex = 3
        '
        'RemoveButton
        '
        Me.RemoveButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.RemoveButton.Location = New System.Drawing.Point(280, 4)
        Me.RemoveButton.Margin = New System.Windows.Forms.Padding(4)
        Me.RemoveButton.Name = "RemoveButton"
        Me.RemoveButton.Size = New System.Drawing.Size(92, 28)
        Me.RemoveButton.TabIndex = 3
        Me.RemoveButton.Text = "Remove"
        '
        'ExtBox
        '
        Me.ExtBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExtBox.Location = New System.Drawing.Point(3, 5)
        Me.ExtBox.Name = "ExtBox"
        Me.ExtBox.Size = New System.Drawing.Size(186, 27)
        Me.ExtBox.TabIndex = 0
        '
        'ExtsListView
        '
        Me.ExtsListView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExtsListView.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1})
        Me.ExtsListView.LabelEdit = True
        Me.ExtsListView.LabelWrap = False
        Me.ExtsListView.LargeImageList = Me.ImageList1
        Me.ExtsListView.Location = New System.Drawing.Point(15, 55)
        Me.ExtsListView.Name = "ExtsListView"
        Me.ExtsListView.Size = New System.Drawing.Size(562, 171)
        Me.ExtsListView.SmallImageList = Me.ImageList1
        Me.ExtsListView.TabIndex = 4
        Me.ExtsListView.UseCompatibleStateImageBehavior = False
        Me.ExtsListView.View = System.Windows.Forms.View.List
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "FileExt24.png")
        '
        'EditFileExtsDlg
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(592, 239)
        Me.Controls.Add(Me.ExtsListView)
        Me.Controls.Add(Me.Panel1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(610, 286)
        Me.Name = "EditFileExtsDlg"
        Me.ShowInTaskbar = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Filename Extensions"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Friend WithEvents AddButton As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents RemoveButton As Button
    Friend WithEvents ExtBox As TextBox
    Friend WithEvents ExtsListView As ListView
    Friend WithEvents ImageList1 As ImageList
End Class
