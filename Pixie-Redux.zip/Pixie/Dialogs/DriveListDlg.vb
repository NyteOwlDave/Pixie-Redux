﻿Imports System.Windows.Forms
Imports System.IO

Public Class DriveListDlg

    Enum IconIndex
        FlashDrive = 0
        SDCard = 1
        Desktop = 2
        Fixed = 3
        Net = 4
        NoRoot = 5
        Optical = 6
        Pixie = 7
        RAM = 8
        Removable = 9
        Unknown = 10
    End Enum

    ' Input:
    ' Invoking function should set this to the desired condition
    ' before calling ShowDialog...
    Public ShowAllDrives As Boolean = True

    ' Input:
    ' Flag to indicate that we want to choose a drive, rather
    ' than merely looking. If true, double-clicking the drive
    ' saves the root path in the SelectedPath member and closes
    ' the dialog, rather than invoking the browser.
    Public SelectDrive As Boolean = False

    ' Output:
    ' If SelectDrive was set to TRUE, this will contain the root
    ' directory path for the selected drive after the dialog closes.
    ' This is only true if the dialog was closed by double-clicking
    ' on a drive icon.
    Public SelectedDrive As String = ""

#Region "Help System"

    ' Show help text
    Public Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Show standard help message
    Public Sub ShowStandardHelp()
        ShowHelp(My.Resources.DefaultHelpMsg)
    End Sub

#End Region

    Private Sub EndDialog(result As DialogResult)
        Me.DialogResult = result
        Me.Close()
    End Sub

    ' Clear the list of drives
    Private Sub ClearDriveList()
        DriveListView.Items.Clear()
    End Sub

    ' Get icon index for IO.DriveType
    Private Function GetIconIndex(dt As IO.DriveType) As Integer
        Select Case dt
            Case IO.DriveType.CDRom
                Return IconIndex.Optical
            Case IO.DriveType.Fixed
                Return IconIndex.Fixed
            Case IO.DriveType.Network
                Return IconIndex.Net
            Case IO.DriveType.NoRootDirectory
                Return IconIndex.NoRoot
            Case IO.DriveType.Ram
                Return IconIndex.RAM
            Case IO.DriveType.Removable
                If (My.Settings.CurrentDriveType = DriveType.SDCard) Then
                    Return IconIndex.SDCard
                Else
                    Return IconIndex.FlashDrive
                End If
            Case Else
                Return IconIndex.Unknown
        End Select
    End Function

    ' Compose label for list item from IO.DriveType
    Private Function ComposeItemText(info As IO.DriveInfo) As String
        Dim letter As String
        Dim name As String
        If info.IsReady Then
            Try
                name = info.VolumeLabel
                If name Is Nothing Then
                    name = ""
                End If
            Catch ex As Exception
                name = ""
            End Try
        Else
            name = "No media"
        End If
        If name.Length < 1 Then
            name = "Untitled"
        End If
        letter = " (" + info.Name(0) + ":)"
        Return name + letter
    End Function

    ' Populate drive list
    Private Sub PopulateDriveList()
        ClearDriveList()
        Dim info As DriveInfo
        Dim drives As DriveInfo()
        Dim item As ListViewItem
        drives = System.IO.DriveInfo.GetDrives()
        If Not drives Is Nothing Then
            If Me.ShowAllDrives Then
                Me.Text = "All Drives"
                For n As Integer = 1 To drives.Count
                    info = drives.ElementAt(n - 1)
                    item = New ListViewItem
                    item.Text = ComposeItemText(info)
                    item.ImageIndex = GetIconIndex(info.DriveType)
                    item.Tag = info.Name.Chars(0)
                    DriveListView.Items.Add(item)
                Next
            Else
                Me.Text = "Removable Drives"
                For n As Integer = 1 To drives.Count
                    info = drives.ElementAt(n - 1)
                    If info.DriveType = IO.DriveType.Removable Then
                        item = New ListViewItem
                        item.Text = ComposeItemText(info)
                        item.ImageIndex = GetIconIndex(info.DriveType)
                        item.Tag = info.Name.Chars(0)
                        DriveListView.Items.Add(item)
                    End If
                Next
            End If
        End If
    End Sub

    ' Get drive letter for item double-clicked in drive list view control
    Private Function GetSelectedDrive() As String
        Dim drive As String = ""
        Timer1.Enabled = False
        Try
            Dim ch As Char
            ch = CType(DriveListView.SelectedItems(0).Tag, Char)
            drive = ch + ":\"
        Catch ex As OutOfMemoryException
            Throw
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            Timer1.Enabled = True
        End Try
        Return drive
    End Function

    ' Load event
    Private Sub DriveListDlg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        PopulateDriveList()
        Timer1.Interval = 2000
        Timer1.Enabled = True
    End Sub

    ' Mouse click on pixie box
    Private Sub DriveListView_DoubleClick(sender As Object, e As EventArgs) Handles DriveListView.MouseDoubleClick
        Dim drive As String = GetSelectedDrive()
        If SelectDrive Then
            SelectedDrive = drive
            EndDialog(DialogResult.OK)
        Else
            Explore(drive)
        End If
    End Sub

    ' Mouse click on pixie box
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        Timer1.Enabled = False
        Try
            My.Settings.UserName = "<reset>"
            ChooseUserName()
        Catch ex As OutOfMemoryException
            Throw
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            Timer1.Enabled = True
        End Try
    End Sub

    ' Mouse click on computer box
    Private Sub ComputerBox_Click(sender As Object, e As EventArgs) Handles ComputerBox.Click
        Me.ShowAllDrives = True
        PopulateDriveList()
    End Sub

    ' Mouse click on drive box
    Private Sub DriveBox_Click(sender As Object, e As EventArgs) Handles DriveBox.Click
        Me.ShowAllDrives = False
        PopulateDriveList()
    End Sub

    ' Mouse entering pixie box
    Private Sub PixieBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieBox.MouseEnter
        ShowHelp("Click on my picture to change the name I greet you with.")
    End Sub

    ' Mouse leaving pixie box
    Private Sub PixieBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering computer box
    Private Sub ComputerBox_MouseEnter(sender As Object, e As EventArgs) Handles ComputerBox.MouseEnter
        ShowHelp("Click here to show all available drives for your computer.")
    End Sub

    ' Mouse leaving computer box
    Private Sub ComputerBox_MouseLeave(sender As Object, e As EventArgs) Handles ComputerBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering drive box
    Private Sub DriveBox_MouseEnter(sender As Object, e As EventArgs) Handles DriveBox.MouseEnter
        ShowHelp("Click here to see a list of just removable drives.")
    End Sub

    ' Mouse entering drive box
    Private Sub DriveBox_MouseLeave(sender As Object, e As EventArgs) Handles DriveBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering drive box
    Private Sub DriveListView_MouseEnter(sender As Object, e As EventArgs) Handles DriveListView.MouseEnter
        ShowHelp("Double-click on a drive to explore its content.")
    End Sub

    ' Mouse entering drive box
    Private Sub DriveListView_MouseLeave(sender As Object, e As EventArgs) Handles DriveListView.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Timer tick event
    ' Checks to see if a removable drive has been inserted or removed
    ' If so, updates the drive list
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim drives As IO.DriveInfo()
        drives = IO.DriveInfo.GetDrives()
        Dim count1 As Integer = DriveListView.Items.Count
        Dim count2 As Integer = drives.Count
        If Me.ShowAllDrives Then
            If (count1 = count2) Then Return
        Else
            Dim info As IO.DriveInfo
            Dim n As Integer
            Dim m As Integer = 0
            For n = 1 To count2
                info = drives.ElementAt(n - 1)
                If info.DriveType = IO.DriveType.Removable Then
                    m += 1
                End If
            Next
            If count1 = m Then
                Return
            End If
        End If
        PopulateDriveList()
    End Sub

End Class

Class FormManager

    ' Read-only access to the main form
    Public Shared ReadOnly Property Main As Form
        Get
            With My.Application
                Return .OpenForms(0)
            End With
        End Get
    End Property

    ' Determine if specified form is the main form
    Public Shared Function IsMain(frm As Form) As Boolean
        If frm Is Nothing Then Return False
        With My.Application
            If .OpenForms(0) Is frm Then
                Return True
            End If
        End With
        Return False
    End Function

    ' Determine if specified form is open
    Public Shared Function IsOpen(frm As Form) As Boolean
        With My.Application
            Dim item As Form
            For Each item In .OpenForms
                If item Is frm Then Return True
            Next
        End With
        Return False
    End Function

    ' Find first occurance of named form
    Public Shared Function FindFirst(name As String) As Form
        If name Is Nothing Then Return Nothing
        If name.Length < 1 Then Return Nothing
        With My.Application
            Dim other As Type
            Dim item As Form
            For Each item In .OpenForms
                other = item.GetType()
                If other.Name = name Then
                    Return item
                End If
            Next
        End With
        Return Nothing
    End Function

End Class