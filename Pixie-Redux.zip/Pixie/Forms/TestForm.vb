﻿
Imports System.Text.RegularExpressions

Public Class TestForm

    Private Sub Test1()
        TestJobLog()
    End Sub

    Private Sub Test2()
        Dim r As New Regex("[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?")
        Dim arg As String
        Dim title As String = "Regex test"
        Dim msg As String = "Please enter a floating point number."
        arg = InputBox(msg, title, "-1.2e+3")
        If r.IsMatch(arg) Then
            ShowInfoBox("The number is well formed.")
        Else
            ShowWarnBox("The number is ill-formed!")
        End If
    End Sub

    Public Sub Test3()
        Dim pattern As String = "\b(\w+?)\s\1\b"
        Dim input As String = "This this is a nice day. What about this? This tastes good. I saw a a dog."
        For Each match As Match In Regex.Matches(input, pattern, RegexOptions.IgnoreCase)
            Console.WriteLine("{0} (duplicates '{1}') at position {2}",
                           match.Value, match.Groups(1).Value, match.Index)
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            ShowInfoBox("You need to create a test function in TestForm.vb!")
            ' Test2()
        Catch ex As Exception
            ShowWarnBox(ex.Message)
        End Try
    End Sub

End Class

