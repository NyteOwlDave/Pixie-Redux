﻿
Imports System.ComponentModel

Public Class BrowserForm

    ' Input:
    ' Home page
    Public Shared Property HomePage As String
        Get
            Return NCS.HomePage
        End Get
        Set(value As String)
            NCS.HomePage = value
        End Set
    End Property

    ' Helper static function to simplify showing the browser form
    Public Shared Sub Execute(url As String)
        Dim s As String = url.Trim()
        If s.Length < 1 Then s = "C:\"
        Dim frm As New BrowserForm
        BrowserForm.HomePage = s
        frm.Show()
    End Sub

    ' Canonicalize a pathname
    Public Function Canonicalize(pathName As String) As String
        ' TODO...
        Return pathName
    End Function

    ' Access to current page as a URL string
    Public Property CurrentPage As String
        Get
            Return MyWebBrowser.Url.AbsoluteUri
        End Get
        Set(value As String)
            NavigateTo(value)
        End Set
    End Property

#Region "Read-only access to local pathname or URL being shown in the browser"

    ' Get the current absolute pathname as shown in the browser control.
    ' Returns an empty string if the location is not in the local file system.
    Private ReadOnly Property LocalPath As String
        Get
            If MyWebBrowser.Url IsNot Nothing Then
                With MyWebBrowser.Url
                    If .IsFile Then
                        Return .LocalPath
                    End If
                End With
            End If
            Return ""
        End Get
    End Property

    ' Gets the URL currently displayed in the browser.
    ' Returns an empty string if the current location is on the local file system
    Private ReadOnly Property RemoteSite As String
        Get
            If MyWebBrowser.Url IsNot Nothing Then
                With MyWebBrowser.Url
                    If .IsAbsoluteUri Then
                        Return .AbsoluteUri
                    End If
                End With
            End If
            Return ""
        End Get
    End Property

#End Region

#Region "Omnibar Features"

    ' Get text from omnibar
    Private Function GetOmniBarText() As String
        Return OmniBar.Text
    End Function

    ' Set omnibar text
    Private Sub SetOmniBarText(url As String)
        OmniBar.Text = url
    End Sub

#End Region

#Region "Help Messages"

    ' Show help
    Private Sub ShowHelp(msg As String)
        Me.HelpBox.Text = msg
    End Sub

    ' Show standard help
    Private Sub ShowStandardHelp()
        ShowHelp(My.Resources.DefaultHelpMsg)
    End Sub

#End Region

#Region "Navigation"

    ' Navigate to help file
    Private Sub NavigateToHelp()
        Dim path As String
        path = AppDomain.CurrentDomain().BaseDirectory()
        If Not (path.EndsWith("\") Or path.EndsWith("/")) Then
            path = path + "\Content\" + My.Resources.HelpFileName
        Else
            path = path + "Content\" + My.Resources.HelpFileName
        End If
        NavigateTo(path)
    End Sub

    ' Navigate up one level in the path
    Private Sub NavigateUp()
        Dim path As String = MyWebBrowser.Url.AbsoluteUri
        Dim index As Integer = path.LastIndexOfAny("/\")
        If (index < 0) Then Return
        path = path.Substring(0, index)
        If path.EndsWith(":") Then
            path += "/"
        End If
        NavigateTo(path)
    End Sub

    ' Navigate to specified URL
    Private Sub NavigateTo(url As String)
        Try
            MyWebBrowser.Navigate(url)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Navigate home
    Private Sub NavigateHome()
        NavigateTo(HomePage)
    End Sub

    ' Navigate to past page
    Private Sub NavigateBack()
        Try
            MyWebBrowser.GoBack()
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Navigate forward
    Private Sub NavigateForward()
        Try
            MyWebBrowser.GoForward()
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Refresh
    Private Sub RefreshPage()
        Try
            MyWebBrowser.Refresh()
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

#End Region

#Region "Form Event Handlers"

    ' Form load event
    Private Sub BrowserForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the entire application
        If Not MainModule.Initialize(Me) Then
            Me.Close()
            Return
        End If
        ' Check for reset
        If NCS.RecentPage = "<reset>" Then
            NCS.RecentPage = ""
        End If
        ' If no recent page
        If NCS.RecentPage.Length < 1 Then
            ' If user's pictures folder exists
            If IO.Directory.Exists(My.Settings.PicturesFolder) Then
                ' Visit there by default
                NCS.RecentPage = My.Settings.PicturesFolder
            Else
                ' If home page exists
                If IO.Directory.Exists(NCS.HomePage) Then
                    ' Just use home page
                    NCS.RecentPage = NCS.HomePage
                Else
                    ' Use the profile folder for this user
                    NCS.RecentPage = GetUserProfileFolder()
                End If
            End If
        End If
        ' Navigate to recent page
        Me.CurrentPage = NCS.RecentPage
    End Sub

    ' Form closed event
    Private Sub BrowserForm_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        ' Save recent page
        NCS.RecentPage = Me.CurrentPage
        ' Save browser settings
        NCS.SaveBrowserSettings()
    End Sub

#End Region

#Region "Web Browser Control Event Handlers"

    ' After browser has finished navigating
    Private Sub MyWebBrowser_Navigated(sender As Object, e As WebBrowserNavigatedEventArgs) Handles MyWebBrowser.Navigated
        SetOmniBarText(MyWebBrowser.Url.AbsoluteUri)
    End Sub

#End Region

#Region "Button Click Events"

    ' Home button clicked
    Private Sub HomeButton_Click(sender As Object, e As EventArgs) Handles HomeButton.Click
        NavigateHome()
    End Sub

    ' Root button clicked
    Private Sub RootButton_Click(sender As Object, e As EventArgs) Handles RootButton.Click
        NavigateTo(RootButton.Text)
    End Sub

    ' Up button clicked
    Private Sub UpButton_Click(sender As Object, e As EventArgs) Handles UpButton.Click
        NavigateUp()
    End Sub

    ' Back button clicked
    Private Sub BackButton_Click(sender As Object, e As EventArgs) Handles BackButton.Click
        NavigateBack()
    End Sub

    ' Forward button clicked
    Private Sub ForwardButton_Click(sender As Object, e As EventArgs) Handles ForwardButton.Click
        NavigateForward()
    End Sub

    ' Back button clicked
    Private Sub RefreshButton_Click(sender As Object, e As EventArgs) Handles RefreshButton.Click
        Me.MyWebBrowser.Refresh()
    End Sub

    ' Favorites button clicked
    Private Sub FavoritesButton_Click(sender As Object, e As EventArgs) Handles FavoritesButton.Click
        ' TODO...
        ShowToDo(Me.HelpBox)
    End Sub

    ' History button clicked
    Private Sub HistoryButton_Click(sender As Object, e As EventArgs) Handles HistoryButton.Click
        ' TODO...
        ShowToDo(Me.HelpBox)
    End Sub

    ' Tools button clicked
    Private Sub ToolsButton_Click(sender As Object, e As EventArgs) Handles ToolsButton.Click
        ' TODO...
        ShowToDo(Me.HelpBox)
    End Sub

    ' Setup button clicked
    Private Sub SetupButton_Click(sender As Object, e As EventArgs) Handles SetupButton.Click
        ' TODO...
        ShowToDo(Me.HelpBox)
    End Sub

    ' Pixie box clicked
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        Dim frm As Form
        For Each frm In My.Application.OpenForms
            If frm.Name = "PixieForm" Then
                frm.Show()
                frm.Activate()
                Return
            End If
        Next
        frm = New PixieForm
        frm.Show()
        frm.Activate()
    End Sub

    ' Launch box clicked
    Private Sub LaunchBox_Click(sender As Object, e As EventArgs) Handles LaunchBox.Click
        Dim path As String = GetDefaultBrowser()
        If path Is Nothing Then path = ""
        If path.Length < 1 Then
            ShowHelp("I was unable to determine your usual primary browser.")
            Return
        End If
        ShellOpen(path, MyWebBrowser.Url.AbsoluteUri)
    End Sub

    ' Explorer box clicked
    Private Sub ExploreBox_Click(sender As Object, e As EventArgs) Handles ExploreBox.Click
        If (Me.MyWebBrowser.Url.IsFile) Then
            ShellOpen("explorer.exe", Me.LocalPath)
        Else
            ShellOpen("explorer.exe", Me.RemoteSite)
        End If
    End Sub

    ' Pick folder box clicked
    Private Sub PickFolderBox_Click(sender As Object, e As EventArgs) Handles PickFolderBox.Click
        Try
            ' Get path on local file system (if possible)
            Dim folder As String = LocalPath
            If folder Is Nothing Then folder = ""
            ' If web browser isn't browsing on the local file system
            If folder.Length < 1 Then
                ' Just use the root directory of the C: drive
                folder = "C:\"
            End If
            ' Initialize the folder picker dialog
            Dim dlg As New PickFolderDlg
            dlg.HelpMessage = "Choose a folder to browse."
            dlg.LookForFolder = folder
            dlg.RootPath = IO.Path.GetPathRoot(folder)
            dlg.AutoMode = PickFolderDlg.AutoModeEnum.Browse
            ' Invoke the dialog
            Dim result As DialogResult
            result = dlg.ShowDialog(Me)
            ' Make sure the user clicked the OK button
            If result <> DialogResult.OK Then Return
            ' Get the path to the folder selected by the user
            folder = dlg.SelectedPath
            If folder Is Nothing Then folder = ""
            ' If the selected path isn't an empty string...
            If folder.Length > 0 Then
                ' Navigate to this path
                NavigateTo(folder)
            Else
                ShowErrorBox("Result of folder picker dialog was an empty string.")
            End If
        Catch ex As OutOfMemoryException ' We never handle these!!!
            Throw
        Catch ex As Exception ' Everything else results in a popup
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Show drives box clicked
    Private Sub ShowDrivesBox_Click(sender As Object, e As EventArgs) Handles ShowDrivesBox.Click
        Try
            Dim dlg As New DriveListDlg
            dlg.ShowAllDrives = True
            dlg.SelectDrive = True
            Dim result As DialogResult
            result = dlg.ShowDialog(Me)
            If result = DialogResult.OK Then
                NavigateTo(dlg.SelectedDrive)
            End If
            dlg.Dispose()
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Pixie help box clicked
    Private Sub PixieHelpBox_Click(sender As Object, e As EventArgs) Handles PixieHelpBox.Click
        NavigateToHelp()
    End Sub

#End Region

#Region "Mouse Enter/Leave/Hover Events"

    ' Mouse entered favorites button
    Private Sub FavoritesButton_MouseEnter(sender As Object, e As EventArgs) Handles FavoritesButton.MouseEnter
        ShowHelp("Click here to see your favorite places.")
    End Sub

    ' Mouse left favorites button
    Private Sub FavoritesButton_MouseLeave(sender As Object, e As EventArgs) Handles FavoritesButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered forward button
    Private Sub ForwardButton_MouseEnter(sender As Object, e As EventArgs) Handles ForwardButton.MouseEnter
        ShowHelp("Click here to undo the most recent navigate back action.")
    End Sub

    ' Mouse left forward button
    Private Sub ForwardButton_MouseLeave(sender As Object, e As EventArgs) Handles ForwardButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered history button
    Private Sub HistoryButton_MouseEnter(sender As Object, e As EventArgs) Handles HistoryButton.MouseEnter
        ShowHelp("Click here to see the recent history of places you've browsed.")
    End Sub

    ' Mouse left history button
    Private Sub HistoryButton_MouseLeave(sender As Object, e As EventArgs) Handles HistoryButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered home button
    Private Sub HomeButton_MouseEnter(sender As Object, e As EventArgs) Handles HomeButton.MouseEnter
        ShowHelp("Click here to return to the first place you visited when the window was opened.")
    End Sub

    ' Mouse left home button
    Private Sub HomeButton_MouseLeave(sender As Object, e As EventArgs) Handles HomeButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered launch box
    Private Sub LaunchBox_MouseEnter(sender As Object, e As EventArgs) Handles LaunchBox.MouseEnter
        ShowHelp("Click here to open your primary web browser to view this web page.")
    End Sub

    ' Mouse left launch box
    Private Sub LaunchBox_MouseLeave(sender As Object, e As EventArgs) Handles LaunchBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered omnibar text control
    Private Sub OmniBar_MouseEnter(sender As Object, e As EventArgs) Handles OmniBar.MouseEnter
        ShowHelp("Enter the location of a web site or local path on your computer and press <Enter> to go there.")
    End Sub

    ' Mouse left omnibar text control
    Private Sub OmniBar_MouseLeave(sender As Object, e As EventArgs) Handles OmniBar.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered pick folder box
    Private Sub PickFolderBox_MouseEnter(sender As Object, e As EventArgs) Handles PickFolderBox.MouseEnter
        ShowHelp("Click here to chose a folder on your computer to browse.")
    End Sub

    ' Mouse left pick folder box
    Private Sub PickFolderBox_MouseLeave(sender As Object, e As EventArgs) Handles PickFolderBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered pixie box
    Private Sub PixieBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieBox.MouseEnter
        ShowHelp("Click here to copy picture files to or from removable drives.")
    End Sub

    ' Mouse left pixie box
    Private Sub PixieBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered refresh button
    Private Sub RefreshButton_MouseEnter(sender As Object, e As EventArgs) Handles RefreshButton.MouseEnter
        ShowHelp("Click here to refresh the browser content.")
    End Sub

    ' Mouse left refresh button
    Private Sub RefreshButton_MouseLeave(sender As Object, e As EventArgs) Handles RefreshButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered root button
    Private Sub RootButton_MouseEnter(sender As Object, e As EventArgs) Handles RootButton.MouseEnter
        ShowHelp("Click here to browse the root directory of the primary hard drive on your computer.")
    End Sub

    ' Mouse left root button
    Private Sub RootButton_MouseLeave(sender As Object, e As EventArgs) Handles RootButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered setup button
    Private Sub SetupButton_MouseEnter(sender As Object, e As EventArgs) Handles SetupButton.MouseEnter
        ShowHelp("Click here change the browser settings. This is an advanced feature")
    End Sub

    ' Mouse left setup button
    Private Sub SetupButton_MouseLeave(sender As Object, e As EventArgs) Handles SetupButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered show drives button
    Private Sub ShowDrivesBox_MouseEnter(sender As Object, e As EventArgs) Handles ShowDrivesBox.MouseEnter
        ShowHelp("Click here to choose a disk drive to browse.")
    End Sub

    ' Mouse left show drives box
    Private Sub ShowDrivesBox_MouseLeave(sender As Object, e As EventArgs) Handles ShowDrivesBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered tools button
    Private Sub ToolsButton_MouseEnter(sender As Object, e As EventArgs) Handles ToolsButton.MouseEnter
        ShowHelp("Click here to work with other helpful programs. This is an advanced feature.")
    End Sub

    ' Mouse left tools button
    Private Sub ToolsButton_MouseLeave(sender As Object, e As EventArgs) Handles ToolsButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered up button
    Private Sub UpButton_MouseEnter(sender As Object, e As EventArgs) Handles UpButton.MouseEnter
        ShowHelp("Click here to navigate up one level in the current path.")
    End Sub

    ' Mouse left up button
    Private Sub UpButton_MouseLeave(sender As Object, e As EventArgs) Handles UpButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered back button button
    Private Sub BackButton_MouseEnter(sender As Object, e As EventArgs) Handles BackButton.MouseEnter
        ShowHelp("Click here to go back to the previous place you were browsing.")
    End Sub

    ' Mouse left back button
    Private Sub BackButton_MouseLeave(sender As Object, e As EventArgs) Handles BackButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered explore box
    Private Sub ExploreBox_MouseEnter(sender As Object, e As EventArgs) Handles ExploreBox.MouseEnter
        ShowHelp("Click here to examine this location with the Windows Explorer.")
    End Sub

    ' Mouse left explore box
    Private Sub ExploreBox_MouseLeave(sender As Object, e As EventArgs) Handles ExploreBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered pixie help box
    Private Sub PixieHelpBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieHelpBox.MouseEnter
        ShowHelp("Click here to see my help documentation.")
    End Sub

    ' Mouse left pixie help box
    Private Sub PixieHelpBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieHelpBox.MouseLeave
        ShowStandardHelp()
    End Sub

#End Region

#Region "OmniBar Event handlers"

    ' Keypress event on omnibar
    Private Sub OmniBar_KeyUp(sender As Object, e As KeyEventArgs) Handles OmniBar.KeyUp
        If e.KeyCode = Keys.Return Then
            If sender IsNot Me.OmniBar Then
                e.Handled = False
                Return
            End If
            e.Handled = True
            Dim uri As String = Me.OmniBar.Text.Trim()
            If uri.Length < 1 Then
                ShowInfoBox("You must type in a web address or local path before pressing enter.")
                Return
            End If
            NavigateTo(uri)
        Else
            e.Handled = False
        End If
    End Sub

#End Region

#Region "Web Browser control event handlers"

    ' Can go back changed states
    Private Sub MyWebBrowser_CanGoBackChanged(sender As Object, e As EventArgs) Handles MyWebBrowser.CanGoBackChanged
        Me.BackButton.Enabled = MyWebBrowser.CanGoBack
    End Sub

    ' Can go forward changed states
    Private Sub MyWebBrowser_CanGoForwardChanged(sender As Object, e As EventArgs) Handles MyWebBrowser.CanGoForwardChanged
        Me.ForwardButton.Enabled = MyWebBrowser.CanGoForward
    End Sub

#End Region

End Class

