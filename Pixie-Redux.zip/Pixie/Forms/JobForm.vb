﻿
Public Class JobForm

    ' Internal instance of pixie job class
    Private myPixieJob As New PixieJob

    ' Show help message
    Private Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Show standard help message
    Private Sub ShowStandardHelp()
        ShowHelp(My.Resources.DefaultHelpMsg)
    End Sub

    ' Form load event
    Private Sub JobForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Select Case NCS.JobType
            Case NCS.JobTypeEnum.Backup
                Me.Text = "Backing up Pictures"
            Case NCS.JobTypeEnum.Restore
                Me.Text = "Restoring Pictures"
            Case NCS.JobTypeEnum.ComputerToRemovable
                Me.Text = "Copying Pictures to Removable Drive"
            Case NCS.JobTypeEnum.RemovableToComputer
                Me.Text = "Copying Pictures to your Computer"
        End Select
    End Sub

    Private myTick As Integer = 0

    Private Sub TrafficBox_Click(sender As Object, e As MouseEventArgs) Handles TrafficBox.MouseClick

        Dim x As Integer = e.Location.X
        Dim y As Integer = e.Location.Y
        '        Me.PixieBox.Location = New Point(x, y)
        '       Return

        Dim z As Integer = TrafficBox.Height / 3
        If y < z Then
            myTick = 0
        ElseIf y < (z * 2) Then
            myTick = 1
        Else
            myTick = 2
        End If

DoOver:
        Select Case myTick
            Case 0
                Dim old As Image = Me.TrafficBox.BackgroundImage
                Me.TrafficBox.BackgroundImage = My.Resources.JobResources.TrafficLightRed
                Me.Update()
                Dim msg As String = "Do you really want to cancel the operation?"
                Dim result As MsgBoxResult
                result = SupportModule.ShowYesNoBox(msg)
                If (result = MsgBoxResult.Yes) Then
                    Me.Close()
                    Return
                End If
                TrafficBox.BackgroundImage = old
            Case 1
                Me.TrafficBox.BackgroundImage = My.Resources.JobResources.TrafficLightYellow
                ShowHelp("You paused the operation.")
            Case 2
                Me.TrafficBox.BackgroundImage = My.Resources.JobResources.TrafficLightGreen
                ShowHelp("You resumed the operation.")
            Case Else
                myTick = 0
                GoTo DoOver
        End Select
        myTick += 1
        If (myTick > 2) Then myTick = 0
    End Sub

End Class
