﻿
Imports System.ComponentModel

Public Class TextSearchForm

    ' Collection to serve as a cache for 

    ' Current folder's path (thread safe)
    Public Property CurrentFolderPath As String
        Get
            Dim lock As New Object
            SyncLock lock
                Return Me.CurrentFolderLabel.Text
            End SyncLock
        End Get
        Set(value As String)
            Dim lock As New Object
            SyncLock lock
                Me.CurrentFolderLabel.Text = value
            End SyncLock
        End Set
    End Property

    ' Entry point for thread
    Private Sub MyThread_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs) Handles MyThread.DoWork
        While Not MyThread.CancellationPending
            ' TODO... scan files
            System.Threading.Thread.Sleep(750)
            Me.AddResult("Dave!")
        End While
    End Sub

    ' Clicked on current folder label
    Private Sub CurrentFolderLabel_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles CurrentFolderLabel.LinkClicked
        Dim path As String = CurrentFolderLabel.Text
        Dim dlg As New PickFolderDlg
        dlg.RootPath = "C:\"
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.Admin
        dlg.HelpMessage = "Select a folder to search and click <OK>."
        Dim result As DialogResult
        result = dlg.ShowDialog(Me)
        If result <> DialogResult.OK Then
            Return
        End If
        CurrentFolderLabel.Text = dlg.SelectedPath
        dlg.Dispose()
    End Sub

    ' Size of form changed
    Private Sub TextSearchForm_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        If Me.Height < 360 Then
            Me.ResultsGroupBox.Visible = False
        Else
            Dim h1 As Integer = ResultsGroupBox.Height
            Dim y1 As Integer = ResultsGroupBox.Top
            Dim y2 As Integer = ResultsBox.Top
            Dim border As Integer = y2 - y1
            Me.ResultsBox.Height = h1 - (4 * border)
            Me.ResultsGroupBox.Visible = True
        End If
    End Sub

    ' Form load event handler
    Private Sub TextSearchForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.FileExtTextBox.Text = My.Settings.SearchExtensions
    End Sub

    ' Results cache class
    Friend Class ResultCache
        Private myResults As New Collection
        Public ReadOnly Property Results As Collection
            Get
                Return myResults
            End Get
        End Property
        ' Flush cache to textbox control
        Public Sub Flush(ctrl As TextBox)
            If ctrl Is Nothing Then Return
            Dim line As String
            For Each line In myResults
                ctrl.AppendText(line)
            Next
            myResults.Clear()
        End Sub
        ' Add new result
        Public Sub Add(pathName As String)
            myResults.Add(pathName)
        End Sub
        ' Read-only access to count
        Public ReadOnly Property Count As Integer
            Get
                Return myResults.Count
            End Get
        End Property
    End Class

    ' Internal instance of results cache
    Private myResultsCache As New ResultCache

    ' Add a result to the cache
    Public Sub AddResult(pathName As String)
        Dim lock As New Object
        SyncLock lock
            myResultsCache.Add(pathName + ControlChars.NewLine)
        End SyncLock
    End Sub

    ' Flush results cache
    Private Sub FlushResultsCache()
        Dim lock As New Object
        SyncLock lock
            myResultsCache.Flush(Me.ResultsBox)
        End SyncLock
    End Sub

    ' Timer tick event
    Private Sub MyTimer_Tick(sender As Object, e As EventArgs) Handles MyTimer.Tick
        FlushResultsCache()
    End Sub

    ' Enable/disable input controls
    Private Sub EnableInputControls(enabled As Boolean)
        Me.FileExtGroupBox.Enabled = enabled
        Me.SearchForGroupBox.Enabled = enabled
        Me.FolderGroupBox.Enabled = enabled
    End Sub

    ' Start search
    Private Sub StartSearch()
        Me.WindowState = FormWindowState.Maximized
        ActionButton.Tag = New Object
        ClearResultsButton.Enabled = False
        MyProgressBar.Style = ProgressBarStyle.Marquee
        My.Settings.CaseSensitiveSearch = Me.CaseSenseCheckBox.Checked
        My.Settings.MatchWholeWord = Me.WholeWordCheckBox.Checked
        My.Settings.SubdirectorySearch = SubfoldersCheckBox.Checked
        Me.ActionButton.Text = "Cancel Search"
        EnableInputControls(False)
        MyThread.WorkerSupportsCancellation = True
        MyThread.RunWorkerAsync(Me)
        MyTimer.Enabled = True
    End Sub

    ' Signal to the thread that cancellation has been requested
    Private Sub RequestCancelSearch()
        ActionButton.Enabled = False
        MyThread.CancelAsync()
    End Sub

    ' Finalize the search
    Private Sub FinalizeSearch()
        MyTimer.Enabled = False
        FlushResultsCache()
        ActionButton.Text = "Resume Search"
        ActionButton.Tag = Nothing
        ActionButton.Enabled = True
        With MyProgressBar
            .Style = ProgressBarStyle.Continuous
            .Value = 0
        End With
        EnableInputControls(True)
        Dim path As String
        Dim lines As String() = Me.ResultsBox.Lines()
        If lines.Count < 1 Then Return
        ClearResultsButton.Enabled = True
        Try
            path = IO.Path.GetTempFileName()
            path = IO.Path.ChangeExtension(path, "txt")
            Dim stream As New IO.StreamWriter(path)
            Dim line As String
            For Each line In lines
                stream.WriteLine(line)
            Next
            stream.Close()
            stream.Dispose()
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            Return
        End Try
        ShellOpen("notepad.exe", path)
    End Sub

    ' Action button clicked
    Private Sub ActionButton_Click(sender As Object, e As EventArgs) Handles ActionButton.Click
        If ActionButton.Tag Is Nothing Then
            StartSearch()
        Else
            RequestCancelSearch()
        End If
    End Sub

    ' Worker has completed it's task
    Private Sub MyThread_RunWorkerCompleted(sender As Object, e As RunWorkerCompletedEventArgs) Handles MyThread.RunWorkerCompleted
        FinalizeSearch()
    End Sub

    ' Clear result button clicked
    Private Sub ClearResultsButton_Click(sender As Object, e As EventArgs) Handles ClearResultsButton.Click
        ResultsBox.Clear()
        ClearResultsButton.Enabled = False
    End Sub

    ' Form closed
    Private Sub TextSearchForm_Closed(sender As Object, e As EventArgs) Handles Me.Closed
        My.Settings.SearchExtensions = FileExtTextBox.Text
    End Sub

    ' Validating filename extensions
    Private Sub FileExtTextBox_Validating(sender As Object, e As CancelEventArgs) Handles FileExtTextBox.Validating
        Dim exts As String = Me.FileExtTextBox.Text
        exts = exts.Trim().ToUpper()
        If exts.Length < 1 Then
            ShowInfoBox("You must provide at least one filename extension.")
            e.Cancel = True
        End If
        Try
            Dim coll As New FileExtCollection
            coll.AddMultiple(exts, ";")
            coll.Clear()
            e.Cancel = False
        Catch ex As Exception
            ShowWarnBox(ex.Message)
            e.Cancel = True
        End Try
    End Sub

    ' Clicked on file extensions button
    Private Sub FileExtButton_Click(sender As Object, e As EventArgs) Handles FileExtButton.Click
        Dim dlg As New EditFileExtsDlg
        Try
            dlg.Extensions = Me.FileExtTextBox.Text
            Dim result As DialogResult
            result = dlg.ShowDialog(Me)
            If result = DialogResult.OK Then
                Me.FileExtTextBox.Text = dlg.Extensions
            End If
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        Finally
            dlg.Dispose()
        End Try
    End Sub

End Class

