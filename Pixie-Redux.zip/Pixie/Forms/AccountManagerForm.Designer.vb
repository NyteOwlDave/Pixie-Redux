﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AccountManagerForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim ProtocolLabel As System.Windows.Forms.ToolStripLabel
        Dim SiteLabel As System.Windows.Forms.ToolStripLabel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(AccountManagerForm))
        Me.MainMenu = New System.Windows.Forms.MenuStrip()
        Me.FileMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.SaveMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.CloseMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountNewMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountConfigureMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountRenameMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountStatusMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountActivateMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountDeactivateMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountDeleteMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewAllAccountsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewActiveAccountsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewInactiveAccountsMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpManualMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpAboutMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.UserLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.UserTextBox = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PasswordLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MyToolStrip = New System.Windows.Forms.ToolStrip()
        Me.FileSaveChangesButton = New System.Windows.Forms.ToolStripButton()
        Me.FileCloseButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountNewButton = New System.Windows.Forms.ToolStripButton()
        Me.AccountConfigureButton = New System.Windows.Forms.ToolStripButton()
        Me.AccountRenameButton = New System.Windows.Forms.ToolStripButton()
        Me.AccountDeleteButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.AccountToggleStatusButton = New System.Windows.Forms.ToolStripButton()
        Me.ViewRotateButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpManualButton = New System.Windows.Forms.ToolStripButton()
        Me.HelpAboutButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator()
        Me.HelpToolStrip = New System.Windows.Forms.ToolStrip()
        Me.HelpMessageLabel = New System.Windows.Forms.ToolStripLabel()
        Me.AccountsPanel = New System.Windows.Forms.Panel()
        Me.AccountsListView = New System.Windows.Forms.ListView()
        Me.ToolStrip2 = New System.Windows.Forms.ToolStrip()
        Me.ProtocolTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.SiteTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.SiteOKButton = New System.Windows.Forms.ToolStripButton()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.UndoChangesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChooseGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator()
        Me.FileChooseGroupButton = New System.Windows.Forms.ToolStripButton()
        Me.FileUndoChangesButton = New System.Windows.Forms.ToolStripButton()
        ProtocolLabel = New System.Windows.Forms.ToolStripLabel()
        SiteLabel = New System.Windows.Forms.ToolStripLabel()
        Me.MainMenu.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MyToolStrip.SuspendLayout()
        Me.HelpToolStrip.SuspendLayout()
        Me.AccountsPanel.SuspendLayout()
        Me.ToolStrip2.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ProtocolLabel
        '
        ProtocolLabel.Name = "ProtocolLabel"
        ProtocolLabel.Size = New System.Drawing.Size(65, 24)
        ProtocolLabel.Text = "Protocol"
        '
        'SiteLabel
        '
        SiteLabel.Name = "SiteLabel"
        SiteLabel.Size = New System.Drawing.Size(34, 24)
        SiteLabel.Text = "Site"
        '
        'MainMenu
        '
        Me.MainMenu.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MainMenu.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileMenu, Me.AccountMenu, Me.ViewMenu, Me.HelpMenu})
        Me.MainMenu.Location = New System.Drawing.Point(0, 0)
        Me.MainMenu.Name = "MainMenu"
        Me.MainMenu.Size = New System.Drawing.Size(622, 28)
        Me.MainMenu.TabIndex = 1
        Me.MainMenu.Text = "Main Menu"
        '
        'FileMenu
        '
        Me.FileMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChooseGroupToolStripMenuItem, Me.SaveMenuItem, Me.ToolStripSeparator10, Me.UndoChangesToolStripMenuItem, Me.ToolStripSeparator1, Me.CloseMenuItem})
        Me.FileMenu.Name = "FileMenu"
        Me.FileMenu.Size = New System.Drawing.Size(44, 24)
        Me.FileMenu.Text = "&File"
        '
        'SaveMenuItem
        '
        Me.SaveMenuItem.Name = "SaveMenuItem"
        Me.SaveMenuItem.Size = New System.Drawing.Size(187, 26)
        Me.SaveMenuItem.Text = "&Save Changes"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(184, 6)
        '
        'CloseMenuItem
        '
        Me.CloseMenuItem.Name = "CloseMenuItem"
        Me.CloseMenuItem.Size = New System.Drawing.Size(187, 26)
        Me.CloseMenuItem.Text = " Window"
        '
        'AccountMenu
        '
        Me.AccountMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountNewMenuItem, Me.ToolStripSeparator3, Me.AccountConfigureMenuItem, Me.ToolStripSeparator7, Me.AccountRenameMenuItem, Me.ToolStripSeparator2, Me.AccountStatusMenu, Me.ToolStripSeparator8, Me.AccountDeleteMenuItem})
        Me.AccountMenu.Name = "AccountMenu"
        Me.AccountMenu.Size = New System.Drawing.Size(75, 24)
        Me.AccountMenu.Text = "&Account"
        '
        'AccountNewMenuItem
        '
        Me.AccountNewMenuItem.Name = "AccountNewMenuItem"
        Me.AccountNewMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.AccountNewMenuItem.Text = "&New..."
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(178, 6)
        '
        'AccountConfigureMenuItem
        '
        Me.AccountConfigureMenuItem.Name = "AccountConfigureMenuItem"
        Me.AccountConfigureMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.AccountConfigureMenuItem.Text = "&Configure..."
        '
        'ToolStripSeparator7
        '
        Me.ToolStripSeparator7.Name = "ToolStripSeparator7"
        Me.ToolStripSeparator7.Size = New System.Drawing.Size(178, 6)
        '
        'AccountRenameMenuItem
        '
        Me.AccountRenameMenuItem.Name = "AccountRenameMenuItem"
        Me.AccountRenameMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.AccountRenameMenuItem.Text = "&Rename"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(178, 6)
        '
        'AccountStatusMenu
        '
        Me.AccountStatusMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AccountActivateMenuItem, Me.AccountDeactivateMenuItem})
        Me.AccountStatusMenu.Name = "AccountStatusMenu"
        Me.AccountStatusMenu.Size = New System.Drawing.Size(181, 26)
        Me.AccountStatusMenu.Text = "&Status"
        '
        'AccountActivateMenuItem
        '
        Me.AccountActivateMenuItem.Name = "AccountActivateMenuItem"
        Me.AccountActivateMenuItem.Size = New System.Drawing.Size(155, 26)
        Me.AccountActivateMenuItem.Text = "&Activate"
        '
        'AccountDeactivateMenuItem
        '
        Me.AccountDeactivateMenuItem.Name = "AccountDeactivateMenuItem"
        Me.AccountDeactivateMenuItem.Size = New System.Drawing.Size(155, 26)
        Me.AccountDeactivateMenuItem.Text = "&Deactivate"
        '
        'ToolStripSeparator8
        '
        Me.ToolStripSeparator8.Name = "ToolStripSeparator8"
        Me.ToolStripSeparator8.Size = New System.Drawing.Size(178, 6)
        '
        'AccountDeleteMenuItem
        '
        Me.AccountDeleteMenuItem.Name = "AccountDeleteMenuItem"
        Me.AccountDeleteMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.AccountDeleteMenuItem.Text = "Delete"
        '
        'ViewMenu
        '
        Me.ViewMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ViewAllAccountsMenuItem, Me.ViewActiveAccountsMenuItem, Me.ViewInactiveAccountsMenuItem})
        Me.ViewMenu.Name = "ViewMenu"
        Me.ViewMenu.Size = New System.Drawing.Size(53, 24)
        Me.ViewMenu.Text = "&View"
        '
        'ViewAllAccountsMenuItem
        '
        Me.ViewAllAccountsMenuItem.Name = "ViewAllAccountsMenuItem"
        Me.ViewAllAccountsMenuItem.Size = New System.Drawing.Size(199, 26)
        Me.ViewAllAccountsMenuItem.Text = "A&ll Accounts"
        '
        'ViewActiveAccountsMenuItem
        '
        Me.ViewActiveAccountsMenuItem.Name = "ViewActiveAccountsMenuItem"
        Me.ViewActiveAccountsMenuItem.Size = New System.Drawing.Size(199, 26)
        Me.ViewActiveAccountsMenuItem.Text = "&Active Accounts"
        '
        'ViewInactiveAccountsMenuItem
        '
        Me.ViewInactiveAccountsMenuItem.Name = "ViewInactiveAccountsMenuItem"
        Me.ViewInactiveAccountsMenuItem.Size = New System.Drawing.Size(199, 26)
        Me.ViewInactiveAccountsMenuItem.Text = "&Inactive Accounts"
        '
        'HelpMenu
        '
        Me.HelpMenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpManualMenuItem, Me.HelpAboutMenuItem})
        Me.HelpMenu.Name = "HelpMenu"
        Me.HelpMenu.Size = New System.Drawing.Size(53, 24)
        Me.HelpMenu.Text = "&Help"
        '
        'HelpManualMenuItem
        '
        Me.HelpManualMenuItem.Name = "HelpManualMenuItem"
        Me.HelpManualMenuItem.Size = New System.Drawing.Size(134, 26)
        Me.HelpManualMenuItem.Text = "&Manual"
        '
        'HelpAboutMenuItem
        '
        Me.HelpAboutMenuItem.Name = "HelpAboutMenuItem"
        Me.HelpAboutMenuItem.Size = New System.Drawing.Size(134, 26)
        Me.HelpAboutMenuItem.Text = "&About..."
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.UserLabel, Me.UserTextBox, Me.PasswordLabel, Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 404)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(622, 29)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'UserLabel
        '
        Me.UserLabel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UserLabel.Name = "UserLabel"
        Me.UserLabel.Size = New System.Drawing.Size(41, 24)
        Me.UserLabel.Text = "User"
        '
        'UserTextBox
        '
        Me.UserTextBox.BackColor = System.Drawing.Color.Snow
        Me.UserTextBox.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.UserTextBox.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.UserTextBox.Name = "UserTextBox"
        Me.UserTextBox.Size = New System.Drawing.Size(34, 24)
        Me.UserTextBox.Text = "me"
        '
        'PasswordLabel
        '
        Me.PasswordLabel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PasswordLabel.Name = "PasswordLabel"
        Me.PasswordLabel.Size = New System.Drawing.Size(76, 24)
        Me.PasswordLabel.Text = "Password"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel1.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel1.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(72, 24)
        Me.ToolStripStatusLabel1.Text = "excellent"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(35, 24)
        Me.ToolStripStatusLabel2.Text = "PIN"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.BackColor = System.Drawing.Color.Snow
        Me.ToolStripStatusLabel3.BorderSides = CType((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) _
            Or System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom), System.Windows.Forms.ToolStripStatusLabelBorderSides)
        Me.ToolStripStatusLabel3.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(45, 24)
        Me.ToolStripStatusLabel3.Text = "0000"
        '
        'MyToolStrip
        '
        Me.MyToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.MyToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.MyToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileChooseGroupButton, Me.FileSaveChangesButton, Me.FileUndoChangesButton, Me.FileCloseButton, Me.ToolStripSeparator4, Me.AccountNewButton, Me.AccountConfigureButton, Me.AccountRenameButton, Me.AccountDeleteButton, Me.ToolStripSeparator5, Me.AccountToggleStatusButton, Me.ViewRotateButton, Me.ToolStripSeparator9, Me.HelpManualButton, Me.HelpAboutButton, Me.ToolStripSeparator6})
        Me.MyToolStrip.Location = New System.Drawing.Point(0, 0)
        Me.MyToolStrip.Name = "MyToolStrip"
        Me.MyToolStrip.Size = New System.Drawing.Size(363, 27)
        Me.MyToolStrip.TabIndex = 3
        Me.MyToolStrip.Text = "ToolStrip1"
        '
        'FileSaveChangesButton
        '
        Me.FileSaveChangesButton.AutoToolTip = False
        Me.FileSaveChangesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FileSaveChangesButton.Image = CType(resources.GetObject("FileSaveChangesButton.Image"), System.Drawing.Image)
        Me.FileSaveChangesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileSaveChangesButton.Name = "FileSaveChangesButton"
        Me.FileSaveChangesButton.Size = New System.Drawing.Size(24, 24)
        '
        'FileCloseButton
        '
        Me.FileCloseButton.AutoToolTip = False
        Me.FileCloseButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FileCloseButton.Image = CType(resources.GetObject("FileCloseButton.Image"), System.Drawing.Image)
        Me.FileCloseButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileCloseButton.Name = "FileCloseButton"
        Me.FileCloseButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 27)
        '
        'AccountNewButton
        '
        Me.AccountNewButton.AutoToolTip = False
        Me.AccountNewButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AccountNewButton.Image = CType(resources.GetObject("AccountNewButton.Image"), System.Drawing.Image)
        Me.AccountNewButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AccountNewButton.Name = "AccountNewButton"
        Me.AccountNewButton.Size = New System.Drawing.Size(24, 24)
        '
        'AccountConfigureButton
        '
        Me.AccountConfigureButton.AutoToolTip = False
        Me.AccountConfigureButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AccountConfigureButton.Image = CType(resources.GetObject("AccountConfigureButton.Image"), System.Drawing.Image)
        Me.AccountConfigureButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AccountConfigureButton.Name = "AccountConfigureButton"
        Me.AccountConfigureButton.Size = New System.Drawing.Size(24, 24)
        '
        'AccountRenameButton
        '
        Me.AccountRenameButton.AutoToolTip = False
        Me.AccountRenameButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AccountRenameButton.Image = CType(resources.GetObject("AccountRenameButton.Image"), System.Drawing.Image)
        Me.AccountRenameButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AccountRenameButton.Name = "AccountRenameButton"
        Me.AccountRenameButton.Size = New System.Drawing.Size(24, 24)
        '
        'AccountDeleteButton
        '
        Me.AccountDeleteButton.AutoToolTip = False
        Me.AccountDeleteButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AccountDeleteButton.Image = CType(resources.GetObject("AccountDeleteButton.Image"), System.Drawing.Image)
        Me.AccountDeleteButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AccountDeleteButton.Name = "AccountDeleteButton"
        Me.AccountDeleteButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 27)
        '
        'AccountToggleStatusButton
        '
        Me.AccountToggleStatusButton.AutoToolTip = False
        Me.AccountToggleStatusButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.AccountToggleStatusButton.Image = CType(resources.GetObject("AccountToggleStatusButton.Image"), System.Drawing.Image)
        Me.AccountToggleStatusButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AccountToggleStatusButton.Name = "AccountToggleStatusButton"
        Me.AccountToggleStatusButton.Size = New System.Drawing.Size(24, 24)
        '
        'ViewRotateButton
        '
        Me.ViewRotateButton.AutoToolTip = False
        Me.ViewRotateButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ViewRotateButton.Image = CType(resources.GetObject("ViewRotateButton.Image"), System.Drawing.Image)
        Me.ViewRotateButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ViewRotateButton.Name = "ViewRotateButton"
        Me.ViewRotateButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator9
        '
        Me.ToolStripSeparator9.Name = "ToolStripSeparator9"
        Me.ToolStripSeparator9.Size = New System.Drawing.Size(6, 27)
        '
        'HelpManualButton
        '
        Me.HelpManualButton.AutoToolTip = False
        Me.HelpManualButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpManualButton.Image = CType(resources.GetObject("HelpManualButton.Image"), System.Drawing.Image)
        Me.HelpManualButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpManualButton.Name = "HelpManualButton"
        Me.HelpManualButton.Size = New System.Drawing.Size(24, 24)
        '
        'HelpAboutButton
        '
        Me.HelpAboutButton.AutoToolTip = False
        Me.HelpAboutButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HelpAboutButton.Image = CType(resources.GetObject("HelpAboutButton.Image"), System.Drawing.Image)
        Me.HelpAboutButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HelpAboutButton.Name = "HelpAboutButton"
        Me.HelpAboutButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator6
        '
        Me.ToolStripSeparator6.Name = "ToolStripSeparator6"
        Me.ToolStripSeparator6.Size = New System.Drawing.Size(6, 27)
        '
        'HelpToolStrip
        '
        Me.HelpToolStrip.Dock = System.Windows.Forms.DockStyle.None
        Me.HelpToolStrip.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.HelpToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpMessageLabel})
        Me.HelpToolStrip.Location = New System.Drawing.Point(363, 0)
        Me.HelpToolStrip.Name = "HelpToolStrip"
        Me.HelpToolStrip.Size = New System.Drawing.Size(91, 25)
        Me.HelpToolStrip.TabIndex = 5
        Me.HelpToolStrip.Text = "ToolStrip1"
        '
        'HelpMessageLabel
        '
        Me.HelpMessageLabel.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpMessageLabel.Name = "HelpMessageLabel"
        Me.HelpMessageLabel.Size = New System.Drawing.Size(79, 22)
        Me.HelpMessageLabel.Text = "Welcome!"
        '
        'AccountsPanel
        '
        Me.AccountsPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.AccountsPanel.Controls.Add(Me.AccountsListView)
        Me.AccountsPanel.Location = New System.Drawing.Point(0, 95)
        Me.AccountsPanel.Name = "AccountsPanel"
        Me.AccountsPanel.Size = New System.Drawing.Size(622, 306)
        Me.AccountsPanel.TabIndex = 6
        '
        'AccountsListView
        '
        Me.AccountsListView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.AccountsListView.CausesValidation = False
        Me.AccountsListView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AccountsListView.Location = New System.Drawing.Point(0, 0)
        Me.AccountsListView.MultiSelect = False
        Me.AccountsListView.Name = "AccountsListView"
        Me.AccountsListView.ShowGroups = False
        Me.AccountsListView.Size = New System.Drawing.Size(622, 306)
        Me.AccountsListView.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.AccountsListView.TabIndex = 0
        Me.AccountsListView.UseCompatibleStateImageBehavior = False
        '
        'ToolStrip2
        '
        Me.ToolStrip2.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip2.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {ProtocolLabel, Me.ProtocolTextBox, SiteLabel, Me.SiteTextBox, Me.SiteOKButton})
        Me.ToolStrip2.Location = New System.Drawing.Point(0, 27)
        Me.ToolStrip2.Name = "ToolStrip2"
        Me.ToolStrip2.Size = New System.Drawing.Size(508, 27)
        Me.ToolStrip2.TabIndex = 7
        Me.ToolStrip2.Text = "ToolStrip2"
        '
        'ProtocolTextBox
        '
        Me.ProtocolTextBox.AutoCompleteCustomSource.AddRange(New String() {"http", "https", "ftp"})
        Me.ProtocolTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.ProtocolTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.ProtocolTextBox.Name = "ProtocolTextBox"
        Me.ProtocolTextBox.Size = New System.Drawing.Size(60, 27)
        '
        'SiteTextBox
        '
        Me.SiteTextBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.SiteTextBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.RecentlyUsedList
        Me.SiteTextBox.Name = "SiteTextBox"
        Me.SiteTextBox.Size = New System.Drawing.Size(300, 27)
        '
        'SiteOKButton
        '
        Me.SiteOKButton.AutoToolTip = False
        Me.SiteOKButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SiteOKButton.Image = CType(resources.GetObject("SiteOKButton.Image"), System.Drawing.Image)
        Me.SiteOKButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SiteOKButton.Name = "SiteOKButton"
        Me.SiteOKButton.Size = New System.Drawing.Size(33, 24)
        Me.SiteOKButton.Text = "OK"
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.MyToolStrip)
        Me.FlowLayoutPanel1.Controls.Add(Me.HelpToolStrip)
        Me.FlowLayoutPanel1.Controls.Add(Me.ToolStrip2)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 28)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(622, 61)
        Me.FlowLayoutPanel1.TabIndex = 8
        '
        'UndoChangesToolStripMenuItem
        '
        Me.UndoChangesToolStripMenuItem.Name = "UndoChangesToolStripMenuItem"
        Me.UndoChangesToolStripMenuItem.Size = New System.Drawing.Size(187, 26)
        Me.UndoChangesToolStripMenuItem.Text = "&Undo Changes"
        '
        'ChooseGroupToolStripMenuItem
        '
        Me.ChooseGroupToolStripMenuItem.Name = "ChooseGroupToolStripMenuItem"
        Me.ChooseGroupToolStripMenuItem.Size = New System.Drawing.Size(187, 26)
        Me.ChooseGroupToolStripMenuItem.Text = "Choose &Group..."
        '
        'ToolStripSeparator10
        '
        Me.ToolStripSeparator10.Name = "ToolStripSeparator10"
        Me.ToolStripSeparator10.Size = New System.Drawing.Size(184, 6)
        '
        'FileChooseGroupButton
        '
        Me.FileChooseGroupButton.AutoToolTip = False
        Me.FileChooseGroupButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FileChooseGroupButton.Image = CType(resources.GetObject("FileChooseGroupButton.Image"), System.Drawing.Image)
        Me.FileChooseGroupButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileChooseGroupButton.Name = "FileChooseGroupButton"
        Me.FileChooseGroupButton.Size = New System.Drawing.Size(24, 24)
        Me.FileChooseGroupButton.Text = "ToolStripButton1"
        '
        'FileUndoChangesButton
        '
        Me.FileUndoChangesButton.AutoToolTip = False
        Me.FileUndoChangesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FileUndoChangesButton.Image = CType(resources.GetObject("FileUndoChangesButton.Image"), System.Drawing.Image)
        Me.FileUndoChangesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FileUndoChangesButton.Name = "FileUndoChangesButton"
        Me.FileUndoChangesButton.Size = New System.Drawing.Size(24, 24)
        Me.FileUndoChangesButton.Text = "ToolStripButton2"
        '
        'AccountManagerForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(120.0!, 120.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi
        Me.CausesValidation = False
        Me.ClientSize = New System.Drawing.Size(622, 433)
        Me.Controls.Add(Me.FlowLayoutPanel1)
        Me.Controls.Add(Me.AccountsPanel)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MainMenu)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MainMenu
        Me.MinimumSize = New System.Drawing.Size(640, 480)
        Me.Name = "AccountManagerForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "My Accounts"
        Me.MainMenu.ResumeLayout(False)
        Me.MainMenu.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MyToolStrip.ResumeLayout(False)
        Me.MyToolStrip.PerformLayout()
        Me.HelpToolStrip.ResumeLayout(False)
        Me.HelpToolStrip.PerformLayout()
        Me.AccountsPanel.ResumeLayout(False)
        Me.ToolStrip2.ResumeLayout(False)
        Me.ToolStrip2.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.FlowLayoutPanel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MainMenu As MenuStrip
    Friend WithEvents FileMenu As ToolStripMenuItem
    Friend WithEvents SaveMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents CloseMenuItem As ToolStripMenuItem
    Friend WithEvents AccountMenu As ToolStripMenuItem
    Friend WithEvents AccountNewMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents AccountConfigureMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator7 As ToolStripSeparator
    Friend WithEvents AccountRenameMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents AccountDeleteMenuItem As ToolStripMenuItem
    Friend WithEvents HelpMenu As ToolStripMenuItem
    Friend WithEvents HelpManualMenuItem As ToolStripMenuItem
    Friend WithEvents HelpAboutMenuItem As ToolStripMenuItem
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents UserLabel As ToolStripStatusLabel
    Friend WithEvents UserTextBox As ToolStripStatusLabel
    Friend WithEvents MyToolStrip As ToolStrip
    Friend WithEvents FileSaveChangesButton As ToolStripButton
    Friend WithEvents FileCloseButton As ToolStripButton
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
    Friend WithEvents AccountNewButton As ToolStripButton
    Friend WithEvents AccountConfigureButton As ToolStripButton
    Friend WithEvents AccountDeleteButton As ToolStripButton
    Friend WithEvents ToolStripSeparator5 As ToolStripSeparator
    Friend WithEvents HelpManualButton As ToolStripButton
    Friend WithEvents HelpAboutButton As ToolStripButton
    Friend WithEvents AccountStatusMenu As ToolStripMenuItem
    Friend WithEvents AccountActivateMenuItem As ToolStripMenuItem
    Friend WithEvents AccountDeactivateMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator8 As ToolStripSeparator
    Friend WithEvents ViewMenu As ToolStripMenuItem
    Friend WithEvents ViewAllAccountsMenuItem As ToolStripMenuItem
    Friend WithEvents ViewActiveAccountsMenuItem As ToolStripMenuItem
    Friend WithEvents ViewInactiveAccountsMenuItem As ToolStripMenuItem
    Friend WithEvents AccountToggleStatusButton As ToolStripButton
    Friend WithEvents ViewRotateButton As ToolStripButton
    Friend WithEvents ToolStripSeparator9 As ToolStripSeparator
    Friend WithEvents HelpToolStrip As ToolStrip
    Friend WithEvents HelpMessageLabel As ToolStripLabel
    Friend WithEvents AccountsPanel As Panel
    Friend WithEvents AccountRenameButton As ToolStripButton
    Friend WithEvents ToolStripSeparator6 As ToolStripSeparator
    Friend WithEvents AccountsListView As ListView
    Friend WithEvents ToolStrip2 As ToolStrip
    Friend WithEvents ProtocolTextBox As ToolStripTextBox
    Friend WithEvents SiteTextBox As ToolStripTextBox
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents PasswordLabel As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents SiteOKButton As ToolStripButton
    Friend WithEvents ChooseGroupToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ToolStripSeparator10 As ToolStripSeparator
    Friend WithEvents UndoChangesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents FileChooseGroupButton As ToolStripButton
    Friend WithEvents FileUndoChangesButton As ToolStripButton
End Class
