﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PixieForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ActionGroup As System.Windows.Forms.GroupBox
        Dim DriveGroup As System.Windows.Forms.GroupBox
        Dim ComputerGroup As System.Windows.Forms.GroupBox
        Dim HelpGroup As System.Windows.Forms.GroupBox
        Dim Label1 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PixieForm))
        Me.ComputerToDriveBox = New System.Windows.Forms.PictureBox()
        Me.DriveToComputerBox = New System.Windows.Forms.PictureBox()
        Me.DriveTypeBox = New System.Windows.Forms.PictureBox()
        Me.ComputerTypeBox = New System.Windows.Forms.PictureBox()
        Me.ToolsBox = New System.Windows.Forms.PictureBox()
        Me.SettingsBox = New System.Windows.Forms.PictureBox()
        Me.PixieHelpBox = New System.Windows.Forms.PictureBox()
        Me.MyPicturesBox = New System.Windows.Forms.PictureBox()
        Me.HelpPanel = New System.Windows.Forms.Panel()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.ToolTips = New System.Windows.Forms.ToolTip(Me.components)
        ActionGroup = New System.Windows.Forms.GroupBox()
        DriveGroup = New System.Windows.Forms.GroupBox()
        ComputerGroup = New System.Windows.Forms.GroupBox()
        HelpGroup = New System.Windows.Forms.GroupBox()
        Label1 = New System.Windows.Forms.Label()
        ActionGroup.SuspendLayout()
        CType(Me.ComputerToDriveBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DriveToComputerBox, System.ComponentModel.ISupportInitialize).BeginInit()
        DriveGroup.SuspendLayout()
        CType(Me.DriveTypeBox, System.ComponentModel.ISupportInitialize).BeginInit()
        ComputerGroup.SuspendLayout()
        CType(Me.ComputerTypeBox, System.ComponentModel.ISupportInitialize).BeginInit()
        HelpGroup.SuspendLayout()
        CType(Me.ToolsBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SettingsBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MyPicturesBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.HelpPanel.SuspendLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ActionGroup
        '
        ActionGroup.Controls.Add(Me.ComputerToDriveBox)
        ActionGroup.Controls.Add(Me.DriveToComputerBox)
        ActionGroup.Location = New System.Drawing.Point(9, 2)
        ActionGroup.Name = "ActionGroup"
        ActionGroup.Size = New System.Drawing.Size(269, 200)
        ActionGroup.TabIndex = 0
        ActionGroup.TabStop = False
        ActionGroup.Text = "Action"
        '
        'ComputerToDriveBox
        '
        Me.ComputerToDriveBox.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ComputerToDriveBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ComputerToDriveBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ComputerToDriveBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComputerToDriveBox.Location = New System.Drawing.Point(6, 110)
        Me.ComputerToDriveBox.Name = "ComputerToDriveBox"
        Me.ComputerToDriveBox.Size = New System.Drawing.Size(254, 83)
        Me.ComputerToDriveBox.TabIndex = 1
        Me.ComputerToDriveBox.TabStop = False
        '
        'DriveToComputerBox
        '
        Me.DriveToComputerBox.BackColor = System.Drawing.Color.PaleTurquoise
        Me.DriveToComputerBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DriveToComputerBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DriveToComputerBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DriveToComputerBox.Location = New System.Drawing.Point(6, 21)
        Me.DriveToComputerBox.Name = "DriveToComputerBox"
        Me.DriveToComputerBox.Size = New System.Drawing.Size(254, 83)
        Me.DriveToComputerBox.TabIndex = 0
        Me.DriveToComputerBox.TabStop = False
        '
        'DriveGroup
        '
        DriveGroup.Controls.Add(Me.DriveTypeBox)
        DriveGroup.Location = New System.Drawing.Point(9, 208)
        DriveGroup.Name = "DriveGroup"
        DriveGroup.Size = New System.Drawing.Size(125, 137)
        DriveGroup.TabIndex = 1
        DriveGroup.TabStop = False
        DriveGroup.Text = "Drive Type"
        '
        'DriveTypeBox
        '
        Me.DriveTypeBox.BackColor = System.Drawing.Color.PaleTurquoise
        Me.DriveTypeBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.DriveTypeBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.DriveTypeBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.DriveTypeBox.Location = New System.Drawing.Point(6, 21)
        Me.DriveTypeBox.Name = "DriveTypeBox"
        Me.DriveTypeBox.Size = New System.Drawing.Size(113, 110)
        Me.DriveTypeBox.TabIndex = 3
        Me.DriveTypeBox.TabStop = False
        '
        'ComputerGroup
        '
        ComputerGroup.Controls.Add(Me.ComputerTypeBox)
        ComputerGroup.Location = New System.Drawing.Point(153, 208)
        ComputerGroup.Name = "ComputerGroup"
        ComputerGroup.Size = New System.Drawing.Size(125, 137)
        ComputerGroup.TabIndex = 2
        ComputerGroup.TabStop = False
        ComputerGroup.Text = "Computer Type"
        '
        'ComputerTypeBox
        '
        Me.ComputerTypeBox.BackColor = System.Drawing.Color.PaleTurquoise
        Me.ComputerTypeBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ComputerTypeBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ComputerTypeBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ComputerTypeBox.Location = New System.Drawing.Point(6, 21)
        Me.ComputerTypeBox.Name = "ComputerTypeBox"
        Me.ComputerTypeBox.Size = New System.Drawing.Size(113, 110)
        Me.ComputerTypeBox.TabIndex = 4
        Me.ComputerTypeBox.TabStop = False
        '
        'HelpGroup
        '
        HelpGroup.Controls.Add(Me.ToolsBox)
        HelpGroup.Controls.Add(Me.SettingsBox)
        HelpGroup.Controls.Add(Me.PixieHelpBox)
        HelpGroup.Controls.Add(Me.MyPicturesBox)
        HelpGroup.Controls.Add(Me.HelpPanel)
        HelpGroup.Controls.Add(Label1)
        HelpGroup.Controls.Add(Me.PixieBox)
        HelpGroup.Location = New System.Drawing.Point(288, 2)
        HelpGroup.Name = "HelpGroup"
        HelpGroup.Size = New System.Drawing.Size(340, 343)
        HelpGroup.TabIndex = 3
        HelpGroup.TabStop = False
        HelpGroup.Text = "Help"
        '
        'ToolsBox
        '
        Me.ToolsBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.RedToolBox
        Me.ToolsBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ToolsBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ToolsBox.Location = New System.Drawing.Point(93, 21)
        Me.ToolsBox.Name = "ToolsBox"
        Me.ToolsBox.Size = New System.Drawing.Size(55, 54)
        Me.ToolsBox.TabIndex = 6
        Me.ToolsBox.TabStop = False
        '
        'SettingsBox
        '
        Me.SettingsBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.Gear
        Me.SettingsBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SettingsBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.SettingsBox.Location = New System.Drawing.Point(154, 21)
        Me.SettingsBox.Name = "SettingsBox"
        Me.SettingsBox.Size = New System.Drawing.Size(55, 54)
        Me.SettingsBox.TabIndex = 5
        Me.SettingsBox.TabStop = False
        '
        'PixieHelpBox
        '
        Me.PixieHelpBox.BackgroundImage = Global.Pixie.My.Resources.AlertResources.HelpIcon
        Me.PixieHelpBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieHelpBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieHelpBox.Location = New System.Drawing.Point(215, 21)
        Me.PixieHelpBox.Name = "PixieHelpBox"
        Me.PixieHelpBox.Size = New System.Drawing.Size(55, 54)
        Me.PixieHelpBox.TabIndex = 4
        Me.PixieHelpBox.TabStop = False
        '
        'MyPicturesBox
        '
        Me.MyPicturesBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.MyPictures
        Me.MyPicturesBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.MyPicturesBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MyPicturesBox.Location = New System.Drawing.Point(276, 21)
        Me.MyPicturesBox.Name = "MyPicturesBox"
        Me.MyPicturesBox.Size = New System.Drawing.Size(55, 54)
        Me.MyPicturesBox.TabIndex = 3
        Me.MyPicturesBox.TabStop = False
        '
        'HelpPanel
        '
        Me.HelpPanel.BackColor = System.Drawing.Color.Transparent
        Me.HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.HelpPanel.Controls.Add(Me.HelpBox)
        Me.HelpPanel.Location = New System.Drawing.Point(7, 111)
        Me.HelpPanel.Name = "HelpPanel"
        Me.HelpPanel.Size = New System.Drawing.Size(324, 225)
        Me.HelpPanel.TabIndex = 2
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(320, 221)
        Me.HelpBox.TabIndex = 0
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Label1.Location = New System.Drawing.Point(95, 83)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(164, 24)
        Label1.TabIndex = 1
        Label1.Text = "Your Pixie Says..."
        Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(6, 21)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 0
        Me.PixieBox.TabStop = False
        '
        'ToolTips
        '
        Me.ToolTips.ToolTipTitle = "My Tool Tips"
        '
        'PixieForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Cornsilk
        Me.ClientSize = New System.Drawing.Size(637, 353)
        Me.Controls.Add(HelpGroup)
        Me.Controls.Add(ComputerGroup)
        Me.Controls.Add(DriveGroup)
        Me.Controls.Add(ActionGroup)
        Me.Cursor = System.Windows.Forms.Cursors.Help
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "PixieForm"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.Text = "Pixie - Redux"
        ActionGroup.ResumeLayout(False)
        CType(Me.ComputerToDriveBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DriveToComputerBox, System.ComponentModel.ISupportInitialize).EndInit()
        DriveGroup.ResumeLayout(False)
        CType(Me.DriveTypeBox, System.ComponentModel.ISupportInitialize).EndInit()
        ComputerGroup.ResumeLayout(False)
        CType(Me.ComputerTypeBox, System.ComponentModel.ISupportInitialize).EndInit()
        HelpGroup.ResumeLayout(False)
        HelpGroup.PerformLayout()
        CType(Me.ToolsBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SettingsBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MyPicturesBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.HelpPanel.ResumeLayout(False)
        Me.HelpPanel.PerformLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DriveToComputerBox As PictureBox
    Friend WithEvents ComputerToDriveBox As PictureBox
    Friend WithEvents DriveTypeBox As PictureBox
    Friend WithEvents ComputerTypeBox As PictureBox
    Public WithEvents HelpPanel As Panel
    Friend WithEvents MyPicturesBox As PictureBox
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents ToolTips As ToolTip
    Friend WithEvents ToolsBox As PictureBox
    Friend WithEvents SettingsBox As PictureBox
    Friend WithEvents PixieHelpBox As PictureBox
End Class
