﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class BrowserForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim LeftPanel As System.Windows.Forms.Panel
        Dim BrowserPanel As System.Windows.Forms.Panel
        Dim OmniBarPanel As System.Windows.Forms.Panel
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BrowserForm))
        Dim HelpPanel As System.Windows.Forms.Panel
        Me.PixieHelpBox = New System.Windows.Forms.PictureBox()
        Me.ShowDrivesBox = New System.Windows.Forms.PictureBox()
        Me.LaunchBox = New System.Windows.Forms.PictureBox()
        Me.PickFolderBox = New System.Windows.Forms.PictureBox()
        Me.ExploreBox = New System.Windows.Forms.PictureBox()
        Me.MyWebBrowser = New System.Windows.Forms.WebBrowser()
        Me.OmniBar = New System.Windows.Forms.TextBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.HomeButton = New System.Windows.Forms.ToolStripButton()
        Me.RootButton = New System.Windows.Forms.ToolStripButton()
        Me.UpButton = New System.Windows.Forms.ToolStripButton()
        Me.BackButton = New System.Windows.Forms.ToolStripButton()
        Me.ForwardButton = New System.Windows.Forms.ToolStripButton()
        Me.RefreshButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.FavoritesButton = New System.Windows.Forms.ToolStripButton()
        Me.HistoryButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolsButton = New System.Windows.Forms.ToolStripButton()
        Me.SetupButton = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.WelcomeButton = New System.Windows.Forms.ToolStripButton()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        LeftPanel = New System.Windows.Forms.Panel()
        BrowserPanel = New System.Windows.Forms.Panel()
        OmniBarPanel = New System.Windows.Forms.Panel()
        HelpPanel = New System.Windows.Forms.Panel()
        LeftPanel.SuspendLayout()
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShowDrivesBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LaunchBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PickFolderBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ExploreBox, System.ComponentModel.ISupportInitialize).BeginInit()
        BrowserPanel.SuspendLayout()
        OmniBarPanel.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        HelpPanel.SuspendLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'LeftPanel
        '
        LeftPanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        LeftPanel.Controls.Add(Me.PixieHelpBox)
        LeftPanel.Controls.Add(Me.ShowDrivesBox)
        LeftPanel.Controls.Add(Me.LaunchBox)
        LeftPanel.Controls.Add(Me.PickFolderBox)
        LeftPanel.Controls.Add(Me.ExploreBox)
        LeftPanel.Location = New System.Drawing.Point(9, 166)
        LeftPanel.MaximumSize = New System.Drawing.Size(75, 0)
        LeftPanel.MinimumSize = New System.Drawing.Size(75, 376)
        LeftPanel.Name = "LeftPanel"
        LeftPanel.Size = New System.Drawing.Size(75, 376)
        LeftPanel.TabIndex = 3
        '
        'PixieHelpBox
        '
        Me.PixieHelpBox.BackColor = System.Drawing.Color.AliceBlue
        Me.PixieHelpBox.BackgroundImage = Global.Pixie.My.Resources.BrowserResources.Help
        Me.PixieHelpBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieHelpBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PixieHelpBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieHelpBox.Location = New System.Drawing.Point(3, 305)
        Me.PixieHelpBox.Name = "PixieHelpBox"
        Me.PixieHelpBox.Size = New System.Drawing.Size(70, 70)
        Me.PixieHelpBox.TabIndex = 4
        Me.PixieHelpBox.TabStop = False
        '
        'ShowDrivesBox
        '
        Me.ShowDrivesBox.BackColor = System.Drawing.Color.AliceBlue
        Me.ShowDrivesBox.BackgroundImage = Global.Pixie.My.Resources.BrowserResources.DriveList
        Me.ShowDrivesBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ShowDrivesBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ShowDrivesBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ShowDrivesBox.Location = New System.Drawing.Point(2, 229)
        Me.ShowDrivesBox.Name = "ShowDrivesBox"
        Me.ShowDrivesBox.Size = New System.Drawing.Size(70, 70)
        Me.ShowDrivesBox.TabIndex = 3
        Me.ShowDrivesBox.TabStop = False
        '
        'LaunchBox
        '
        Me.LaunchBox.BackColor = System.Drawing.Color.AliceBlue
        Me.LaunchBox.BackgroundImage = Global.Pixie.My.Resources.BrowserResources.PrimaryBrowser
        Me.LaunchBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.LaunchBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LaunchBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.LaunchBox.Location = New System.Drawing.Point(3, 1)
        Me.LaunchBox.Name = "LaunchBox"
        Me.LaunchBox.Size = New System.Drawing.Size(70, 70)
        Me.LaunchBox.TabIndex = 0
        Me.LaunchBox.TabStop = False
        '
        'PickFolderBox
        '
        Me.PickFolderBox.BackColor = System.Drawing.Color.AliceBlue
        Me.PickFolderBox.BackgroundImage = Global.Pixie.My.Resources.BrowserResources.PickFolder
        Me.PickFolderBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PickFolderBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PickFolderBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PickFolderBox.Location = New System.Drawing.Point(2, 153)
        Me.PickFolderBox.Name = "PickFolderBox"
        Me.PickFolderBox.Size = New System.Drawing.Size(70, 70)
        Me.PickFolderBox.TabIndex = 2
        Me.PickFolderBox.TabStop = False
        '
        'ExploreBox
        '
        Me.ExploreBox.BackColor = System.Drawing.Color.AliceBlue
        Me.ExploreBox.BackgroundImage = Global.Pixie.My.Resources.BrowserResources.Explorer
        Me.ExploreBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ExploreBox.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ExploreBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.ExploreBox.Location = New System.Drawing.Point(2, 77)
        Me.ExploreBox.Name = "ExploreBox"
        Me.ExploreBox.Size = New System.Drawing.Size(70, 70)
        Me.ExploreBox.TabIndex = 1
        Me.ExploreBox.TabStop = False
        '
        'BrowserPanel
        '
        BrowserPanel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        BrowserPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        BrowserPanel.Controls.Add(Me.MyWebBrowser)
        BrowserPanel.Location = New System.Drawing.Point(90, 167)
        BrowserPanel.Name = "BrowserPanel"
        BrowserPanel.Size = New System.Drawing.Size(682, 376)
        BrowserPanel.TabIndex = 4
        '
        'MyWebBrowser
        '
        Me.MyWebBrowser.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MyWebBrowser.Location = New System.Drawing.Point(0, 0)
        Me.MyWebBrowser.MinimumSize = New System.Drawing.Size(20, 20)
        Me.MyWebBrowser.Name = "MyWebBrowser"
        Me.MyWebBrowser.Size = New System.Drawing.Size(678, 372)
        Me.MyWebBrowser.TabIndex = 0
        Me.MyWebBrowser.Url = New System.Uri("file://c:/users/david", System.UriKind.Absolute)
        '
        'OmniBarPanel
        '
        OmniBarPanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        OmniBarPanel.Controls.Add(Me.OmniBar)
        OmniBarPanel.Controls.Add(Me.ToolStrip1)
        OmniBarPanel.Location = New System.Drawing.Point(9, 98)
        OmniBarPanel.Name = "OmniBarPanel"
        OmniBarPanel.Size = New System.Drawing.Size(763, 61)
        OmniBarPanel.TabIndex = 5
        '
        'OmniBar
        '
        Me.OmniBar.AcceptsReturn = True
        Me.OmniBar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.OmniBar.CausesValidation = False
        Me.OmniBar.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OmniBar.Location = New System.Drawing.Point(0, 0)
        Me.OmniBar.Name = "OmniBar"
        Me.OmniBar.Size = New System.Drawing.Size(763, 27)
        Me.OmniBar.TabIndex = 0
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.None
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HomeButton, Me.RootButton, Me.UpButton, Me.BackButton, Me.ForwardButton, Me.RefreshButton, Me.ToolStripSeparator1, Me.FavoritesButton, Me.HistoryButton, Me.ToolStripSeparator2, Me.ToolsButton, Me.SetupButton, Me.ToolStripSeparator3, Me.WelcomeButton})
        Me.ToolStrip1.Location = New System.Drawing.Point(3, 31)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(349, 27)
        Me.ToolStrip1.TabIndex = 0
        '
        'HomeButton
        '
        Me.HomeButton.AutoToolTip = False
        Me.HomeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HomeButton.Image = Global.Pixie.My.Resources.BrowserResources.Home
        Me.HomeButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HomeButton.Name = "HomeButton"
        Me.HomeButton.Size = New System.Drawing.Size(24, 24)
        Me.HomeButton.Text = "Home"
        '
        'RootButton
        '
        Me.RootButton.AutoToolTip = False
        Me.RootButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RootButton.Image = Global.Pixie.My.Resources.BrowserResources.RootDirectory
        Me.RootButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RootButton.Name = "RootButton"
        Me.RootButton.Size = New System.Drawing.Size(24, 24)
        Me.RootButton.Tag = "C:\"
        Me.RootButton.Text = "C:\"
        '
        'UpButton
        '
        Me.UpButton.AutoToolTip = False
        Me.UpButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.UpButton.Image = Global.Pixie.My.Resources.BrowserResources.NavUp
        Me.UpButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.UpButton.Name = "UpButton"
        Me.UpButton.Size = New System.Drawing.Size(24, 24)
        '
        'BackButton
        '
        Me.BackButton.AutoToolTip = False
        Me.BackButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BackButton.Enabled = False
        Me.BackButton.Image = Global.Pixie.My.Resources.BrowserResources.NavBack
        Me.BackButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BackButton.Name = "BackButton"
        Me.BackButton.Size = New System.Drawing.Size(24, 24)
        '
        'ForwardButton
        '
        Me.ForwardButton.AutoToolTip = False
        Me.ForwardButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ForwardButton.Enabled = False
        Me.ForwardButton.Image = Global.Pixie.My.Resources.BrowserResources.NavForward
        Me.ForwardButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ForwardButton.Name = "ForwardButton"
        Me.ForwardButton.Size = New System.Drawing.Size(24, 24)
        '
        'RefreshButton
        '
        Me.RefreshButton.AutoToolTip = False
        Me.RefreshButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.RefreshButton.Image = Global.Pixie.My.Resources.BrowserResources.Refresh
        Me.RefreshButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.RefreshButton.Name = "RefreshButton"
        Me.RefreshButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 27)
        '
        'FavoritesButton
        '
        Me.FavoritesButton.AutoToolTip = False
        Me.FavoritesButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.FavoritesButton.Image = Global.Pixie.My.Resources.BrowserResources.Favorites
        Me.FavoritesButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.FavoritesButton.Name = "FavoritesButton"
        Me.FavoritesButton.Size = New System.Drawing.Size(24, 24)
        '
        'HistoryButton
        '
        Me.HistoryButton.AutoToolTip = False
        Me.HistoryButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.HistoryButton.Image = Global.Pixie.My.Resources.BrowserResources.History
        Me.HistoryButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.HistoryButton.Name = "HistoryButton"
        Me.HistoryButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 27)
        '
        'ToolsButton
        '
        Me.ToolsButton.AutoToolTip = False
        Me.ToolsButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ToolsButton.Image = Global.Pixie.My.Resources.BrowserResources.Tools
        Me.ToolsButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ToolsButton.Name = "ToolsButton"
        Me.ToolsButton.Size = New System.Drawing.Size(24, 24)
        '
        'SetupButton
        '
        Me.SetupButton.AutoToolTip = False
        Me.SetupButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SetupButton.Image = Global.Pixie.My.Resources.BrowserResources.Settings
        Me.SetupButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.SetupButton.Name = "SetupButton"
        Me.SetupButton.Size = New System.Drawing.Size(24, 24)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 27)
        '
        'WelcomeButton
        '
        Me.WelcomeButton.AutoToolTip = False
        Me.WelcomeButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.WelcomeButton.Image = CType(resources.GetObject("WelcomeButton.Image"), System.Drawing.Image)
        Me.WelcomeButton.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.WelcomeButton.Name = "WelcomeButton"
        Me.WelcomeButton.Size = New System.Drawing.Size(79, 24)
        Me.WelcomeButton.Text = "Welcome!"
        '
        'HelpPanel
        '
        HelpPanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        HelpPanel.BackColor = System.Drawing.Color.Transparent
        HelpPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        HelpPanel.Controls.Add(Me.HelpBox)
        HelpPanel.Location = New System.Drawing.Point(97, 9)
        HelpPanel.Name = "HelpPanel"
        HelpPanel.Size = New System.Drawing.Size(675, 83)
        HelpPanel.TabIndex = 7
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(671, 79)
        Me.HelpBox.TabIndex = 1
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl128
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(9, 9)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(82, 83)
        Me.PixieBox.TabIndex = 6
        Me.PixieBox.TabStop = False
        '
        'BrowserForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(782, 553)
        Me.Controls.Add(HelpPanel)
        Me.Controls.Add(Me.PixieBox)
        Me.Controls.Add(OmniBarPanel)
        Me.Controls.Add(BrowserPanel)
        Me.Controls.Add(LeftPanel)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MinimumSize = New System.Drawing.Size(800, 600)
        Me.Name = "BrowserForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Pixie Browser"
        LeftPanel.ResumeLayout(False)
        CType(Me.PixieHelpBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShowDrivesBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LaunchBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PickFolderBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ExploreBox, System.ComponentModel.ISupportInitialize).EndInit()
        BrowserPanel.ResumeLayout(False)
        OmniBarPanel.ResumeLayout(False)
        OmniBarPanel.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        HelpPanel.ResumeLayout(False)
        HelpPanel.PerformLayout()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MyWebBrowser As WebBrowser
    Friend WithEvents ShowDrivesBox As PictureBox
    Friend WithEvents PickFolderBox As PictureBox
    Friend WithEvents ExploreBox As PictureBox
    Friend WithEvents LaunchBox As PictureBox
    Friend WithEvents OmniBar As TextBox
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents HomeButton As ToolStripButton
    Friend WithEvents RootButton As ToolStripButton
    Friend WithEvents UpButton As ToolStripButton
    Friend WithEvents BackButton As ToolStripButton
    Friend WithEvents ForwardButton As ToolStripButton
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents RefreshButton As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents FavoritesButton As ToolStripButton
    Friend WithEvents HistoryButton As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents ToolsButton As ToolStripButton
    Friend WithEvents SetupButton As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents PixieHelpBox As PictureBox
    Friend WithEvents WelcomeButton As ToolStripButton
End Class
