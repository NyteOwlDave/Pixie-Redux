﻿
Imports System.ComponentModel

Public Class PixieForm

    ' Set to true when no USERPROFILE variable exists
    Public Shared NoUserProfile As Boolean = False

#Region "Logic for sorting out choice of images"

    ' Get current drive type
    Function GetCurrentDriveType() As DriveType
        Dim dt As DriveType = My.Settings.CurrentDriveType
        If (dt = DriveType.Undefined) Then
            dt = DriveType.FlashDrive
        End If
        Return dt
    End Function

    ' Set current drive type and update image
    Sub SetCurrentDriveType(dt As DriveType)
        If (dt = DriveType.Undefined) Then
            dt = DriveType.FlashDrive
        End If
        My.Settings.CurrentDriveType = dt
        Dim it As ImageType = GetImageTypeForDrive(dt, 128)
        DriveTypeBox.BackgroundImage = GetImageResource(it)
        If Not My.Settings.AllowToolTips Then Return
        Select Case dt
            Case DriveType.FlashDrive
                ToolTips.SetToolTip(DriveTypeBox, "Flash Drive")
            Case Else
                ToolTips.SetToolTip(DriveTypeBox, "SD Card")
        End Select
    End Sub

    ' Get current computer type
    Function GetCurrentComputerType() As ComputerType
        Dim ct As ComputerType = My.Settings.CurrentComputerType
        If (ct = ComputerType.Undefined) Then
            ct = ComputerType.Laptop
        End If
        Return ct
    End Function

    ' Set current computer type and update image
    Sub SetCurrentComputerType(ct As ComputerType)
        If (ct = ComputerType.Undefined) Then
            ct = ComputerType.Laptop
        End If
        My.Settings.CurrentComputerType = ct
        Dim it As ImageType = GetImageTypeForComputer(ct, 128)
        ComputerTypeBox.BackgroundImage = GetImageResource(it)
        If Not My.Settings.AllowToolTips Then Return
        Select Case ct
            Case ComputerType.Laptop
                ToolTips.SetToolTip(ComputerTypeBox, "Laptop Computer")
            Case Else
                ToolTips.SetToolTip(ComputerTypeBox, "Desktop Computer")
        End Select
    End Sub

    ' Update drive to computer image
    Sub UpdateDriveToComputer()
        Dim ct As ComputerType = GetCurrentComputerType()
        Dim dt As DriveType = GetCurrentDriveType()
        Dim it As ImageType = GetImageTypeDtoC(dt, ct)
        DriveToComputerBox.BackgroundImage = GetImageResource(it)
    End Sub

    ' Update computer to drive image
    Sub UpdateComputerToDrive()
        Dim ct As ComputerType = GetCurrentComputerType()
        Dim dt As DriveType = GetCurrentDriveType()
        Dim it As ImageType = GetImageTypeCtoD(dt, ct)
        ComputerToDriveBox.BackgroundImage = GetImageResource(it)
    End Sub

#End Region

#Region "Help System"

    ' Show help text
    Public Sub ShowHelp(msg As String)
        HelpBox.Text = msg
    End Sub

    ' Show standard help message
    Public Sub ShowStandardHelp()
        Dim s As String
        s = "Hi, " + My.Settings.UserName + "! "
        s += My.Resources.DefaultHelpMsg
        ShowHelp(s)
    End Sub

#End Region

#Region "Form Events"

    ' Handler for form load event
    Private Sub OnFormLoad() Handles MyBase.Load
        If Not Initialize(Me) Then
            Close()
            Return
        End If
        ShowStandardHelp()
        SetCurrentDriveType(GetCurrentDriveType())
        SetCurrentComputerType(GetCurrentComputerType())
        UpdateDriveToComputer()
        UpdateComputerToDrive()
    End Sub

#End Region

#Region "Mouse Click Events"

    ' Clicked on tools box
    Private Sub ToolsBox_Click(sender As Object, e As EventArgs) Handles ToolsBox.Click
        ' ShowHelp(My.Resources.ToDoMessage)
        BrowserUserPicturesFolder()
    End Sub

    ' Clicked on settings box
    Private Sub SettingsBox_Click(sender As Object, e As EventArgs) Handles SettingsBox.Click
        ShowHelp(My.Resources.ToDoMessage)
    End Sub

    ' Clicked on pixie help box
    Private Sub PixieHelpBox_Click(sender As Object, e As EventArgs) Handles PixieHelpBox.Click
        BrowsePixieHelp()
    End Sub

    ' Mouse click on pixie box box
    Private Sub PixieBox_Click(sender As Object, e As EventArgs) Handles PixieBox.Click
        Dim dlg As New ArtViewDlg
        dlg.ShowDialog(Me)
    End Sub

    ' Mouse click on drive to computer box box
    Private Sub DriveToComputerBox_Click(sender As Object, e As EventArgs) Handles DriveToComputerBox.Click
        ShowHelp(My.Resources.ToDoMessage)
    End Sub

    ' Mouse click on computer to drive box box
    Private Sub ComputerToDriveBox_Click(sender As Object, e As EventArgs) Handles ComputerToDriveBox.Click
        ShowHelp(My.Resources.ToDoMessage)
    End Sub

    ' Mouse click on drive type box
    Private Sub DriveTypeBox_Click(sender As Object, e As EventArgs) Handles DriveTypeBox.Click
        Dim dlg As DriveTypeDlg = New DriveTypeDlg
        Dim n As DialogResult = dlg.ShowDialog(Me)
        If n = DialogResult.OK Then
            Dim dt As DriveType = dlg.Result
            SetCurrentDriveType(dt)
            UpdateComputerToDrive()
            UpdateDriveToComputer()
        End If
    End Sub

    ' Mouse click on computer type box
    Private Sub ComputerTypeBox_Click(sender As Object, e As EventArgs) Handles ComputerTypeBox.Click
        Dim dlg As ComputerTypeDlg = New ComputerTypeDlg
        Dim n As DialogResult = dlg.ShowDialog(Me)
        If n = DialogResult.OK Then
            Dim dt As ComputerType = dlg.Result
            SetCurrentComputerType(dt)
            UpdateComputerToDrive()
            UpdateDriveToComputer()
        End If
    End Sub

    ' Mouse click on my pictures box
    Private Sub MyPicturesBox_Click(sender As Object, e As EventArgs) Handles MyPicturesBox.Click
        SpecialFoldersDlg.Reveal()
    End Sub

#End Region

#Region "Mouse Enter/Leave/Hover Events"

    ' Mouse enters pixie box
    Private Sub PixieBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieBox.MouseEnter
        ShowHelp("Click my picture to see my art. You can also check your computer drives and my program files.")
    End Sub

    ' Mouse leaves pixie box
    Private Sub PixieBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse enters drive to computer box
    Private Sub DriveToComputerBox_MouseEnter(sender As Object, e As EventArgs) Handles DriveToComputerBox.MouseEnter
        ShowHelp("Click here to copy files from a removable drive to your computer.")
    End Sub

    ' Mouse leaves drive to computer box
    Private Sub DriveToComputerBox_MouseLeave(sender As Object, e As EventArgs) Handles DriveToComputerBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse enters computer to drive box
    Private Sub ComputerToDriveBox_MouseEnter(sender As Object, e As EventArgs) Handles ComputerToDriveBox.MouseEnter
        ShowHelp("Click here to copy files from your computer to a removable drive.")
    End Sub

    ' Mouse leaves computer to drive box
    Private Sub ComputerToDriveBox_MouseLeave(sender As Object, e As EventArgs) Handles ComputerToDriveBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse enters drive type box
    Private Sub DriveTypeBox_MouseEnter(sender As Object, e As EventArgs) Handles DriveTypeBox.MouseEnter
        ShowHelp("Click here to choose a picture to represent the type of removable drive you use.")
    End Sub

    ' Mouse leaves drive type box
    Private Sub DriveTypeBox_MouseLeave(sender As Object, e As EventArgs) Handles DriveTypeBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse enters computer box
    Private Sub ComputerTypeBox_MouseEnter(sender As Object, e As EventArgs) Handles ComputerTypeBox.MouseEnter
        ShowHelp("Click here to choose a picture to represent the type of computer you use.")
    End Sub

    ' Mouse leaves computer box
    Private Sub ComputerTypeBox_MouseLeave(sender As Object, e As EventArgs) Handles ComputerTypeBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse enters my profile box
    Private Sub MyPicturesBox_MouseEnter(sender As Object, e As EventArgs) Handles MyPicturesBox.MouseEnter
        Dim t As String
        Dim s As String = Environ("USERPROFILE")
        If s Is Nothing Then
            t = "Click here to browse your computer's files."
            NoUserProfile = True
        Else
            t = "Click here to call up a window that lets you access your special" &
                " folders, like pictures, videos, music and more."
        End If
        ShowHelp(t)
    End Sub

    ' Mouse leaves my profile box
    Private Sub MyPicturesBox_MouseLeave(sender As Object, e As EventArgs) Handles MyPicturesBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse hovering over main form
    Private Sub PixieForm_Hover(sender As Object, e As EventArgs) Handles MyBase.MouseHover
        ShowStandardHelp()
    End Sub

    ' Mouse entering help box
    Private Sub HelpBox_MouseEnter(sender As Object, e As EventArgs) Handles HelpBox.MouseEnter
        Me.Cursor = System.Windows.Forms.Cursors.No
    End Sub

    ' Mouse leaving help box
    Private Sub HelpBox_MouseLeave(sender As Object, e As EventArgs) Handles HelpBox.MouseLeave
        Me.Cursor = System.Windows.Forms.Cursors.Default
    End Sub

    ' Mouse entering tools box
    Private Sub ToolsBox_MouseEnter(sender As Object, e As EventArgs) Handles ToolsBox.MouseEnter
        ShowHelp("Click here to work with some of the extra tools that I have for you." &
                 " For example, you can do a full backup or restore.")
    End Sub

    ' Mouse leaving tools box
    Private Sub ToolsBox_MouseLeave(sender As Object, e As EventArgs) Handles ToolsBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering pixie help box
    Private Sub PixieHelpBox_MouseEnter(sender As Object, e As EventArgs) Handles PixieHelpBox.MouseEnter
        ShowHelp("Click here to get more help with using me.")
    End Sub

    ' Mouse leaving pixie help box
    Private Sub PixieHelpBox_MouseLeave(sender As Object, e As EventArgs) Handles PixieHelpBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entering settings box
    Private Sub SettingsBox_MouseEnter(sender As Object, e As EventArgs) Handles SettingsBox.MouseEnter
        ShowHelp("Click here to change some of my settings. For example, you can change your user name.")
    End Sub

    ' Mouse leaving settings box
    Private Sub SettingsBox_MouseLeave(sender As Object, e As EventArgs) Handles SettingsBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Form closing
    Private Sub PixieForm_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        With My.Application.OpenForms
            If .Count > 1 Then
                If .Item(0).GetType().Name <> "PixieForm" Then
                    e.Cancel = True
                    Me.Hide()
                    Return
                End If
            End If
        End With
        e.Cancel = False
    End Sub

#End Region

End Class
