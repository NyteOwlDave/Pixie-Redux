﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class JobForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(JobForm))
        Me.TrafficBox = New System.Windows.Forms.PictureBox()
        Me.PixieBox = New System.Windows.Forms.PictureBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.HelpBox = New System.Windows.Forms.TextBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        CType(Me.TrafficBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TrafficBox
        '
        Me.TrafficBox.BackgroundImage = Global.Pixie.My.Resources.JobResources.TrafficLightGreen
        Me.TrafficBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TrafficBox.Location = New System.Drawing.Point(12, 179)
        Me.TrafficBox.Name = "TrafficBox"
        Me.TrafficBox.Size = New System.Drawing.Size(160, 320)
        Me.TrafficBox.TabIndex = 0
        Me.TrafficBox.TabStop = False
        '
        'PixieBox
        '
        Me.PixieBox.BackgroundImage = Global.Pixie.My.Resources.PixieResources.PixieGirl
        Me.PixieBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PixieBox.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PixieBox.Location = New System.Drawing.Point(12, 12)
        Me.PixieBox.Name = "PixieBox"
        Me.PixieBox.Size = New System.Drawing.Size(160, 161)
        Me.PixieBox.TabIndex = 2
        Me.PixieBox.TabStop = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.HelpBox)
        Me.Panel1.Location = New System.Drawing.Point(178, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(566, 161)
        Me.Panel1.TabIndex = 3
        '
        'HelpBox
        '
        Me.HelpBox.BackColor = System.Drawing.Color.PaleGoldenrod
        Me.HelpBox.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.HelpBox.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.HelpBox.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HelpBox.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.HelpBox.Location = New System.Drawing.Point(0, 0)
        Me.HelpBox.Multiline = True
        Me.HelpBox.Name = "HelpBox"
        Me.HelpBox.ReadOnly = True
        Me.HelpBox.Size = New System.Drawing.Size(562, 157)
        Me.HelpBox.TabIndex = 1
        Me.HelpBox.TabStop = False
        Me.HelpBox.Text = "Hello! Point your cursor at something and I'll tell you what it does."
        Me.HelpBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.HelpBox.WordWrap = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.ProgressBar1.Location = New System.Drawing.Point(0, 505)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(756, 23)
        Me.ProgressBar1.TabIndex = 4
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.BalloonTipIcon = System.Windows.Forms.ToolTipIcon.Info
        Me.NotifyIcon1.BalloonTipText = "Hello!"
        Me.NotifyIcon1.BalloonTipTitle = "Pixie"
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "Your Pixie is working!"
        Me.NotifyIcon1.Visible = True
        '
        'JobForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(756, 528)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PixieBox)
        Me.Controls.Add(Me.TrafficBox)
        Me.Name = "JobForm"
        Me.Text = "Working"
        CType(Me.TrafficBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PixieBox, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TrafficBox As PictureBox
    Friend WithEvents PixieBox As PictureBox
    Friend WithEvents Panel1 As Panel
    Friend WithEvents HelpBox As TextBox
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents NotifyIcon1 As NotifyIcon
End Class
