﻿
' Account Manager Form
Imports System.ComponentModel

Public Class AccountManagerForm

    ' Whether the managed data has changed in any way,
    ' so we know whether the file needs to be saved before
    ' closing the form.
    Public Property IsModified As Boolean = False

#Region "Quick Help Logic"

    ' Show help message
    Private Sub ShowHelp(msg As String)
        Me.HelpMessageLabel.Text = msg
    End Sub

    ' Show standard help
    Private Sub ShowStandardHelp()
        ShowHelp("Point the cursor at a control.")
    End Sub

#End Region

#Region "Simple popup (temporary)"

    ' TODO popup
    Private Sub Popup(msg As String)
        Dim cap As String = "TODO"
        Dim style As MsgBoxStyle = MsgBoxStyle.Information
        MsgBox(msg, style, cap)
    End Sub

#End Region

#Region "Form Events"

    ' Form Load Event
    Private Sub AccountManagerForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' TODO...
        ShowStandardHelp()
    End Sub

#End Region

#Region "Menu Item Click Events"

    ' Clicked on file save menu item
    Private Sub SaveMenuItem_Click(sender As Object, e As EventArgs) Handles SaveMenuItem.Click
        ' TODO...
        Popup("Save File")
    End Sub

    ' Clicked on file close menu item
    Private Sub CloseMenuItem_Click(sender As Object, e As EventArgs) Handles CloseMenuItem.Click
        ' TODO...
        Popup("Close Window")
    End Sub

    ' Clicked on account new menu item
    Private Sub AccountNewMenuItem_Click(sender As Object, e As EventArgs) Handles AccountNewMenuItem.Click
        ' TODO...
        Popup("Create New Account")
    End Sub

    ' Clicked on account configure menu item
    Private Sub AccountConfigureMenuItem_Click(sender As Object, e As EventArgs) Handles AccountConfigureMenuItem.Click
        ' TODO...
        Popup("Configure Account")
    End Sub

    ' Clicked on account rename menu item
    Private Sub AccountRenameMenuItem_Click(sender As Object, e As EventArgs) Handles AccountRenameMenuItem.Click
        ' TODO...
        Popup("Rename Account")
    End Sub

    ' Clicked on account delete menu item
    Private Sub AccountDeleteMenuItem_Click(sender As Object, e As EventArgs) Handles AccountDeleteMenuItem.Click
        ' TODO...
        Popup("Delete Account")
    End Sub

    ' Clicked on help manual menu item
    Private Sub HelpManualMenuItem_Click(sender As Object, e As EventArgs) Handles HelpManualMenuItem.Click
        ' TODO...
        Popup("Help Manual")
    End Sub

    ' Clicked on help about menu item
    Private Sub HelpAboutMenuItem_Click(sender As Object, e As EventArgs) Handles HelpAboutMenuItem.Click
        ' TODO...
        Popup("About Dialog")
    End Sub

    ' Clicked on view all accounts menu item
    Private Sub ViewAllAccountsMenuItem_Click(sender As Object, e As EventArgs) Handles ViewAllAccountsMenuItem.Click
        ' TODO...
        Popup("View All Accounts")
    End Sub

    ' Clicked on view active accounts menu item
    Private Sub ViewActiveAccountsMenuItem_Click(sender As Object, e As EventArgs) Handles ViewActiveAccountsMenuItem.Click
        ' TODO...
        Popup("View Active Accounts")
    End Sub

    ' Clicked on view inactive accounts menu item
    Private Sub ViewInactiveAccountsMenuItem_Click(sender As Object, e As EventArgs) Handles ViewInactiveAccountsMenuItem.Click
        ' TODO...
        Popup("View Inactive Accounts")
    End Sub

    ' Clicked on account activate menu item
    Private Sub AccountActivateMenuItem_Click(sender As Object, e As EventArgs) Handles AccountActivateMenuItem.Click
        ActivateAccount()
    End Sub

    ' Clicked on account deactivate menu item
    Private Sub AccountDeactivateMenuItem_Click(sender As Object, e As EventArgs) Handles AccountDeactivateMenuItem.Click
        DeactivateAccount()
    End Sub

#End Region

#Region "Tool Strip Click Events"

    ' Clicked on file choose group button
    Private Sub FileChooseGroupButton_Click(sender As Object, e As EventArgs) Handles FileChooseGroupButton.Click

    End Sub

    ' Clicked on file undo changes button
    Private Sub FileUndoChangesButton_Click(sender As Object, e As EventArgs) Handles FileUndoChangesButton.Click

    End Sub

    ' Clicked on file save toolbar button
    Private Sub FileSaveChangesButton_Click(sender As Object, e As EventArgs) Handles FileSaveChangesButton.Click
        Me.SaveMenuItem_Click(sender, e)
    End Sub

    ' Clicked on file close toolbar button
    Private Sub FileCloseButton_Click(sender As Object, e As EventArgs) Handles FileCloseButton.Click
        Me.CloseMenuItem_Click(sender, e)
    End Sub

    ' Clicked on account new toolbar button
    Private Sub AccountNewButton_Click(sender As Object, e As EventArgs) Handles AccountNewButton.Click
        Me.AccountNewMenuItem_Click(sender, e)
    End Sub

    ' Clicked on account configure toolbar button
    Private Sub AccountConfigureButton_Click(sender As Object, e As EventArgs) Handles AccountConfigureButton.Click
        Me.AccountConfigureMenuItem_Click(sender, e)
    End Sub

    ' Clicked on account rename button
    Private Sub AccountRenameButton_Click(sender As Object, e As EventArgs) Handles AccountRenameButton.Click
        Me.AccountRenameMenuItem_Click(sender, e)
    End Sub

    ' Clicked on account delete toolbar button
    Private Sub AccountDeleteButton_Click(sender As Object, e As EventArgs) Handles AccountDeleteButton.Click
        Me.AccountDeleteMenuItem_Click(sender, e)
    End Sub

    ' Clicked on help manual toolbar button
    Private Sub HelpManualButton_Click(sender As Object, e As EventArgs) Handles HelpManualButton.Click
        Me.HelpManualMenuItem_Click(sender, e)
    End Sub

    ' Clicked on help about toolbar button
    Private Sub HelpAboutButton_Click(sender As Object, e As EventArgs) Handles HelpAboutButton.Click
        Me.HelpAboutMenuItem_Click(sender, e)
    End Sub

    ' Clicked on view rotate toolbar button
    Private Sub ViewRotateButton_Click(sender As Object, e As EventArgs) Handles ViewRotateButton.Click
        RotateViewMode()
    End Sub

    ' Clicked on account toggle status button
    Private Sub AccountToggleStatusButton_Click(sender As Object, e As EventArgs) Handles AccountToggleStatusButton.Click
        ToggleAccountStatus()
    End Sub

#End Region

#Region "Mouse Enter/Leave/Hover Events"

    ' Mouse entered account configure button
    Private Sub AccountConfigureButton_MouseEnter(sender As Object, e As EventArgs) Handles AccountConfigureButton.MouseEnter
        ShowHelp("View or modify an account")
    End Sub

    ' Mouse left account configure button
    Private Sub AccountConfigureButton_MouseLeave(sender As Object, e As EventArgs) Handles AccountConfigureButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered account delete button
    Private Sub AccountDeleteButton_MouseEnter(sender As Object, e As EventArgs) Handles AccountDeleteButton.MouseEnter
        ShowHelp("Delete an account")
    End Sub

    ' Mouse left account delete button
    Private Sub AccountDeleteButton_MouseLeave(sender As Object, e As EventArgs) Handles AccountDeleteButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered account new button
    Private Sub AccountNewButton_MouseEnter(sender As Object, e As EventArgs) Handles AccountNewButton.MouseEnter
        ShowHelp("Create a new account")
    End Sub

    ' Mouse left account new button
    Private Sub AccountNewButton_MouseLeave(sender As Object, e As EventArgs) Handles AccountNewButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered file close button
    Private Sub FileCloseButton_MouseEnter(sender As Object, e As EventArgs) Handles FileCloseButton.MouseEnter
        ShowHelp("Close the window")
    End Sub

    ' Mouse left file close button
    Private Sub FileCloseButton_MouseLeave(sender As Object, e As EventArgs) Handles FileCloseButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered file save button
    Private Sub FileSaveButton_MouseEnter(sender As Object, e As EventArgs) Handles FileSaveChangesButton.MouseEnter
        ShowHelp("Save all changes")
    End Sub

    ' Mouse left file save button
    Private Sub FileSaveButton_MouseLeave(sender As Object, e As EventArgs) Handles FileSaveChangesButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered help about button
    Private Sub HelpAboutButton_MouseEnter(sender As Object, e As EventArgs) Handles HelpAboutButton.MouseEnter
        ShowHelp("Show version details")
    End Sub

    ' Mouse left help about button
    Private Sub HelpAboutButton_MouseLeave(sender As Object, e As EventArgs) Handles HelpAboutButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered help manual button
    Private Sub HelpManualButton_MouseEnter(sender As Object, e As EventArgs) Handles HelpManualButton.MouseEnter
        ShowHelp("Browse the user's manual")
    End Sub

    ' Mouse left help manual button
    Private Sub HelpManualButton_MouseLeave(sender As Object, e As EventArgs) Handles HelpManualButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered account rename button
    Private Sub AccountRenameButton_MouseEnter(sender As Object, e As EventArgs) Handles AccountRenameButton.MouseEnter
        ShowHelp("Change account name")
    End Sub

    ' Mouse left account rename button
    Private Sub AccountRenameButton_MouseLeave(sender As Object, e As EventArgs) Handles AccountRenameButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered account toggle status button
    Private Sub AccountToggleStatusButton_MouseEnter(sender As Object, e As EventArgs) Handles AccountToggleStatusButton.MouseEnter
        If Not IsAccountSelected() Then
            ShowHelp("Unavailable until an account is selected")
            Return
        End If
        If IsAccountActive() Then
            ShowHelp("Deactivate selected account")
        Else
            ShowHelp("Activate selected account")
        End If
    End Sub

    ' Mouse left account toggle status button
    Private Sub AccountToggleStatusButton_MouseLeave(sender As Object, e As EventArgs) Handles AccountToggleStatusButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered view rotate button
    Private Sub ViewRotateButton_MouseEnter(sender As Object, e As EventArgs) Handles ViewRotateButton.MouseEnter
        ShowHelp("")
    End Sub

    ' Mouse left view rotate button
    Private Sub ViewRotateButton_MouseLeave(sender As Object, e As EventArgs) Handles ViewRotateButton.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered protocol text box
    Private Sub ProtocolTextBox_MouseEnter(sender As Object, e As EventArgs) Handles ProtocolTextBox.MouseEnter
        ShowHelp("")
    End Sub

    ' Mouse left protocol text box
    Private Sub ProtocolTextBox_MouseLeave(sender As Object, e As EventArgs) Handles ProtocolTextBox.MouseLeave
        ShowStandardHelp()
    End Sub

    ' Mouse entered site text box
    Private Sub SiteTextBox_MouseEnter(sender As Object, e As EventArgs) Handles SiteTextBox.MouseEnter
        ShowHelp("")
    End Sub

    ' Mouse left ?
    Private Sub SiteTextBox_MouseLeave(sender As Object, e As EventArgs) Handles SiteTextBox.MouseLeave
        ShowStandardHelp()
    End Sub

#End Region

#Region "View Mode Logic"

    ' Rotate view mode
    Private Sub RotateViewMode()
        ' TODO...
        Popup("Rotate View Mode")
    End Sub

#End Region

#Region "Account Activation/Deactivation Logic"

    ' Determines whether an account is selected
    Private Function IsAccountSelected() As Boolean
        If Me.AccountsListView.SelectedIndices.Count < 1 Then
            Return False
        Else
            Return True
        End If
    End Function

    ' Determines whether the selected account is active
    Private Function IsAccountActive() As Boolean
        ' TODO...
        Return True
    End Function

    ' Toggles the account status between active/inactive
    Private Sub ToggleAccountStatus()
        If IsAccountActive() Then
            DeactivateAccount()
        Else
            ActivateAccount()
        End If
    End Sub

    ' Activates the selected account
    Private Sub ActivateAccount()
        ' TODO...
        Popup("Activate Account")
    End Sub

    ' Deactivates the selected account
    Private Sub DeactivateAccount()
        ' TODO...
        Popup("Activate Account")
    End Sub

    ' Load accounts file
    Private Sub LoadAccountsFile()
        ' TODO...
        PopulateList()
    End Sub

    ' Save accounts file
    Private Sub SaveAccountsFile()
        ' TODO...
    End Sub

    ' Populate list
    Private Sub PopulateList()
        ' TODO...
    End Sub

    ' Form is about to close
    Private Sub AccountManagerForm_Closing(sender As Object, e As CancelEventArgs) Handles Me.Closing
        If Not IsModified() Then
            e.Cancel = False
            Return
        End If
        Dim dlg As New SaveChangesDlg
            dlg.Message = "You've made some changes that haven't yet been saved." &
                " How would you like to proceed?"
        dlg.ShowDialog(Me)
        Try
            Select Case dlg.Action
                Case SaveChangesDlg.ActionEnum.SaveAndStayOpen
                    SaveAccountsFile()
                    e.Cancel = True
                    Return
                Case SaveChangesDlg.ActionEnum.SaveAndClose
                    SaveAccountsFile()
                    e.Cancel = False
                    Return
                Case SaveChangesDlg.ActionEnum.DiscardAndStayOpen
                    LoadAccountsFile()
                    e.Cancel = True
                    Return
                Case SaveChangesDlg.ActionEnum.DiscardAndClose
                    e.Cancel = False
                    Return
            End Select
        Catch ex As Exception
            ShowErrorBox(ex.Message)
            ShowWarnBox("Closing Window without saving changes.")
            e.Cancel = False
        End Try
    End Sub

#End Region

#Region "ListView Label Editing Events Events"

    ' TODO...

#End Region

End Class

