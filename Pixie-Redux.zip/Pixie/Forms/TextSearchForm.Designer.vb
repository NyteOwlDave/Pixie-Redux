﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TextSearchForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TextSearchForm))
        Me.FolderGroupBox = New System.Windows.Forms.GroupBox()
        Me.CurrentFolderLabel = New System.Windows.Forms.LinkLabel()
        Me.SearchForGroupBox = New System.Windows.Forms.GroupBox()
        Me.SubfoldersCheckBox = New System.Windows.Forms.CheckBox()
        Me.WholeWordCheckBox = New System.Windows.Forms.CheckBox()
        Me.SearchTextBox = New System.Windows.Forms.TextBox()
        Me.CaseSenseCheckBox = New System.Windows.Forms.CheckBox()
        Me.FileExtGroupBox = New System.Windows.Forms.GroupBox()
        Me.FileExtButton = New System.Windows.Forms.Button()
        Me.FileExtTextBox = New System.Windows.Forms.TextBox()
        Me.MyThread = New System.ComponentModel.BackgroundWorker()
        Me.MyTimer = New System.Windows.Forms.Timer(Me.components)
        Me.MyProgressBar = New System.Windows.Forms.ProgressBar()
        Me.ActionButton = New System.Windows.Forms.Button()
        Me.ResultsGroupBox = New System.Windows.Forms.GroupBox()
        Me.ResultsBox = New System.Windows.Forms.TextBox()
        Me.ClearResultsButton = New System.Windows.Forms.Button()
        Me.FolderGroupBox.SuspendLayout()
        Me.SearchForGroupBox.SuspendLayout()
        Me.FileExtGroupBox.SuspendLayout()
        Me.ResultsGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'FolderGroupBox
        '
        Me.FolderGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FolderGroupBox.Controls.Add(Me.CurrentFolderLabel)
        Me.FolderGroupBox.Location = New System.Drawing.Point(12, 193)
        Me.FolderGroupBox.Name = "FolderGroupBox"
        Me.FolderGroupBox.Size = New System.Drawing.Size(622, 51)
        Me.FolderGroupBox.TabIndex = 4
        Me.FolderGroupBox.TabStop = False
        Me.FolderGroupBox.Text = "Current Folder"
        '
        'CurrentFolderLabel
        '
        Me.CurrentFolderLabel.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CurrentFolderLabel.AutoEllipsis = True
        Me.CurrentFolderLabel.LinkBehavior = System.Windows.Forms.LinkBehavior.AlwaysUnderline
        Me.CurrentFolderLabel.Location = New System.Drawing.Point(6, 21)
        Me.CurrentFolderLabel.Name = "CurrentFolderLabel"
        Me.CurrentFolderLabel.Size = New System.Drawing.Size(609, 19)
        Me.CurrentFolderLabel.TabIndex = 4
        Me.CurrentFolderLabel.TabStop = True
        Me.CurrentFolderLabel.Text = "C:\"
        Me.CurrentFolderLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SearchForGroupBox
        '
        Me.SearchForGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SearchForGroupBox.Controls.Add(Me.SubfoldersCheckBox)
        Me.SearchForGroupBox.Controls.Add(Me.WholeWordCheckBox)
        Me.SearchForGroupBox.Controls.Add(Me.SearchTextBox)
        Me.SearchForGroupBox.Controls.Add(Me.CaseSenseCheckBox)
        Me.SearchForGroupBox.Location = New System.Drawing.Point(12, 10)
        Me.SearchForGroupBox.Name = "SearchForGroupBox"
        Me.SearchForGroupBox.Size = New System.Drawing.Size(622, 78)
        Me.SearchForGroupBox.TabIndex = 5
        Me.SearchForGroupBox.TabStop = False
        Me.SearchForGroupBox.Text = "Search For"
        '
        'SubfoldersCheckBox
        '
        Me.SubfoldersCheckBox.AutoSize = True
        Me.SubfoldersCheckBox.Location = New System.Drawing.Point(249, 49)
        Me.SubfoldersCheckBox.Name = "SubfoldersCheckBox"
        Me.SubfoldersCheckBox.Size = New System.Drawing.Size(178, 21)
        Me.SubfoldersCheckBox.TabIndex = 4
        Me.SubfoldersCheckBox.Text = "Search Subfolders Also"
        Me.SubfoldersCheckBox.UseVisualStyleBackColor = True
        '
        'WholeWordCheckBox
        '
        Me.WholeWordCheckBox.AutoSize = True
        Me.WholeWordCheckBox.Location = New System.Drawing.Point(135, 49)
        Me.WholeWordCheckBox.Name = "WholeWordCheckBox"
        Me.WholeWordCheckBox.Size = New System.Drawing.Size(108, 21)
        Me.WholeWordCheckBox.TabIndex = 3
        Me.WholeWordCheckBox.Text = "Whole Word"
        Me.WholeWordCheckBox.UseVisualStyleBackColor = True
        '
        'SearchTextBox
        '
        Me.SearchTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SearchTextBox.Location = New System.Drawing.Point(6, 21)
        Me.SearchTextBox.Name = "SearchTextBox"
        Me.SearchTextBox.Size = New System.Drawing.Size(610, 22)
        Me.SearchTextBox.TabIndex = 1
        '
        'CaseSenseCheckBox
        '
        Me.CaseSenseCheckBox.AutoSize = True
        Me.CaseSenseCheckBox.Location = New System.Drawing.Point(6, 49)
        Me.CaseSenseCheckBox.Name = "CaseSenseCheckBox"
        Me.CaseSenseCheckBox.Size = New System.Drawing.Size(123, 21)
        Me.CaseSenseCheckBox.TabIndex = 2
        Me.CaseSenseCheckBox.Text = "Case Sensitive"
        Me.CaseSenseCheckBox.UseVisualStyleBackColor = True
        '
        'FileExtGroupBox
        '
        Me.FileExtGroupBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FileExtGroupBox.Controls.Add(Me.FileExtButton)
        Me.FileExtGroupBox.Controls.Add(Me.FileExtTextBox)
        Me.FileExtGroupBox.Location = New System.Drawing.Point(12, 94)
        Me.FileExtGroupBox.Name = "FileExtGroupBox"
        Me.FileExtGroupBox.Size = New System.Drawing.Size(622, 59)
        Me.FileExtGroupBox.TabIndex = 6
        Me.FileExtGroupBox.TabStop = False
        Me.FileExtGroupBox.Text = "Filename Extensions"
        '
        'FileExtButton
        '
        Me.FileExtButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FileExtButton.Font = New System.Drawing.Font("Segoe UI Symbol", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileExtButton.Location = New System.Drawing.Point(573, 21)
        Me.FileExtButton.Name = "FileExtButton"
        Me.FileExtButton.Size = New System.Drawing.Size(42, 27)
        Me.FileExtButton.TabIndex = 3
        Me.FileExtButton.Text = ">>"
        Me.FileExtButton.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.FileExtButton.UseVisualStyleBackColor = True
        '
        'FileExtTextBox
        '
        Me.FileExtTextBox.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FileExtTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FileExtTextBox.Location = New System.Drawing.Point(6, 21)
        Me.FileExtTextBox.Name = "FileExtTextBox"
        Me.FileExtTextBox.Size = New System.Drawing.Size(562, 27)
        Me.FileExtTextBox.TabIndex = 2
        '
        'MyThread
        '
        Me.MyThread.WorkerSupportsCancellation = True
        '
        'MyTimer
        '
        '
        'MyProgressBar
        '
        Me.MyProgressBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.MyProgressBar.Location = New System.Drawing.Point(0, 250)
        Me.MyProgressBar.MarqueeAnimationSpeed = 15
        Me.MyProgressBar.Name = "MyProgressBar"
        Me.MyProgressBar.Size = New System.Drawing.Size(646, 23)
        Me.MyProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous
        Me.MyProgressBar.TabIndex = 0
        '
        'ActionButton
        '
        Me.ActionButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ActionButton.Location = New System.Drawing.Point(12, 159)
        Me.ActionButton.Name = "ActionButton"
        Me.ActionButton.Size = New System.Drawing.Size(167, 28)
        Me.ActionButton.TabIndex = 7
        Me.ActionButton.Text = "Begin Search"
        Me.ActionButton.UseVisualStyleBackColor = True
        '
        'ResultsGroupBox
        '
        Me.ResultsGroupBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ResultsGroupBox.Controls.Add(Me.ResultsBox)
        Me.ResultsGroupBox.Location = New System.Drawing.Point(12, 12)
        Me.ResultsGroupBox.Name = "ResultsGroupBox"
        Me.ResultsGroupBox.Size = New System.Drawing.Size(622, 0)
        Me.ResultsGroupBox.TabIndex = 8
        Me.ResultsGroupBox.TabStop = False
        Me.ResultsGroupBox.Text = "Results"
        Me.ResultsGroupBox.Visible = False
        '
        'ResultsBox
        '
        Me.ResultsBox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ResultsBox.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ResultsBox.Enabled = False
        Me.ResultsBox.ForeColor = System.Drawing.Color.White
        Me.ResultsBox.Location = New System.Drawing.Point(6, 21)
        Me.ResultsBox.MaxLength = 1048576
        Me.ResultsBox.Multiline = True
        Me.ResultsBox.Name = "ResultsBox"
        Me.ResultsBox.ReadOnly = True
        Me.ResultsBox.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.ResultsBox.ShortcutsEnabled = False
        Me.ResultsBox.Size = New System.Drawing.Size(610, 0)
        Me.ResultsBox.TabIndex = 0
        Me.ResultsBox.TabStop = False
        Me.ResultsBox.WordWrap = False
        '
        'ClearResultsButton
        '
        Me.ClearResultsButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ClearResultsButton.Enabled = False
        Me.ClearResultsButton.Location = New System.Drawing.Point(185, 159)
        Me.ClearResultsButton.Name = "ClearResultsButton"
        Me.ClearResultsButton.Size = New System.Drawing.Size(167, 28)
        Me.ClearResultsButton.TabIndex = 9
        Me.ClearResultsButton.Text = "Clear Results"
        Me.ClearResultsButton.UseVisualStyleBackColor = True
        '
        'TextSearchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(646, 273)
        Me.Controls.Add(Me.ClearResultsButton)
        Me.Controls.Add(Me.ResultsGroupBox)
        Me.Controls.Add(Me.ActionButton)
        Me.Controls.Add(Me.FileExtGroupBox)
        Me.Controls.Add(Me.SearchForGroupBox)
        Me.Controls.Add(Me.FolderGroupBox)
        Me.Controls.Add(Me.MyProgressBar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximumSize = New System.Drawing.Size(8000, 6000)
        Me.MinimumSize = New System.Drawing.Size(664, 320)
        Me.Name = "TextSearchForm"
        Me.Text = "Text Search"
        Me.FolderGroupBox.ResumeLayout(False)
        Me.SearchForGroupBox.ResumeLayout(False)
        Me.SearchForGroupBox.PerformLayout()
        Me.FileExtGroupBox.ResumeLayout(False)
        Me.FileExtGroupBox.PerformLayout()
        Me.ResultsGroupBox.ResumeLayout(False)
        Me.ResultsGroupBox.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents MyThread As System.ComponentModel.BackgroundWorker
    Friend WithEvents MyTimer As Timer
    Friend WithEvents MyProgressBar As ProgressBar
    Friend WithEvents SearchTextBox As TextBox
    Friend WithEvents CaseSenseCheckBox As CheckBox
    Friend WithEvents SubfoldersCheckBox As CheckBox
    Friend WithEvents WholeWordCheckBox As CheckBox
    Friend WithEvents FileExtButton As Button
    Friend WithEvents FileExtTextBox As TextBox
    Friend WithEvents ActionButton As Button
    Friend WithEvents CurrentFolderLabel As LinkLabel
    Friend WithEvents ResultsBox As TextBox
    Friend WithEvents ResultsGroupBox As GroupBox
    Friend WithEvents FolderGroupBox As GroupBox
    Friend WithEvents SearchForGroupBox As GroupBox
    Friend WithEvents FileExtGroupBox As GroupBox
    Friend WithEvents ClearResultsButton As Button
End Class
