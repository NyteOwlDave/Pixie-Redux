﻿
Public Module SupportModule

    ' Format date string
    Function FormatDateString(d As Date) As String
        Dim s As String = d.Year.ToString()
        s += "/" + d.Month.ToString("00")
        s += "/" + d.Day.ToString("00")
        Return s
    End Function

    ' Show to-do message in a control
    Sub ShowToDo(ctrl As Control)
        If ctrl IsNot Nothing Then
            ctrl.Text = My.Resources.ToDoMessage
        Else
            ToDo()
        End If
    End Sub

    ' Shows an OK/Cancel popup
    Function ShowOkCancelBox(msg As String) As MsgBoxResult
        Dim result As DialogResult
        Dim parent As Form = My.Application.OpenForms(0)
        result = ActionDlg.Execute(parent, msg, ActionDlg.Mode.OKCancel)
        Select Case result
            Case DialogResult.OK
                Return MsgBoxResult.Ok
            Case Else
                Return MsgBoxResult.Cancel
        End Select
    End Function

    ' Shows a Yes/No popup
    Function ShowYesNoBox(msg As String) As MsgBoxResult
        Dim result As DialogResult
        Dim parent As Form = My.Application.OpenForms(0)
        result = ActionDlg.Execute(parent, msg, ActionDlg.Mode.YesNo)
        Select Case result
            Case DialogResult.Yes
                Return MsgBoxResult.Yes
            Case Else
                Return MsgBoxResult.No
        End Select
    End Function

    ' Shows an informational message popup
    Sub ShowInfoBox(msg As String)
        Dim parent As Form = My.Application.OpenForms(0)
        AlertDlg.Execute(parent, msg, Nothing, AlertDlg.Mode.Notice)
    End Sub

    ' Shows a warning message popup
    Sub ShowWarnBox(msg As String)
        Dim parent As Form = My.Application.OpenForms(0)
        AlertDlg.Execute(parent, msg, Nothing, AlertDlg.Mode.Warning)
    End Sub

    ' Shows an error message popup
    Sub ShowErrorBox(msg As String)
        Dim parent As Form = My.Application.OpenForms(0)
        AlertDlg.Execute(parent, msg, Nothing, AlertDlg.Mode.Critical)
    End Sub

    ' Message box for todo items
    Sub ToDo()
        ShowInfoBox(My.Resources.ToDoMessage)
    End Sub

End Module

