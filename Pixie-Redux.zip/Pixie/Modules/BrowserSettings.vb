﻿
Namespace NCS

    ' Provides access to the job settings
    <Global.Microsoft.VisualBasic.HideModuleNameAttribute()>
    Friend Module BrowserSettingsProperty

        ' Internal access to the job settings default instance
        <Global.System.ComponentModel.Design.HelpKeywordAttribute("NCS.BrowserSettings")>
        Private ReadOnly Property BrowserSettings() As Global.Pixie.Browser
            Get
                Return Global.Pixie.Browser.Default
            End Get
        End Property

        ' Recent page property
        Friend Property RecentPage As String
            Get
                Return BrowserSettings.RecentPage
            End Get
            Set(value As String)
                BrowserSettings.RecentPage = value
            End Set
        End Property

        ' Home page property
        Friend Property HomePage As String
            Get
                Return BrowserSettings.HomePage
            End Get
            Set(value As String)
                BrowserSettings.HomePage = value
            End Set
        End Property

        ' Reset browser settings
        Friend Sub ResetBrowserSettings()
            BrowserSettings.Reset()
        End Sub

        ' Save job settings
        Friend Sub SaveBrowserSettings()
            BrowserSettings.Save()
        End Sub

        ' Reload job settings
        Friend Sub ReloadBrowserSettings()
            BrowserSettings.Reload()
        End Sub

    End Module

End Namespace
