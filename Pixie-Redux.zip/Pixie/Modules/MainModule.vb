﻿
Imports System.Collections.ObjectModel

Public Module MainModule

    ' Set this to FALSE for release build!
    Public DebugMode As Boolean = False

    ' Computer types
    Enum ComputerType
        Undefined = 0
        Laptop
        Desktop
    End Enum

    ' Drive types
    Enum DriveType
        Undefined = 0
        FlashDrive
        SDCard
        FixedDisk
        FloppyDisk
        RemovableDisk
        OpticalDisk
        NetworkDrive
        RAMDrive
        OfflineDrive
        LogicalDrive
        NoRootDirectory
    End Enum

    ' Translate drive type from .NET to Pixie
    Function TranslateDriveType(msType As IO.DriveType) As MainModule.DriveType
        Select Case msType
            Case IO.DriveType.CDRom
                Return DriveType.OpticalDisk
            Case IO.DriveType.Fixed
                Return DriveType.FixedDisk
            Case IO.DriveType.Network
                Return DriveType.NetworkDrive
            Case IO.DriveType.NoRootDirectory
                Return DriveType.NoRootDirectory
            Case IO.DriveType.Ram
                Return DriveType.RAMDrive
            Case IO.DriveType.Removable
                Return CType(My.Settings.CurrentDriveType, DriveType)
            Case Else
                Return DriveType.Undefined
        End Select
    End Function

    ' Choose username
    Sub ChooseUserName()
        Dim user As String = My.Settings.UserName
        If user = My.Resources.DefaultUserName Then
            user = ""
        End If
        If user.Length < 1 Then
            user = Environ("USERNAME")
            If user Is Nothing Then user = ""
        End If
        If user = "<reset>" Then user = ""
        If user.Length < 1 Then
            PickUserDlg.Execute()
        Else
            My.Settings.UserName = PrettifyUserName(user)
        End If
    End Sub

    ' Choose userdomain
    Sub ChooseUserDomain()
        Dim domain As String = My.Settings.UserDomain
        If domain.Length < 1 Then
            domain = Environ("USERDOMAIN")
            If domain Is Nothing Then domain = ""
            If domain.Length < 1 Then
                domain = "localhost"
            End If
        End If
        Dim query As String = "Please enter the user domain for your computer."
        domain = InputDlg.Execute(query, domain, True)
        My.Settings.UserDomain = domain
    End Sub

    ' Choose user profile folder
    Sub ChooseUserProfileFolder()
        Dim path As String
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        Dim msg As String = My.Resources.PixieResources.ChooseUserProfileMsg
        Dim lookFor As String = Environ("USERPROFILE")
        If lookFor Is Nothing Then lookFor = ""
        Dim root As String = "C:\Users"
        Dim auto As PickFolderDlg.AutoModeEnum = PickFolderDlg.AutoModeEnum.None
        Do
            result = PickFolderDlg.Execute(msg, root, lookFor, auto)
            If result <> DialogResult.OK Then
                ShowInfoBox("I'm sorry, but this is really important. Please try again.")
            Else
                path = PickFolderDlg.ExecuteResult
                Exit Do
            End If
        Loop
        If path.EndsWith("\") Or path.EndsWith("/") Then
            path = path.Substring(0, path.Length - 1)
        End If
        My.Settings.ProfileFolder = path
        If DebugMode Then
            ResetSpecialFolders()
            Return
        End If
        My.Settings.PicturesFolder = path + "\Pictures"
        My.Settings.VideosFolder = path + "\Videos"
        My.Settings.MusicFolder = path + "\Music"
        My.Settings.ContactsFolder = path + "\Contacts"
        My.Settings.DocumentsFolder = path + "\Documents"
        My.Settings.FavoritesFolder = path + "\Favorites"
        My.Settings.DownloadsFolder = path + "\Downloads"
    End Sub

    ' Choose pictures folder
    Sub ChoosePicturesFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your pictures are located."
        dlg.LookForFolder = "Pictures"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.PicturesFolder = dlg.SelectedPath
    End Sub

    ' Choose videos folder
    Sub ChooseVideosFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your videos are located."
        dlg.LookForFolder = "Videos"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.VideosFolder = dlg.SelectedPath
    End Sub

    ' Choose music folder
    Sub ChooseMusicFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your music is located."
        dlg.LookForFolder = "Music"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.MusicFolder = dlg.SelectedPath
    End Sub

    ' Choose documents folder
    Sub ChooseDocumentsFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your documents are located."
        dlg.LookForFolder = "Documents"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.DocumentsFolder = dlg.SelectedPath
    End Sub

    ' Choose downloads folder
    Sub ChooseDownloadsFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your downloaded files are located."
        dlg.LookForFolder = "Downloads"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.DownloadsFolder = dlg.SelectedPath
    End Sub

    ' Choose favorites folder
    Sub ChooseFavoritesFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your favorites are located."
        dlg.LookForFolder = "Favorites"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.FavoritesFolder = dlg.SelectedPath
    End Sub

    ' Choose contacts folder
    Sub ChooseContactsFolder()
        Dim dlg As New PickFolderDlg
        dlg.AutoMode = PickFolderDlg.AutoModeEnum.None
        dlg.HelpMessage = "Please choose the folder where your contacts are located."
        dlg.LookForFolder = "Contacts"
        dlg.RootPath = My.Settings.ProfileFolder
        Dim parent As Form = My.Application.OpenForms(0)
        Dim result As DialogResult
        result = dlg.ShowDialog(parent)
        If (result <> DialogResult.OK) Then
            Return
        End If
        My.Settings.ContactsFolder = dlg.SelectedPath
    End Sub

    ' Choose removable device and prepare path for pixie load/save
    Function ChooseRemovableDevicePath(parent As Form) As String
        Dim s As String = ""
        Dim dlg As New PickDeviceDlg
        Dim r As DialogResult = dlg.ShowDialog(parent)
        If (r = DialogResult.OK) Then
            s = dlg.SelectedDrive + ":\"
        Else
            Return ""
        End If
        Return s
    End Function

    ' Get user profile folder
    Function GetUserProfileFolder() As String
        If DebugMode Then
            ChooseUserProfileFolder()
            Return My.Settings.ProfileFolder
        End If
        Dim folder As String = My.Settings.ProfileFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = Environ("USERPROFILE")
        If folder Is Nothing Then
            ChooseUserProfileFolder()
            Return My.Settings.ProfileFolder
        End If
        If Not IO.Directory.Exists(folder) Then
            ChooseUserProfileFolder()
            Return My.Settings.ProfileFolder
        End If
        My.Settings.ProfileFolder = folder
        Return folder
    End Function

    ' Compose special folder
    Function ComposeSpecialFolder(name As String) As String
        Dim profile As String = GetUserProfileFolder()
        If profile.EndsWith("\") Or profile.EndsWith("/") Then
            Return profile + name
        Else
            Return profile + "\" + name
        End If
    End Function

    ' Get pictures folder
    Function GetPicturesFolder() As String
        If DebugMode Then
            ChoosePicturesFolder()
            Return My.Settings.PicturesFolder
        End If
        Dim folder As String = My.Settings.PicturesFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Pictures")
        If IO.Directory.Exists(folder) Then
            My.Settings.PicturesFolder = folder
            Return folder
        End If
        ChoosePicturesFolder()
        Return My.Settings.PicturesFolder
    End Function

    ' Get music folder
    Function GetMusicFolder() As String
        If DebugMode Then
            ChooseMusicFolder()
            Return My.Settings.MusicFolder
        End If
        Dim folder As String = My.Settings.MusicFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Music")
        If IO.Directory.Exists(folder) Then
            My.Settings.MusicFolder = folder
            Return folder
        End If
        ChooseMusicFolder()
        Return My.Settings.MusicFolder
    End Function

    ' Get videos folder
    Function GetVideosFolder() As String
        If DebugMode Then
            ChooseVideosFolder()
            Return My.Settings.VideosFolder
        End If
        Dim folder As String = My.Settings.VideosFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Videos")
        If IO.Directory.Exists(folder) Then
            My.Settings.VideosFolder = folder
            Return folder
        End If
        ChooseVideosFolder()
        Return My.Settings.VideosFolder
    End Function

    ' Get documents folder
    Function GetDocumentsFolder() As String
        If DebugMode Then
            ChooseDocumentsFolder()
            Return My.Settings.DocumentsFolder
        End If
        Dim folder As String = My.Settings.DocumentsFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Documents")
        If IO.Directory.Exists(folder) Then
            My.Settings.DocumentsFolder = folder
            Return folder
        End If
        ChooseDocumentsFolder()
        Return My.Settings.DocumentsFolder
    End Function

    ' Get contacts folder
    Function GetContactsFolder() As String
        If DebugMode Then
            ChooseContactsFolder()
            Return My.Settings.ContactsFolder
        End If
        Dim folder As String = My.Settings.ContactsFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Contacts")
        If IO.Directory.Exists(folder) Then
            My.Settings.ContactsFolder = folder
            Return folder
        End If
        ChooseContactsFolder()
        Return My.Settings.ContactsFolder
    End Function

    ' Get favorites folder
    Function GetFavoritesFolder() As String
        If DebugMode Then
            ChooseFavoritesFolder()
            Return My.Settings.FavoritesFolder
        End If
        Dim folder As String = My.Settings.FavoritesFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Favorites")
        If IO.Directory.Exists(folder) Then
            My.Settings.FavoritesFolder = folder
            Return folder
        End If
        ChooseFavoritesFolder()
        Return My.Settings.FavoritesFolder
    End Function

    ' Get downloads folder
    Function GetDownloadsFolder() As String
        If DebugMode Then
            ChooseDownloadsFolder()
            Return My.Settings.DownloadsFolder
        End If
        Dim folder As String = My.Settings.DownloadsFolder
        If IO.Directory.Exists(folder) Then Return folder
        folder = ComposeSpecialFolder("Downloads")
        If IO.Directory.Exists(folder) Then
            My.Settings.DownloadsFolder = folder
            Return folder
        End If
        ChooseDownloadsFolder()
        Return My.Settings.DownloadsFolder
    End Function

    ' Get user name
    Function GetUserName() As String
        Dim user As String = My.Settings.UserName
        If user = My.Resources.DefaultUserName Then
            user = ""
        End If
        If user.Length < 1 Then
            ChooseUserName()
        End If
        Return My.Settings.UserName
    End Function

    ' Get user domain
    Function GetUserDomain() As String
        Dim domain As String = My.Settings.UserDomain
        If domain.Length > 0 Then Return domain
        domain = Environ("USERDOMAIN")
        If domain Is Nothing Then
            domain = ""
        End If
        If domain.Length < 1 Then
            ChooseUserDomain()
            domain = My.Settings.UserDomain
        End If
        My.Settings.UserDomain = domain
        Return domain
    End Function

    ' Reset special folders
    Sub ResetSpecialFolders()
        My.Settings.ProfileFolder = ""
        My.Settings.PicturesFolder = ""
        My.Settings.MusicFolder = ""
        My.Settings.VideosFolder = ""
        My.Settings.DocumentsFolder = ""
        My.Settings.DownloadsFolder = ""
        My.Settings.ContactsFolder = ""
        My.Settings.FavoritesFolder = ""
    End Sub

    ' Verify special folders
    Sub VerifySpecialFolders()
        If Not IO.Directory.Exists(My.Settings.PicturesFolder) Then
            ChoosePicturesFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.VideosFolder) Then
            ChooseVideosFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.MusicFolder) Then
            ChooseMusicFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.DocumentsFolder) Then
            ChooseDocumentsFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.ContactsFolder) Then
            ChooseContactsFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.DownloadsFolder) Then
            ChooseDownloadsFolder()
        End If
        If Not IO.Directory.Exists(My.Settings.FavoritesFolder) Then
            ChooseFavoritesFolder()
        End If
    End Sub

    ' Primary application initialization
    Function Initialize(mainForm As Form) As Boolean
        Dim success As Boolean = False
        Try
            If DebugMode Then
                My.Settings.UserName = My.Resources.DefaultUserName
                My.Settings.UserDomain = ""
                Dim frm As New TestForm
                frm.Show()
                ResetSpecialFolders()
            End If
            GetUserName()
            GetUserDomain()
            GetUserProfileFolder()
            VerifySpecialFolders()
            '
            ' TODO... put additional initialization here...
            '
            success = True
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
        Return success
    End Function

    ' Prettify user name
    Public Function PrettifyUserName(name As String) As String
        Return PickUserDlg.PrettifyName(name)
    End Function

End Module

