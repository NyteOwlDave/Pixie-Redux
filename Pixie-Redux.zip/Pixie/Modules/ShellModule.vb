﻿
Imports Microsoft.Win32

Public Module ShellModule

    ' Get environment variable
    Function GetEnviron(name As String) As String
        Dim value As String = ""
        Try
            value = Environ(name)
            If value Is Nothing Then value = ""
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
        Return value
    End Function

    ' Opens the specified program with the specified argument strin
    Sub ShellOpen(cmd As String, arg As String)
        Try
            If cmd.Length < 1 Then
                cmd = arg
                arg = ""
                If cmd.Length < 1 Then
                    ShowInfoBox("Sorry, but you need to specify a command.")
                    Return
                End If
            End If
            Dim s As String
            If arg.Length < 1 Then
                s = cmd
            Else
                s = cmd + " " + Chr(34) + arg + Chr(34)
            End If
            Shell(s, AppWinStyle.NormalFocus)
        Catch ex As Exception
            ShowErrorBox(ex.Message)
        End Try
    End Sub

    ' Opens Windows Explorer with the specified argument string
    Sub Explore(arg As String)
        ShellOpen("explorer.exe", arg)
    End Sub

    ' Opens the web browser to show the specified url
    Sub Browse(arg As String)
        Dim form As New BrowserForm
        BrowserForm.HomePage = arg
        form.Show()
    End Sub

    ' Show pixie's root folder in explorer window
    Sub ExplorePixieRootFolder()
        Explore(GetPixieFolder())
    End Sub

    ' Show user's profile folder in explorer window
    Sub ExploreUserProfileFolder()
        Dim s As String
        s = Environ("USERPROFILE")
        If s Is Nothing Then s = ""
        If s.Length < 1 Then
            Dim r As MsgBoxResult
            Dim msg As String = My.Resources.NoUserProfile
            r = ShowYesNoBox(msg)
            If r <> MsgBoxResult.Yes Then Return
            Explore("")
        Else
            Explore(s)
        End If
    End Sub

    ' Browse user's profile folder in Pixie browser
    Sub BrowseUserProfileFolder()
        Dim s As String
        s = Environ("USERPROFILE")
        If s Is Nothing Then s = ""
        If s.Length < 1 Then
            Dim r As MsgBoxResult
            Dim msg As String = My.Resources.NoUserProfile
            r = ShowYesNoBox(msg)
            If r <> MsgBoxResult.Yes Then Return
            BrowserForm.Execute("C:\")
        Else
            BrowserForm.Execute(s)
        End If
    End Sub

    ' Get pathname for default browser
    Function GetDefaultBrowser() As String
        Dim browser As String = String.Empty
        Dim key As RegistryKey = Nothing
        Try
            key = Registry.ClassesRoot.OpenSubKey("HTTP\shell\open\command", False)
            'trim off quotes
            browser = key.GetValue(Nothing).ToString().ToLower().Replace("""", "")
            If Not browser.EndsWith("exe") Then
                'get rid of everything after the ".exe"
                browser = browser.Substring(0, browser.LastIndexOf(".exe") + 4)
            End If
        Finally
            If key IsNot Nothing Then
                key.Close()
            End If
        End Try
        Return browser
    End Function

    ' Get pixie folder
    Function GetPixieFolder() As String
        Dim path = System.AppDomain.CurrentDomain.BaseDirectory
        If path.EndsWith("\") Or path.EndsWith("/") Then
            Return path.Substring(0, path.Length - 1)
        End If
        Return path
    End Function

    ' Get pixie content folder
    Function GetPixieContentFolder() As String
        Return GetPixieFolder() + "\Content"
    End Function

    ' Get user profile subfolder
    Function GetUserProfileSubFolder(name As String) As String
        Dim path As String = Environ("USERPROFILE")
        If path.EndsWith("\") Or path.EndsWith("/") Then
            Return path + name
        Else
            Return path + "\" + name
        End If
    End Function

    ' Browse pixie help
    Sub BrowsePixieHelp()
        Dim path As String = GetPixieContentFolder()
        If path.EndsWith("\") Or path.EndsWith("/") Then
            path = path + My.Resources.HelpFileName
        Else
            path = path + "\" + My.Resources.HelpFileName
        End If
        Browse(path)
    End Sub

    ' Browse user pictures folder
    Sub BrowserUserPicturesFolder()
        Dim path As String = GetUserProfileSubFolder("Pictures")
        Browse(path)
    End Sub

End Module

