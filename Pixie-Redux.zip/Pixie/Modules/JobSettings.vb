﻿
Namespace NCS

    ' Job type enumeration
    Public Enum JobTypeEnum
        Undefined = 0
        ComputerToRemovable = 1
        RemovableToComputer = 2
        Backup = 3
        Restore = 4
    End Enum

    ' Job status enum
    Public Enum JobStatusEnum
        Pending = 0
        Paused = 1
        Scanning = 2
        Scanned = 3
        Copying = 4
        Copied = 5
        Completed = 6
        Failed = 7
        Cancelled = 8
    End Enum

    ' Provides access to the job settings
    <Global.Microsoft.VisualBasic.HideModuleNameAttribute()>
    Friend Module JobSettingsProperty

        ' Internal access to the job settings default instance
        <Global.System.ComponentModel.Design.HelpKeywordAttribute("NCS.JobSettings")>
        Private ReadOnly Property JobSettings() As Global.Pixie.Job
            Get
                Return Global.Pixie.Job.Default
            End Get
        End Property

        ' Current job status
        Friend Property JobStatus() As JobStatusEnum
            Get
                Return JobSettings.JobStatus
            End Get
            Set(value As JobStatusEnum)
                JobSettings.JobType = value
            End Set
        End Property

        ' Current job type
        Friend Property JobType() As JobTypeEnum
            Get
                Return JobSettings.JobType
            End Get
            Set(value As JobTypeEnum)
                JobSettings.JobType = value
            End Set
        End Property

        ' Number of folders copied
        Friend Property FoldersCopied() As UInteger
            Get
                Return JobSettings.FoldersCopied
            End Get
            Set(value As UInteger)
                JobSettings.FoldersCopied = value
            End Set
        End Property

        ' Number of files copied
        Friend Property FilesCopied() As UInteger
            Get
                Return JobSettings.FilesCopied
            End Get
            Set(value As UInteger)
                JobSettings.FilesCopied = value
            End Set
        End Property

        ' Number of bytes copied
        Friend Property BytesCopied() As ULong
            Get
                Return JobSettings.BytesCopied
            End Get
            Set(value As ULong)
                JobSettings.BytesCopied = value
            End Set
        End Property

        ' Number of folders scanned
        Friend Property FoldersScanned() As UInteger
            Get
                Return JobSettings.FoldersScanned
            End Get
            Set(value As UInteger)
                JobSettings.FoldersScanned = value
            End Set
        End Property

        ' Number of files scanned
        Friend Property FilesScanned() As UInteger
            Get
                Return JobSettings.FilesScanned
            End Get
            Set(value As UInteger)
                JobSettings.FilesScanned = value
            End Set
        End Property

        ' Number of bytes scanned
        Friend Property BytesScanned() As ULong
            Get
                Return JobSettings.BytesScanned
            End Get
            Set(value As ULong)
                JobSettings.BytesScanned = value
            End Set
        End Property

        ' Local folder
        Friend Property LocalFolder As String
            Get
                Return JobSettings.LocalFolder
            End Get
            Set(value As String)
                JobSettings.LocalFolder = value
            End Set
        End Property

        ' Removable drive
        Friend Property RemovableDrive As String
            Get
                Return JobSettings.RemovableDrive
            End Get
            Set(value As String)
                JobSettings.RemovableDrive = value
            End Set
        End Property

        ' Source path
        Friend Property SourcePath As String
            Get
                Return JobSettings.SourcePath
            End Get
            Set(value As String)
                JobSettings.SourcePath = value
            End Set
        End Property

        ' User domain
        Friend Property UserDomain As String
            Get
                Return JobSettings.UserDomain
            End Get
            Set(value As String)
                JobSettings.UserDomain = value
            End Set
        End Property

        ' User name
        Friend Property UserName As String
            Get
                Return JobSettings.UserName
            End Get
            Set(value As String)
                JobSettings.UserName = value
            End Set
        End Property

        ' Target path
        Friend Property TargetPath As String
            Get
                Return JobSettings.TargetPath
            End Get
            Set(value As String)
                JobSettings.TargetPath = value
            End Set
        End Property

        ' Creation date
        Friend Property CreationDate As Date
            Get
                Return JobSettings.CreationDate
            End Get
            Set(value As Date)
                JobSettings.CreationDate = value
            End Set
        End Property

        ' Completion date
        Friend Property CompletionDate As Date
            Get
                Return JobSettings.CompletionDate
            End Get
            Set(value As Date)
                JobSettings.CompletionDate = value
            End Set
        End Property

        ' Reset job settings
        Friend Sub ResetJobSettings()
            JobSettings.Reset()
        End Sub

        ' Save job settings
        Friend Sub SaveJobSettings()
            JobSettings.Save()
        End Sub

        ' Reload job settings
        Friend Sub ReloadJobSettings()
            JobSettings.Reload()
        End Sub

    End Module

End Namespace

