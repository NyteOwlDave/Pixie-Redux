﻿
Imports System.Windows.Forms

Public Module ResourceModule

    ' Image Categories
    Enum ImageCategory
        Simple = 0
        RemovableToComputer
        ComputerToRemovable
        PixieGirl
        Laptop
        Desktop
        SDCard
        UnknownDrive
        LogicalDrive
        OfflineDrive
        FlashDrive
        RemovableDrive
        NetworkDrive
        RAMDrive
        FloppyDisk
        FixedDisk
        OpticalDisk
        NoRootDirectory
    End Enum

    ' Image ranges
    Enum ImageRange

        ' Undefindex image type
        Undefined = 0

        ' Valid range
        ValidFirst = 1
        ValidLast = 999
        ValidCount = 999

        ' Simple images category
        SimpleCategoryFirst = 1
        SimpleCategoryLast = 99
        SimpleCount = 99

        ' Removable to computer category
        RemovableToComputerFirst = SimpleCategoryLast + 1
        RemovableToComputerLast = RemovableToComputerFirst + 9
        RemovableToComputerCount = RemovableToComputerLast - RemovableToComputerFirst + 1

        ' Computer to removable category
        ComputerToRemovableFirst = RemovableToComputerLast + 1
        ComputerToRemovableLast = ComputerToRemovableFirst + 9
        ComputerToRemovableCount = ComputerToRemovableLast - ComputerToRemovableFirst + 1

        ' PixieGirl category
        PixieGirlFirst = ComputerToRemovableLast + 1
        PixieGirlLast = PixieGirlFirst + 9
        PixieGirlCount = PixieGirlLast - PixieGirlFirst + 1

        ' Laptop category
        LaptopFirst = PixieGirlLast + 1
        LaptopLast = LaptopFirst + 9
        LaptopCount = LaptopLast - LaptopFirst + 1

        ' Desktop category
        DesktopFirst = LaptopLast + 1
        DesktopLast = DesktopFirst + 9
        desktopcount = DesktopLast - DesktopFirst + 1

        ' Flash drive category
        FlashDriveFirst = DesktopLast + 1
        FlashDriveLast = FlashDriveFirst + 9
        FlashDriveCount = FlashDriveLast - FlashDriveFirst + 1

        ' SD card category
        SDCardFirst = FlashDriveLast + 1
        SDCardLast = SDCardFirst + 9
        SDCardCount = SDCardLast - SDCardFirst + 1

        ' Fixed disk category
        FixedDiskFirst = SDCardLast + 1
        FixedDiskLast = FixedDiskFirst + 9
        FixedDiskCount = FixedDiskLast - FixedDiskFirst + 1

        ' Optical disk category
        OpticalDiskFirst = FixedDiskLast + 1
        OpticalDiskLast = OpticalDiskFirst + 9
        OpticalDiskCount = OpticalDiskLast - OpticalDiskFirst + 1

        ' Network drive category
        NetworkDriveFirst = OpticalDiskLast + 1
        NetworkDriveLast = NetworkDriveFirst + 9
        NetworkDriveCount = NetworkDriveLast - NetworkDriveFirst + 1

        ' No root directory category
        NoRootDirFirst = NetworkDriveLast + 1
        NoRootDirLast = NoRootDirFirst + 9
        NoRootDirCount = NoRootDirLast - NoRootDirFirst + 1

        ' No root directory category
        RemovableDriveFirst = NoRootDirLast + 1
        RemovableDriveLast = RemovableDriveFirst + 9
        RemovableDriveCount = RemovableDriveLast - RemovableDriveFirst + 1

        ' Offline drive category
        OfflineDriveFirst = RemovableDriveLast + 1
        OfflineDriveLast = OfflineDriveFirst + 9
        OfflineDriveCount = OfflineDriveLast - OfflineDriveFirst + 1

        ' Unknown drive category
        UnknownDriveFirst = OfflineDriveLast + 1
        UnknownDriveLast = UnknownDriveFirst + 9
        UnknownDriveCount = UnknownDriveLast - UnknownDriveFirst + 1

        ' RAM drive category
        RAMDriveFirst = UnknownDriveLast + 1
        RAMDriveLast = RAMDriveFirst + 9
        RAMDriveCount = RAMDriveLast - RAMDriveFirst + 1

        ' Logical drive category
        LogicalDriveFirst = RAMDriveLast + 1
        LogicalDriveLast = LogicalDriveFirst + 9
        LogicalDriveCount = LogicalDriveLast - LogicalDriveFirst + 1

        ' Floppy disk category
        FloppyDiskFirst = LogicalDriveLast + 1
        FloppyDiskLast = FloppyDiskFirst + 9
        FloppyDiskCount = FloppyDiskLast - FloppyDiskFirst + 1

        ' Futute drive category
        FutureDriveFirst = FloppyDiskLast + 1
        FutureDriveLast = FutureDriveFirst + 9
        FutureDriveCount = FutureDriveLast - FutureDriveFirst + 1

    End Enum

    ' Image types
    Enum ImageType

        ' Undefined
        Undefined = ImageRange.Undefined

        ' Simple images
        MyProfile = ImageRange.SimpleCategoryFirst

        ' Copy from removable drive to computer
        FlashToLaptop = ImageRange.RemovableToComputerFirst
        FlashToDesktop = FlashToLaptop + 1
        SDtoDesktop = FlashToLaptop + 2
        SDtoLaptop = FlashToLaptop + 3

        ' Copy from computer to removable drive
        LaptopToFlash = ImageRange.ComputerToRemovableFirst
        LaptopToSD = LaptopToFlash + 1
        DesktopToSD = LaptopToFlash + 2
        DesktopToFlash = LaptopToFlash + 3

        ' Pixie girl (various sizes)
        PixieGirl = ImageRange.PixieGirlFirst
        PixieGirl256 = PixieGirl ' No 512 available
        PixieGirl128 = PixieGirl + 1
        PixieGirl64 = PixieGirl + 2
        PixieGirl32 = PixieGirl + 3

        ' Laptop computer (various sizes)
        Laptop = ImageRange.LaptopFirst
        Laptop256 = Laptop ' No 512 available
        Laptop128 = Laptop + 1
        Laptop64 = Laptop + 2
        Laptop32 = Laptop + 3

        ' Desktop computer (various sizes)
        Desktop = ImageRange.DesktopFirst
        Desktop256 = Desktop ' No 512 available
        Desktop128 = Desktop + 1
        Desktop64 = Desktop + 2
        Desktop32 = Desktop + 3

        ' Flash drive (various sizes)
        FlashDrive = ImageRange.FlashDriveFirst
        FlashDrive256 = FlashDrive ' No 512 available
        FlashDrive128 = FlashDrive + 1
        FlashDrive64 = FlashDrive + 2
        FlashDrive32 = FlashDrive + 3

        ' SD card (various sizes)
        SDCard = ImageRange.SDCardFirst
        SDCard256 = SDCard ' No 512 available
        SDCard128 = SDCard + 1
        SDCard32 = SDCard + 2
        SDCard64 = SDCard + 3

        ' Fixed disk drive (various sizes)
        FixedDisk = ImageRange.FixedDiskFirst
        FixedDisk256 = FixedDisk + 1
        FixedDisk128 = FixedDisk + 2
        FixedDisk64 = FixedDisk + 3
        FixedDisk32 = FixedDisk + 4

        ' Optical disk drive (various sizes)
        OpticalDisk = ImageRange.OpticalDiskFirst
        OpticalDisk256 = OpticalDisk + 1
        OpticalDisk128 = OpticalDisk + 2
        OpticalDisk64 = OpticalDisk + 3
        OpticalDisk32 = OpticalDisk + 4

        ' Network drive (various sizes)
        NetworkDrive = ImageRange.NetworkDriveFirst
        NetworkDrive256 = NetworkDrive + 1
        NetworkDrive128 = NetworkDrive + 2
        NetworkDrive64 = NetworkDrive + 3
        NetworkDrive32 = NetworkDrive + 4

        ' Drive with no root directory (various sizes)
        NoRootDir = ImageRange.NoRootDirFirst
        NoRootDir256 = NoRootDir + 1
        NoRootDir128 = NoRootDir + 2
        NoRootDir64 = NoRootDir + 3
        NoRootDir32 = NoRootDir + 4

        ' Generic removable drive (various sizes)
        RemovableDrive = ImageRange.RemovableDriveFirst
        RemovableDrive256 = RemovableDrive + 1
        RemovableDrive128 = RemovableDrive + 2
        RemovableDrive64 = RemovableDrive + 3
        RemovableDrive32 = RemovableDrive + 4

        ' Offline network drive (various sizes)
        OfflineDrive = ImageRange.OfflineDriveFirst
        OfflineDrive256 = OfflineDrive + 1
        OfflineDrive128 = OfflineDrive + 2
        OfflineDrive64 = OfflineDrive + 3
        OfflineDrive32 = OfflineDrive + 4

        ' Unknown drive (various sizes)
        UnknownDrive = ImageRange.UnknownDriveFirst
        UnknownDrive256 = UnknownDrive + 1
        UnknownDrive128 = UnknownDrive + 2
        UnknownDrive64 = UnknownDrive + 3
        UnknownDrive32 = UnknownDrive + 4

        ' Unknown drive (various sizes)
        RAMDrive = ImageRange.RAMDriveFirst
        RAMDrive256 = RAMDrive + 1
        RAMDrive128 = RAMDrive + 2
        RAMDrive64 = RAMDrive + 3
        RAMDrive32 = RAMDrive + 4

        ' Floppy disk (various sizes)
        FloppyDisk = ImageRange.FloppyDiskFirst
        FloppyDisk256 = FloppyDisk + 1
        FloppyDisk128 = FloppyDisk + 2
        FloppyDisk64 = FloppyDisk + 3
        FloppyDisk32 = FloppyDisk + 4

        ' Logical drive (various sizes)
        LogicalDrive = ImageRange.LogicalDriveFirst
        LogicalDrive256 = LogicalDrive + 1
        LogicalDrive128 = LogicalDrive + 2
        LogicalDrive64 = LogicalDrive + 3
        LogicalDrive32 = LogicalDrive + 4

    End Enum

    ' Image sizes
    Enum ImageSize
        Custom = 0
        Miniscule = 16
        Tiny = 32
        Small = 64
        Medium = 128
        Large = 256
        Standard = 512
        Jumbo = 1024
    End Enum

    ' Detects image size from image object
    Public Function DetectImageSize(img As Image) As ImageSize
        If img Is Nothing Then Return ImageSize.Custom
        Dim w As Integer = img.Width
        Dim h As Integer = img.Height
        If (w <> h) Then Return ImageSize.Custom
        Select Case w
            Case 1024
                Return ImageSize.Jumbo
            Case 512
                Return ImageSize.Standard
            Case 256
                Return ImageSize.Large
            Case 128
                Return ImageSize.Medium
            Case 64
                Return ImageSize.Small
            Case 32
                Return ImageSize.Tiny
            Case Else
                Return ImageSize.Custom
        End Select
    End Function

    ' TODO --- Get image
    Function GetImage(cat As ImageCategory, size As ImageSize) As BaseImage
        '
        ' TODO...
        '
        Return Nothing
    End Function

    ' Lookup image type for drive type and image size
    Function GetImageTypeForDrive(dt As DriveType, size As ImageSize) As ImageType
        Select Case dt
            Case DriveType.FixedDisk
                Return GetImageTypeForFixedDisk(size)
            Case DriveType.FlashDrive
                Return GetImageTypeForFlashDrive(size)
            Case DriveType.FloppyDisk
                Return GetImageTypeForFloppyDisk(size)
            Case DriveType.LogicalDrive
                Return GetImageTypeForLogicalDrive(size)
            Case DriveType.NetworkDrive
                Return GetImageTypeForNetworkDrive(size)
            Case DriveType.NoRootDirectory
                Return GetImageTypeForNoRootDirectory(size)
            Case DriveType.OfflineDrive
                Return GetImageTypeForOfflineDrive(size)
            Case DriveType.OpticalDisk
                Return GetImageTypeForOpticalDisk(size)
            Case DriveType.RAMDrive
                Return GetImageTypeForRAMDrive(size)
            Case DriveType.RemovableDisk
                Return GetImageTypeForRemovableDisk(size)
            Case DriveType.SDCard
                Return GetImageTypeForSDCard(size)
            Case Else
                Return ImageType.Undefined
        End Select
    End Function

    ' Lookup image type for flash drive given image size
    Function GetImageTypeForFlashDrive(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.FlashDrive32
            Case ImageSize.Tiny
                Return ImageType.FlashDrive32
            Case ImageSize.Small
                Return ImageType.FlashDrive64
            Case ImageSize.Medium
                Return ImageType.FlashDrive128
            Case Else
                Return ImageType.FlashDrive
        End Select
    End Function

    ' Lookup image type for SD card given image size
    Function GetImageTypeForSDCard(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.SDCard32
            Case ImageSize.Tiny
                Return ImageType.SDCard32
            Case ImageSize.Small
                Return ImageType.SDCard64
            Case ImageSize.Medium
                Return ImageType.SDCard128
            Case Else
                Return ImageType.SDCard
        End Select
    End Function

    ' Lookup image type for fixed disk given image size
    Function GetImageTypeForFixedDisk(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.FixedDisk32
            Case ImageSize.Tiny
                Return ImageType.FixedDisk32
            Case ImageSize.Small
                Return ImageType.FixedDisk64
            Case ImageSize.Medium
                Return ImageType.FixedDisk128
            Case ImageSize.Large
                Return ImageType.FixedDisk256
            Case Else
                Return ImageType.FixedDisk
        End Select
    End Function

    ' Lookup image type for floppy disk given image size
    Function GetImageTypeForFloppyDisk(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.FloppyDisk32
            Case ImageSize.Tiny
                Return ImageType.FloppyDisk32
            Case ImageSize.Small
                Return ImageType.FloppyDisk64
            Case ImageSize.Medium
                Return ImageType.FloppyDisk128
            Case ImageSize.Large
                Return ImageType.FloppyDisk256
            Case Else
                Return ImageType.FloppyDisk
        End Select
    End Function

    ' Lookup image type for generic removable disk given image size
    Function GetImageTypeForRemovableDisk(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.RemovableDrive32
            Case ImageSize.Tiny
                Return ImageType.RemovableDrive32
            Case ImageSize.Small
                Return ImageType.RemovableDrive64
            Case ImageSize.Medium
                Return ImageType.RemovableDrive128
            Case ImageSize.Large
                Return ImageType.RemovableDrive256
            Case Else
                Return ImageType.RemovableDrive
        End Select
    End Function

    ' Lookup image type for optical disk given image size
    Function GetImageTypeForOpticalDisk(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.OpticalDisk32
            Case ImageSize.Tiny
                Return ImageType.OpticalDisk32
            Case ImageSize.Small
                Return ImageType.OpticalDisk64
            Case ImageSize.Medium
                Return ImageType.OpticalDisk128
            Case ImageSize.Large
                Return ImageType.OpticalDisk256
            Case Else
                Return ImageType.OpticalDisk
        End Select
    End Function

    ' Lookup image type for network given image size
    Function GetImageTypeForNetworkDrive(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.NetworkDrive32
            Case ImageSize.Tiny
                Return ImageType.NetworkDrive32
            Case ImageSize.Small
                Return ImageType.NetworkDrive64
            Case ImageSize.Medium
                Return ImageType.NetworkDrive128
            Case ImageSize.Large
                Return ImageType.NetworkDrive256
            Case Else
                Return ImageType.NetworkDrive
        End Select
    End Function

    ' Lookup image type for RAM drive given image size
    Function GetImageTypeForRAMDrive(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.RAMDrive32
            Case ImageSize.Tiny
                Return ImageType.RAMDrive32
            Case ImageSize.Small
                Return ImageType.RAMDrive64
            Case ImageSize.Medium
                Return ImageType.RAMDrive128
            Case ImageSize.Large
                Return ImageType.RAMDrive256
            Case Else
                Return ImageType.RAMDrive
        End Select
    End Function

    ' Lookup image type for offline drive given image size
    Function GetImageTypeForOfflineDrive(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.OfflineDrive32
            Case ImageSize.Tiny
                Return ImageType.OfflineDrive32
            Case ImageSize.Small
                Return ImageType.OfflineDrive64
            Case ImageSize.Medium
                Return ImageType.OfflineDrive128
            Case ImageSize.Large
                Return ImageType.OfflineDrive256
            Case Else
                Return ImageType.OfflineDrive
        End Select
    End Function

    ' Lookup image type for logical drive given image size
    Function GetImageTypeForLogicalDrive(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.LogicalDrive32
            Case ImageSize.Tiny
                Return ImageType.LogicalDrive32
            Case ImageSize.Small
                Return ImageType.LogicalDrive64
            Case ImageSize.Medium
                Return ImageType.LogicalDrive128
            Case ImageSize.Large
                Return ImageType.LogicalDrive256
            Case Else
                Return ImageType.LogicalDrive
        End Select
    End Function

    ' Lookup image type for logical drive given image size
    Function GetImageTypeForNoRootDirectory(size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                Return ImageType.NoRootDir32
            Case ImageSize.Tiny
                Return ImageType.NoRootDir32
            Case ImageSize.Small
                Return ImageType.NoRootDir64
            Case ImageSize.Medium
                Return ImageType.NoRootDir128
            Case ImageSize.Large
                Return ImageType.NoRootDir256
            Case Else
                Return ImageType.NoRootDir
        End Select
    End Function

    ' Lookup image type for computer type and image size
    Function GetImageTypeForComputer(ct As ComputerType, size As ImageSize) As ImageType
        Select Case size
            Case ImageSize.Miniscule
                If (ct = ComputerType.Desktop) Then
                    Return ImageType.Desktop32
                Else
                    Return ImageType.Laptop32
                End If
            Case ImageSize.Tiny
                If (ct = ComputerType.Desktop) Then
                    Return ImageType.Desktop32
                Else
                    Return ImageType.Laptop32
                End If
            Case ImageSize.Small
                If (ct = ComputerType.Desktop) Then
                    Return ImageType.Desktop64
                Else
                    Return ImageType.Laptop64
                End If
            Case ImageSize.Medium
                If (ct = ComputerType.Desktop) Then
                    Return ImageType.Desktop128
                Else
                    Return ImageType.Laptop128
                End If
            Case Else
                If (ct = ComputerType.Desktop) Then
                    Return ImageType.Desktop
                Else
                    Return ImageType.Laptop
                End If
        End Select
    End Function

    ' Lookup the appropriate ImageType for moving files from drive to computer
    Function GetImageTypeDtoC(dt As DriveType, ct As ComputerType) As ImageType
        Select Case dt
            Case DriveType.FlashDrive
                Select Case ct
                    Case ComputerType.Desktop
                        Return ImageType.FlashToDesktop
                    Case ComputerType.Laptop
                        Return ImageType.FlashToLaptop
                    Case Else
                        Return Nothing
                End Select
            Case DriveType.SDCard
                Select Case ct
                    Case ComputerType.Desktop
                        Return ImageType.SDtoDesktop
                    Case ComputerType.Laptop
                        Return ImageType.SDtoLaptop
                    Case Else
                        Return Nothing
                End Select
            Case Else
                Return Nothing
        End Select
    End Function

    ' Lookup the appropriate ImageType for moving files from computer to drive
    Function GetImageTypeCtoD(dt As DriveType, ct As ComputerType) As ImageType
        Select Case dt
            Case DriveType.FlashDrive
                Select Case ct
                    Case ComputerType.Desktop
                        Return ImageType.DesktopToFlash
                    Case ComputerType.Laptop
                        Return ImageType.LaptopToFlash
                    Case Else
                        Return Nothing
                End Select
            Case DriveType.SDCard
                Select Case ct
                    Case ComputerType.Desktop
                        Return ImageType.DesktopToSD
                    Case ComputerType.Laptop
                        Return ImageType.LaptopToSD
                    Case Else
                        Return Nothing
                End Select
            Case Else
                Return Nothing
        End Select
    End Function

    ' Determine if image type is within specified image range
    Function IsImageTypeInRange(type As ImageType, first As ImageRange, last As ImageRange) As Boolean
        If first > last Then
            Dim temp As Integer = first
            first = last
            last = temp
        End If
        If type < first Then Return False
        If type > last Then Return False
        Return True
    End Function

    ' Get image category from image type
    Function GetImageCategory(type As ImageType) As ImageCategory
        If IsImageTypeInRange(type, ImageRange.ComputerToRemovableFirst, ImageRange.ComputerToRemovableLast) Then
            Return ImageCategory.ComputerToRemovable
        End If
        If IsImageTypeInRange(type, ImageRange.DesktopFirst, ImageRange.DesktopLast) Then
            Return ImageCategory.Desktop
        End If
        If IsImageTypeInRange(type, ImageRange.FixedDiskFirst, ImageRange.FixedDiskLast) Then
            Return ImageCategory.FixedDisk
        End If
        If IsImageTypeInRange(type, ImageRange.FlashDriveFirst, ImageRange.FlashDriveLast) Then
            Return ImageCategory.FlashDrive
        End If
        If IsImageTypeInRange(type, ImageRange.FloppyDiskFirst, ImageRange.FloppyDiskLast) Then
            Return ImageCategory.FloppyDisk
        End If
        If IsImageTypeInRange(type, ImageRange.LaptopFirst, ImageRange.LaptopLast) Then
            Return ImageCategory.Laptop
        End If
        If IsImageTypeInRange(type, ImageRange.LogicalDriveFirst, ImageRange.LogicalDriveLast) Then
            Return ImageCategory.LogicalDrive
        End If
        If IsImageTypeInRange(type, ImageRange.NetworkDriveFirst, ImageRange.NetworkDriveLast) Then
            Return ImageCategory.NetworkDrive
        End If
        If IsImageTypeInRange(type, ImageRange.NoRootDirFirst, ImageRange.NoRootDirLast) Then
            Return ImageCategory.NoRootDirectory
        End If
        If IsImageTypeInRange(type, ImageRange.OfflineDriveFirst, ImageRange.OfflineDriveLast) Then
            Return ImageCategory.OfflineDrive
        End If
        If IsImageTypeInRange(type, ImageRange.OpticalDiskFirst, ImageRange.OpticalDiskLast) Then
            Return ImageCategory.OpticalDisk
        End If
        If IsImageTypeInRange(type, ImageRange.PixieGirlFirst, ImageRange.PixieGirlLast) Then
            Return ImageCategory.PixieGirl
        End If
        If IsImageTypeInRange(type, ImageRange.RAMDriveFirst, ImageRange.RAMDriveLast) Then
            Return ImageCategory.RAMDrive
        End If
        If IsImageTypeInRange(type, ImageRange.RemovableDriveFirst, ImageRange.RemovableDriveLast) Then
            Return ImageCategory.RemovableDrive
        End If
        If IsImageTypeInRange(type, ImageRange.RemovableToComputerFirst, ImageRange.RemovableToComputerLast) Then
            Return ImageCategory.RemovableToComputer
        End If
        If IsImageTypeInRange(type, ImageRange.SDCardFirst, ImageRange.SDCardLast) Then
            Return ImageCategory.SDCard
        End If
        If IsImageTypeInRange(type, ImageRange.UnknownDriveFirst, ImageRange.UnknownDriveLast) Then
            Return ImageCategory.UnknownDrive
        End If
        Return ImageCategory.Simple
    End Function

    ' Loads an image resource based in ImageType enumeration
    Function GetImageResource(type As ImageType) As Image
        Dim base As BaseImage
        base = GetBaseImageResource(type)
        If (base Is Nothing) Then Return Nothing
        Dim img As Image = base.Content
        base.Content = Nothing
        Return img
    End Function

    ' Loads an image resource based in ImageType enumeration
    Function GetBaseImageResource(type As ImageType) As BaseImage
        Dim cat As ImageCategory = GetImageCategory(type)
        Select Case cat
            Case ImageCategory.ComputerToRemovable
                Dim img As New ComputerToRemovableImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.Desktop
                Dim img As New DesktopImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.FixedDisk
                Dim img As New FixedDiskImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.FlashDrive
                Dim img As New FlashDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.FloppyDisk
                Dim img As New FloppyDiskImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.Laptop
                Dim img As New LaptopImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.LogicalDrive
                Dim img As New LogicalDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.NetworkDrive
                Dim img As New NetworkDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.NoRootDirectory
                ShowInfoBox("NoRootDirectoryImage class has not been implemented.")
                Return Nothing
                'Dim img As New NoRootDirectoryImage
                'If img.LoadResource(type) Then
                '    Return img
                'End If
            Case ImageCategory.OfflineDrive
                Dim img As New OfflineDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.OpticalDisk
                Dim img As New OpticalDiskImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.PixieGirl
                Dim img As New PixieGirlImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.RAMDrive
                Dim img As New RAMDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.RemovableDrive
                Dim img As New RemovableDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.RemovableToComputer
                Dim img As New RemovableToComputerImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.SDCard
                Dim img As New SDCardImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case ImageCategory.UnknownDrive
                Dim img As New UnknownDriveImage
                If img.LoadResource(type) Then
                    Return img
                End If
            Case Else
                Dim img As New SimpleImage
                If img.LoadResource(type) Then
                    Return img
                End If
        End Select
        Return Nothing
    End Function

End Module

' Base class for all image classes
Public MustInherit Class BaseImage
    Public Content As Image
    Public NcsType As ImageType
    ' Derived classes should set this member in their New() function
    Public Category As ImageCategory
    Public Function DetectSize() As ImageSize
        Return DetectImageSize(Content)
    End Function
    ' Helper function to detect image size (shared)
End Class

' Simple images (one size fits all!)
Public Class SimpleImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.Simple
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Select Case type
            Case ImageType.MyProfile
                NcsType = type
                Content = My.Resources.PixieResources.MyProfile
                Return True
            Case Else
                NcsType = ImageType.Undefined
                Content = Nothing
                Return False
        End Select
    End Function
End Class

' Removable to computer (four options)
Public Class RemovableToComputerImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.RemovableToComputer
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Select Case type
            Case ImageType.FlashToDesktop
                NcsType = type
                Content = My.Resources.PixieResources.FlashToDesktop
                Return True
            Case ImageType.FlashToLaptop
                NcsType = type
                Content = My.Resources.PixieResources.FlashToLaptop
                Return True
            Case ImageType.SDtoLaptop
                NcsType = type
                Content = My.Resources.PixieResources.SDtoLaptop
                Return True
            Case ImageType.SDtoDesktop
                NcsType = type
                Content = My.Resources.PixieResources.SDtoDesktop
                Return True
            Case Else
                NcsType = ImageType.Undefined
                Content = Nothing
                Return False
        End Select
    End Function
End Class

' Computer to removable (four options)
Public Class ComputerToRemovableImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.ComputerToRemovable
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Select Case type
            Case ImageType.LaptopToFlash
                NcsType = type
                Content = My.Resources.PixieResources.LaptopToFlash
                Return True
            Case ImageType.LaptopToSD
                NcsType = type
                Content = My.Resources.PixieResources.LaptopToSD
                Return True
            Case ImageType.DesktopToFlash
                NcsType = type
                Content = My.Resources.PixieResources.DesktopToFlash
                Return True
            Case ImageType.DesktopToSD
                NcsType = type
                Content = My.Resources.PixieResources.DesktopToSD
                Return True
            Case Else
                NcsType = ImageType.Undefined
                Content = Nothing
                Return False
        End Select
    End Function
End Class

' Pixie girl (various sizes)
Public Class PixieGirlImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.PixieGirl
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.PixieGirl, ImageType.PixieGirl256
                Return ImageSize.Large
            Case ImageType.PixieGirl128
                Return ImageSize.Medium
            Case ImageType.PixieGirl32
                Return ImageSize.Tiny
            Case ImageType.PixieGirl64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Medium
                NcsType = ImageType.PixieGirl128
                Content = My.Resources.PixieResources.PixieGirl128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.PixieGirl64
                Content = My.Resources.PixieResources.PixieGirl64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.PixieGirl32
                Content = My.Resources.PixieResources.PixieGirl32
                Return True
            Case Else
                NcsType = ImageType.PixieGirl256
                Content = My.Resources.PixieResources.PixieGirl
                Return True
        End Select
    End Function
End Class

' Laptop computer (various sizes)
Public Class LaptopImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.Laptop
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.Laptop, ImageType.Laptop256
                Return ImageSize.Large
            Case ImageType.Laptop128
                Return ImageSize.Medium
            Case ImageType.Laptop32
                Return ImageSize.Tiny
            Case ImageType.Laptop64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Medium
                NcsType = ImageType.Laptop128
                Content = My.Resources.PixieResources.Laptop128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.Laptop64
                Content = My.Resources.PixieResources.Laptop64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.Laptop32
                Content = My.Resources.PixieResources.Laptop32
                Return True
            Case Else
                NcsType = ImageType.Laptop256
                Content = My.Resources.PixieResources.Laptop
                Return True
        End Select
    End Function
End Class

' Desktop computer (various sizes)
Public Class DesktopImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.Desktop
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.Desktop, ImageType.Desktop256
                Return ImageSize.Large
            Case ImageType.Desktop128
                Return ImageSize.Medium
            Case ImageType.Desktop32
                Return ImageSize.Tiny
            Case ImageType.Desktop64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Medium
                NcsType = ImageType.Desktop128
                Content = My.Resources.PixieResources.Desktop128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.Desktop64
                Content = My.Resources.PixieResources.Desktop64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.Desktop32
                Content = My.Resources.PixieResources.Desktop32
                Return True
            Case Else
                NcsType = ImageType.Desktop
                Content = My.Resources.PixieResources.Desktop
                Return True
        End Select
    End Function
End Class

' SD Card (various sizes)
Public Class SDCardImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.SDCard
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.SDCard, ImageType.SDCard256
                Return ImageSize.Large
            Case ImageType.SDCard128
                Return ImageSize.Medium
            Case ImageType.SDCard32
                Return ImageSize.Tiny
            Case ImageType.SDCard64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Medium
                NcsType = ImageType.SDCard128
                Content = My.Resources.PixieResources.SDCard128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.SDCard64
                Content = My.Resources.PixieResources.SDCard64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.SDCard32
                Content = My.Resources.PixieResources.SDCard32
                Return True
            Case Else
                NcsType = ImageType.SDCard
                Content = My.Resources.PixieResources.SDCard
                Return True
        End Select
    End Function
End Class

' Flash drive (various sizes)
Public Class FlashDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.FlashDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.FlashDrive, ImageType.FlashDrive256
                Return ImageSize.Large
            Case ImageType.FlashDrive128
                Return ImageSize.Medium
            Case ImageType.FlashDrive32
                Return ImageSize.Tiny
            Case ImageType.FlashDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Medium
                NcsType = ImageType.FlashDrive128
                Content = My.Resources.PixieResources.FlashDrive128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.FlashDrive64
                Content = My.Resources.PixieResources.FlashDrive64
                Return True
            Case ImageSize.Tiny
                NcsType = ImageType.FlashDrive32
                Content = My.Resources.PixieResources.FlashDrive32
                Return True
            Case ImageSize.Miniscule
                NcsType = ImageType.FlashDrive32
                Content = My.Resources.PixieResources.FlashDrive32
                Return True
            Case Else
                NcsType = ImageType.FlashDrive
                Content = My.Resources.PixieResources.FlashDrive
                Return True
        End Select
    End Function
End Class

' Unknown drive (various sizes)
Public Class UnknownDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.UnknownDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.UnknownDrive
                Return ImageSize.Standard
            Case ImageType.UnknownDrive256
                Return ImageSize.Large
            Case ImageType.UnknownDrive128
                Return ImageSize.Medium
            Case ImageType.UnknownDrive32
                Return ImageSize.Tiny
            Case ImageType.UnknownDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Large
                NcsType = ImageType.UnknownDrive256
                Content = My.Resources.PixieResources.UnknownDrive256
                Return True
            Case ImageSize.Medium
                NcsType = ImageType.UnknownDrive128
                Content = My.Resources.PixieResources.UnknownDrive128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.UnknownDrive64
                Content = My.Resources.PixieResources.UnknownDrive64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.UnknownDrive32
                Content = My.Resources.PixieResources.UnknownDrive32
                Return True
            Case Else
                NcsType = ImageType.UnknownDrive
                Content = My.Resources.PixieResources.UnknownDrive
                Return True
        End Select
    End Function
End Class

' Network drive (various sizes)
Public Class NetworkDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.NetworkDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.NetworkDrive
                Return ImageSize.Standard
            Case ImageType.NetworkDrive256
                Return ImageSize.Large
            Case ImageType.NetworkDrive128
                Return ImageSize.Medium
            Case ImageType.NetworkDrive32
                Return ImageSize.Tiny
            Case ImageType.NetworkDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Large
                NcsType = ImageType.NetworkDrive256
                Content = My.Resources.PixieResources.NetDrive256
                Return True
            Case ImageSize.Medium
                NcsType = ImageType.NetworkDrive128
                Content = My.Resources.PixieResources.NetDrive128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.NetworkDrive64
                Content = My.Resources.PixieResources.NetDrive64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.NetworkDrive32
                Content = My.Resources.PixieResources.NetDrive32
                Return True
            Case Else
                NcsType = ImageType.NetworkDrive
                Content = My.Resources.PixieResources.NetDrive
                Return True
        End Select
    End Function
End Class

' RAM drive (various sizes)
Public Class RAMDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.RAMDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.RAMDrive
                Return ImageSize.Standard
            Case ImageType.RAMDrive256
                Return ImageSize.Large
            Case ImageType.RAMDrive128
                Return ImageSize.Medium
            Case ImageType.RAMDrive32
                Return ImageSize.Tiny
            Case ImageType.RAMDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Large
                NcsType = ImageType.RAMDrive256
                Content = My.Resources.PixieResources.RAMDrive256
                Return True
            Case ImageSize.Medium
                NcsType = ImageType.RAMDrive128
                Content = My.Resources.PixieResources.RAMDrive128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.RAMDrive64
                Content = My.Resources.PixieResources.RAMDrive64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.RAMDrive32
                Content = My.Resources.PixieResources.RAMDrive32
                Return True
            Case Else
                NcsType = ImageType.RAMDrive
                Content = My.Resources.PixieResources.RAMDrive
                Return True
        End Select
    End Function
End Class

' Fixed disk drive (various sizes)
Public Class FixedDiskImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.FixedDisk
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.FixedDisk
                Return ImageSize.Standard
            Case ImageType.FixedDisk256
                Return ImageSize.Large
            Case ImageType.FixedDisk128
                Return ImageSize.Medium
            Case ImageType.FixedDisk32
                Return ImageSize.Tiny
            Case ImageType.FixedDisk64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Large
                NcsType = ImageType.FixedDisk256
                Content = My.Resources.PixieResources.FixedDisk256
                Return True
            Case ImageSize.Medium
                NcsType = ImageType.FixedDisk128
                Content = My.Resources.PixieResources.FixedDisk128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.FixedDisk64
                Content = My.Resources.PixieResources.FixedDisk64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.FixedDisk32
                Content = My.Resources.PixieResources.FixedDisk32
                Return True
            Case Else
                NcsType = ImageType.FixedDisk
                Content = My.Resources.PixieResources.FixedDisk
                Return True
        End Select
    End Function
End Class

' Optical disk drive (various sizes)
Public Class OpticalDiskImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.OpticalDisk
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.OpticalDisk
                Return ImageSize.Standard
            Case ImageType.OpticalDisk256
                Return ImageSize.Large
            Case ImageType.OpticalDisk128
                Return ImageSize.Medium
            Case ImageType.OpticalDisk32
                Return ImageSize.Tiny
            Case ImageType.OpticalDisk64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        Select Case size
            Case ImageSize.Large
                NcsType = ImageType.OpticalDisk256
                Content = My.Resources.PixieResources.OpticalDrive256
                Return True
            Case ImageSize.Medium
                NcsType = ImageType.OpticalDisk128
                Content = My.Resources.PixieResources.OpticalDrive128
                Return True
            Case ImageSize.Small
                NcsType = ImageType.OpticalDisk64
                Content = My.Resources.PixieResources.OpticalDrive64
                Return True
            Case ImageSize.Tiny, ImageSize.Miniscule
                NcsType = ImageType.OpticalDisk32
                Content = My.Resources.PixieResources.OpticalDrive32
                Return True
            Case Else
                NcsType = ImageType.OpticalDisk
                Content = My.Resources.PixieResources.OpticalDrive
                Return True
        End Select
    End Function
End Class

#Region "Unimplemented classes - NEED WORK"

' Logical drive (various sizes)
Public Class LogicalDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.LogicalDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.LogicalDrive
                Return ImageSize.Standard
            Case ImageType.LogicalDrive256
                Return ImageSize.Large
            Case ImageType.LogicalDrive128
                Return ImageSize.Medium
            Case ImageType.LogicalDrive32
                Return ImageSize.Tiny
            Case ImageType.LogicalDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        ' TODO... image resources for logical drives
        ShowInfoBox("Resource files for logical drives need to be implemented!")
        Return False
    End Function
End Class

' Offline drive (various sizes)
Public Class OfflineDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.OfflineDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.OfflineDrive
                Return ImageSize.Standard
            Case ImageType.OfflineDrive256
                Return ImageSize.Large
            Case ImageType.OfflineDrive128
                Return ImageSize.Medium
            Case ImageType.OfflineDrive32
                Return ImageSize.Tiny
            Case ImageType.OfflineDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        ' TODO... image resources for logical drives
        ShowInfoBox("Resource files for offline drives need to be implemented!")
        Return False
    End Function
End Class

' Generic removable drive (various sizes)
Public Class RemovableDriveImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.RemovableDrive
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.RemovableDrive
                Return ImageSize.Standard
            Case ImageType.RemovableDrive256
                Return ImageSize.Large
            Case ImageType.RemovableDrive128
                Return ImageSize.Medium
            Case ImageType.RemovableDrive32
                Return ImageSize.Tiny
            Case ImageType.RemovableDrive64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        ShowInfoBox("Resource files for generic removable drives need to be implemented!")
        Return False
    End Function
End Class

' Floppy disk drive (various sizes)
Public Class FloppyDiskImage
    Inherits BaseImage
    Public Sub New()
        Category = ImageCategory.FloppyDisk
    End Sub
    Public Function LoadResource(type As ImageType) As Boolean
        Dim size As ImageSize = ChooseSize(type)
        If (size = ImageSize.Custom) Then Return False
        Return LoadBySize(size)
    End Function
    Public Function ChooseSize(type As ImageType) As ImageSize
        Select Case type
            Case ImageType.FloppyDisk
                Return ImageSize.Standard
            Case ImageType.FloppyDisk256
                Return ImageSize.Large
            Case ImageType.FloppyDisk128
                Return ImageSize.Medium
            Case ImageType.FloppyDisk32
                Return ImageSize.Tiny
            Case ImageType.FloppyDisk64
                Return ImageSize.Small
            Case Else
                Return ImageSize.Custom
        End Select
    End Function
    Public Function LoadBySize(size As ImageSize) As Boolean
        ' TODO... image resources for logical drives
        ShowInfoBox("Resource files for floppy disk drives need to be implemented!")
        Return False
    End Function
End Class

#End Region

